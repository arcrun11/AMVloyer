-- phpMyAdmin SQL Dump
-- version 2.6.2
-- http://www.phpmyadmin.net
-- 
-- ����: mysql18.1gb.ru
-- ����� ��������: ��� 07 2016 �., 14:34
-- ������ �������: 4.1.21
-- ������ PHP: 4.4.3-dev
-- 
-- ��: `gb_demoferma`
-- 

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_bonus_list`
-- 

CREATE TABLE `db_bonus_list` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(10) character set utf8 NOT NULL default '',
  `user_id` int(11) NOT NULL default '0',
  `sum` double NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  `date_del` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4110 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4110 ;

-- 
-- ���� ������ ������� `db_bonus_list`
-- 

INSERT INTO `db_bonus_list` VALUES (3759, 'vertebra', 78, 21, 1422682845, 1422769245);
INSERT INTO `db_bonus_list` VALUES (3741, 'aivaras881', 188, 17, 1422613779, 1422700179);
INSERT INTO `db_bonus_list` VALUES (3742, 'amince', 244, 32, 1422617348, 1422703748);
INSERT INTO `db_bonus_list` VALUES (3743, 'dens', 217, 17, 1422623200, 1422709600);
INSERT INTO `db_bonus_list` VALUES (3744, 'Mixaluch', 228, 63, 1422627819, 1422714219);
INSERT INTO `db_bonus_list` VALUES (3745, 'Erejep', 245, 19, 1422628840, 1422715240);
INSERT INTO `db_bonus_list` VALUES (3757, 'Deit15', 207, 49, 1422655370, 1422741770);
INSERT INTO `db_bonus_list` VALUES (3758, 'bhbirf906', 221, 45, 1422681674, 1422768074);
INSERT INTO `db_bonus_list` VALUES (3756, 'imkatla', 225, 23, 1422650797, 1422737197);
INSERT INTO `db_bonus_list` VALUES (3755, 'Kastaneda', 155, 85, 1422649889, 1422736289);
INSERT INTO `db_bonus_list` VALUES (3754, 'Lada60', 106, 37, 1422646909, 1422733309);
INSERT INTO `db_bonus_list` VALUES (3753, 'stupak62', 201, 21, 1422644510, 1422730910);
INSERT INTO `db_bonus_list` VALUES (3752, 'sarapul', 198, 50, 1422641409, 1422727809);
INSERT INTO `db_bonus_list` VALUES (3751, 'Aleksandr1', 50, 30, 1422641136, 1422727536);
INSERT INTO `db_bonus_list` VALUES (3750, 'cedoiii83', 150, 11, 1422640277, 1422726677);
INSERT INTO `db_bonus_list` VALUES (3749, 'karolina55', 239, 13, 1422632792, 1422719192);
INSERT INTO `db_bonus_list` VALUES (3748, 'ZET1', 219, 56, 1422630582, 1422716982);
INSERT INTO `db_bonus_list` VALUES (3747, 'volume', 237, 25, 1422630473, 1422716873);
INSERT INTO `db_bonus_list` VALUES (3746, 'FBi59', 246, 53, 1422629367, 1422715767);
INSERT INTO `db_bonus_list` VALUES (3740, 'kukanik', 194, 68, 1422612388, 1422698788);
INSERT INTO `db_bonus_list` VALUES (3738, 'sint', 193, 25, 1422610859, 1422697259);
INSERT INTO `db_bonus_list` VALUES (3739, 'rj3111', 85, 33, 1422611708, 1422698108);
INSERT INTO `db_bonus_list` VALUES (3737, 'toys', 243, 16, 1422610346, 1422696746);
INSERT INTO `db_bonus_list` VALUES (3736, 'slava3201', 212, 20, 1422608262, 1422694662);
INSERT INTO `db_bonus_list` VALUES (3735, 'denplast', 135, 11, 1422605501, 1422691901);
INSERT INTO `db_bonus_list` VALUES (3734, 'vasiadfhz', 92, 18, 1422604278, 1422690678);
INSERT INTO `db_bonus_list` VALUES (3733, 'pijik68', 122, 27, 1422604146, 1422690546);
INSERT INTO `db_bonus_list` VALUES (3732, 'olegator74', 232, 51, 1422603542, 1422689942);
INSERT INTO `db_bonus_list` VALUES (3731, 'Yfnfkbz', 215, 10, 1422603283, 1422689683);
INSERT INTO `db_bonus_list` VALUES (3730, 'mixail', 148, 23, 1422603151, 1422689551);
INSERT INTO `db_bonus_list` VALUES (3718, 'Admin', 1, 52, 1422561587, 1422647987);
INSERT INTO `db_bonus_list` VALUES (3719, 'imkatla', 225, 13, 1422563770, 1422650170);
INSERT INTO `db_bonus_list` VALUES (3720, 'Best', 63, 11, 1422563820, 1422650220);
INSERT INTO `db_bonus_list` VALUES (3721, 'bhbirf906', 221, 44, 1422564297, 1422650697);
INSERT INTO `db_bonus_list` VALUES (3722, 'FLINT333', 84, 70, 1422565154, 1422651554);
INSERT INTO `db_bonus_list` VALUES (3723, 'fktrc906', 209, 74, 1422566388, 1422652788);
INSERT INTO `db_bonus_list` VALUES (3724, 'palpalyh', 231, 64, 1422583767, 1422670167);
INSERT INTO `db_bonus_list` VALUES (3725, 'GetLens', 216, 68, 1422592146, 1422678546);
INSERT INTO `db_bonus_list` VALUES (3726, 'w2mwwm', 183, 49, 1422598536, 1422684936);
INSERT INTO `db_bonus_list` VALUES (3727, 'shpionka', 166, 88, 1422601435, 1422687835);
INSERT INTO `db_bonus_list` VALUES (3728, 'mimi877', 105, 15, 1422602018, 1422688418);
INSERT INTO `db_bonus_list` VALUES (3729, 'lema', 242, 37, 1422602553, 1422688953);
INSERT INTO `db_bonus_list` VALUES (4084, 'andron1144', 250, 21, 1423759667, 1423846067);
INSERT INTO `db_bonus_list` VALUES (4083, 'tornadosta', 260, 56, 1423754724, 1423841124);
INSERT INTO `db_bonus_list` VALUES (4082, 'rj3111', 85, 14, 1423754458, 1423840858);
INSERT INTO `db_bonus_list` VALUES (4081, 'valter', 192, 20, 1423745618, 1423832018);
INSERT INTO `db_bonus_list` VALUES (4080, 'mixail', 148, 12, 1423742600, 1423829000);
INSERT INTO `db_bonus_list` VALUES (4079, 'stupak2691', 275, 17, 1423737814, 1423824214);
INSERT INTO `db_bonus_list` VALUES (4078, 'palpalyh', 231, 22, 1423736016, 1423822416);
INSERT INTO `db_bonus_list` VALUES (4077, 'kukanik', 194, 22, 1423733880, 1423820280);
INSERT INTO `db_bonus_list` VALUES (4076, 'denplast', 135, 36, 1423729056, 1423815456);
INSERT INTO `db_bonus_list` VALUES (4075, 'amince', 244, 39, 1423728938, 1423815338);
INSERT INTO `db_bonus_list` VALUES (4074, 'shpionka', 166, 43, 1423728169, 1423814569);
INSERT INTO `db_bonus_list` VALUES (4073, 'w2mwwm', 183, 10, 1423727282, 1423813682);
INSERT INTO `db_bonus_list` VALUES (4072, 'ZET1', 219, 15, 1423725911, 1423812311);
INSERT INTO `db_bonus_list` VALUES (4071, 'tverdun927', 280, 45, 1423725802, 1423812202);
INSERT INTO `db_bonus_list` VALUES (4070, 'mimi877', 105, 16, 1423724857, 1423811257);
INSERT INTO `db_bonus_list` VALUES (4069, 'toys', 243, 48, 1423719477, 1423805877);
INSERT INTO `db_bonus_list` VALUES (4068, 'Bakeshi', 281, 20, 1423710020, 1423796420);
INSERT INTO `db_bonus_list` VALUES (4067, 'Nogar', 213, 59, 1423699410, 1423785810);
INSERT INTO `db_bonus_list` VALUES (4066, 'Kastaneda', 155, 44, 1423695424, 1423781824);
INSERT INTO `db_bonus_list` VALUES (4065, 'bhbirf906', 221, 28, 1423685696, 1423772096);
INSERT INTO `db_bonus_list` VALUES (4064, 'volume', 237, 11, 1423685595, 1423771995);
INSERT INTO `db_bonus_list` VALUES (4063, 'SUMRAC', 277, 59, 1423685231, 1423771631);
INSERT INTO `db_bonus_list` VALUES (4062, 'mishanja30', 271, 43, 1423684062, 1423770462);
INSERT INTO `db_bonus_list` VALUES (4061, 'imkatla', 225, 16, 1423682491, 1423768891);
INSERT INTO `db_bonus_list` VALUES (4060, 'mitya777', 295, 52, 1423681953, 1423768353);
INSERT INTO `db_bonus_list` VALUES (4059, 'cariden', 270, 46, 1423673958, 1423760358);
INSERT INTO `db_bonus_list` VALUES (4058, 'Mixaluch', 228, 17, 1423672501, 1423758901);
INSERT INTO `db_bonus_list` VALUES (4057, 'GetLens', 216, 22, 1423670972, 1423757372);
INSERT INTO `db_bonus_list` VALUES (4056, 'Evgeniy888', 279, 19, 1423665383, 1423751783);
INSERT INTO `db_bonus_list` VALUES (4055, 'rj3111', 85, 17, 1423665381, 1423751781);
INSERT INTO `db_bonus_list` VALUES (4054, 'smirn59', 126, 10, 1423664771, 1423751171);
INSERT INTO `db_bonus_list` VALUES (4053, 'tornadosta', 260, 34, 1423655320, 1423741720);
INSERT INTO `db_bonus_list` VALUES (4052, 'Vagan', 253, 78, 1423654776, 1423741176);
INSERT INTO `db_bonus_list` VALUES (4051, 'palpalyh', 231, 18, 1423649582, 1423735982);
INSERT INTO `db_bonus_list` VALUES (4050, 'fktrc906', 209, 24, 1423644736, 1423731136);
INSERT INTO `db_bonus_list` VALUES (4049, 'denplast', 135, 14, 1423642537, 1423728937);
INSERT INTO `db_bonus_list` VALUES (4048, 'kukanik', 194, 68, 1423642368, 1423728768);
INSERT INTO `db_bonus_list` VALUES (4047, 'w2mwwm', 183, 11, 1423640639, 1423727039);
INSERT INTO `db_bonus_list` VALUES (4046, 'shpionka', 166, 14, 1423635529, 1423721929);
INSERT INTO `db_bonus_list` VALUES (4045, 'ZET1', 219, 16, 1423635436, 1423721836);
INSERT INTO `db_bonus_list` VALUES (4044, 'toys', 243, 10, 1423627502, 1423713902);
INSERT INTO `db_bonus_list` VALUES (4043, 'Romka92', 294, 14, 1423620728, 1423707128);
INSERT INTO `db_bonus_list` VALUES (4042, 'Kastaneda', 155, 71, 1423606628, 1423693028);
INSERT INTO `db_bonus_list` VALUES (4041, 'tverdun927', 280, 32, 1423599538, 1423685938);
INSERT INTO `db_bonus_list` VALUES (4040, 'bhbirf906', 221, 12, 1423599166, 1423685566);
INSERT INTO `db_bonus_list` VALUES (4039, 'SUMRAC', 277, 38, 1423597674, 1423684074);
INSERT INTO `db_bonus_list` VALUES (4038, 'volume', 237, 83, 1423595882, 1423682282);
INSERT INTO `db_bonus_list` VALUES (4037, 'Bakeshi', 281, 19, 1423593109, 1423679509);
INSERT INTO `db_bonus_list` VALUES (4036, 'imkatla', 225, 27, 1423592502, 1423678902);
INSERT INTO `db_bonus_list` VALUES (4035, 'mixail', 148, 10, 1423589956, 1423676356);
INSERT INTO `db_bonus_list` VALUES (4034, 'cariden', 270, 55, 1423586932, 1423673332);
INSERT INTO `db_bonus_list` VALUES (4033, 'rj3111', 85, 43, 1423576389, 1423662789);
INSERT INTO `db_bonus_list` VALUES (4032, 'sarapul', 198, 28, 1423575838, 1423662238);
INSERT INTO `db_bonus_list` VALUES (4031, 'Evgeniy888', 279, 20, 1423572067, 1423658467);
INSERT INTO `db_bonus_list` VALUES (4030, 'amince', 244, 61, 1423566177, 1423652577);
INSERT INTO `db_bonus_list` VALUES (4029, 'mimi877', 105, 32, 1423565314, 1423651714);
INSERT INTO `db_bonus_list` VALUES (4028, 'tornadosta', 260, 31, 1423564596, 1423650996);
INSERT INTO `db_bonus_list` VALUES (4027, 'palpalyh', 231, 11, 1423560589, 1423646989);
INSERT INTO `db_bonus_list` VALUES (4026, 'levft', 180, 86, 1423560190, 1423646590);
INSERT INTO `db_bonus_list` VALUES (4025, 'Vagan', 253, 12, 1423558768, 1423645168);
INSERT INTO `db_bonus_list` VALUES (4024, 'w2mwwm', 183, 12, 1423554110, 1423640510);
INSERT INTO `db_bonus_list` VALUES (4023, 'stupak62', 201, 10, 1423549221, 1423635621);
INSERT INTO `db_bonus_list` VALUES (4022, 'ZET1', 219, 47, 1423544506, 1423630906);
INSERT INTO `db_bonus_list` VALUES (4021, 'Nogar', 213, 57, 1423522467, 1423608867);
INSERT INTO `db_bonus_list` VALUES (4020, 'annaolga', 187, 46, 1423521632, 1423608032);
INSERT INTO `db_bonus_list` VALUES (4019, 'bhbirf906', 221, 60, 1423512391, 1423598791);
INSERT INTO `db_bonus_list` VALUES (4018, 'soso', 291, 49, 1423511413, 1423597813);
INSERT INTO `db_bonus_list` VALUES (4017, 'Best', 63, 49, 1423510366, 1423596766);
INSERT INTO `db_bonus_list` VALUES (4016, 'Mixaluch', 228, 16, 1423507817, 1423594217);
INSERT INTO `db_bonus_list` VALUES (4015, 'imkatla', 225, 18, 1423505941, 1423592341);
INSERT INTO `db_bonus_list` VALUES (4014, 'Bakeshi', 281, 56, 1423504474, 1423590874);
INSERT INTO `db_bonus_list` VALUES (4013, 'Kastaneda', 155, 36, 1423500779, 1423587179);
INSERT INTO `db_bonus_list` VALUES (4012, 'vitaminka', 185, 27, 1423498433, 1423584833);
INSERT INTO `db_bonus_list` VALUES (4011, 'GetLens', 216, 31, 1423497869, 1423584269);
INSERT INTO `db_bonus_list` VALUES (4010, 'volume', 237, 15, 1423493276, 1423579676);
INSERT INTO `db_bonus_list` VALUES (4009, 'andron1144', 250, 26, 1423489018, 1423575418);
INSERT INTO `db_bonus_list` VALUES (4008, 'cariden', 270, 29, 1423488623, 1423575023);
INSERT INTO `db_bonus_list` VALUES (4007, 'toys', 243, 14, 1423487685, 1423574085);
INSERT INTO `db_bonus_list` VALUES (4006, 'rj3111', 85, 26, 1423480898, 1423567298);
INSERT INTO `db_bonus_list` VALUES (4005, 'tornadosta', 260, 61, 1423474240, 1423560640);
INSERT INTO `db_bonus_list` VALUES (4004, 'shpionka', 166, 45, 1423473476, 1423559876);
INSERT INTO `db_bonus_list` VALUES (4003, 'Vagan', 253, 22, 1423471281, 1423557681);
INSERT INTO `db_bonus_list` VALUES (4002, 'kukanik', 194, 65, 1423471216, 1423557616);
INSERT INTO `db_bonus_list` VALUES (4001, 'palpalyh', 231, 16, 1423471169, 1423557569);
INSERT INTO `db_bonus_list` VALUES (4000, 'amince', 244, 12, 1423469459, 1423555859);
INSERT INTO `db_bonus_list` VALUES (3999, 'denplast', 135, 13, 1423468703, 1423555103);
INSERT INTO `db_bonus_list` VALUES (3998, 'w2mwwm', 183, 34, 1423467503, 1423553903);
INSERT INTO `db_bonus_list` VALUES (3997, 'bananan', 95, 15, 1423450202, 1423536602);
INSERT INTO `db_bonus_list` VALUES (3996, 'ganne', 283, 35, 1423446520, 1423532920);
INSERT INTO `db_bonus_list` VALUES (3995, 'udovitskiy', 268, 55, 1423430982, 1423517382);
INSERT INTO `db_bonus_list` VALUES (3994, 'KOLJUNJA', 161, 63, 1423430407, 1423516807);
INSERT INTO `db_bonus_list` VALUES (3993, 'SUMRAC', 277, 59, 1423430123, 1423516523);
INSERT INTO `db_bonus_list` VALUES (3992, 'Evgeniy888', 279, 10, 1423428050, 1423514450);
INSERT INTO `db_bonus_list` VALUES (3991, 'sarapul', 198, 10, 1423427462, 1423513862);
INSERT INTO `db_bonus_list` VALUES (3990, 'bhbirf906', 221, 70, 1423425721, 1423512121);
INSERT INTO `db_bonus_list` VALUES (3989, 'mixail', 148, 20, 1423420686, 1423507086);
INSERT INTO `db_bonus_list` VALUES (3988, 'tsttst', 181, 39, 1423418269, 1423504669);
INSERT INTO `db_bonus_list` VALUES (3987, 'Bakeshi', 281, 13, 1423415708, 1423502108);
INSERT INTO `db_bonus_list` VALUES (3986, 'GetLens', 216, 90, 1423409842, 1423496242);
INSERT INTO `db_bonus_list` VALUES (3985, 'Mixaluch', 228, 24, 1423408600, 1423495000);
INSERT INTO `db_bonus_list` VALUES (3984, 'mimi877', 105, 12, 1423399943, 1423486343);
INSERT INTO `db_bonus_list` VALUES (3983, 'tverdun927', 280, 12, 1423397141, 1423483541);
INSERT INTO `db_bonus_list` VALUES (3982, 'mishanja30', 271, 54, 1423392648, 1423479048);
INSERT INTO `db_bonus_list` VALUES (3981, 'ZET1', 219, 51, 1423392263, 1423478663);
INSERT INTO `db_bonus_list` VALUES (3980, 'cariden', 270, 66, 1423389758, 1423476158);
INSERT INTO `db_bonus_list` VALUES (3979, 'rj3111', 85, 75, 1423388287, 1423474687);
INSERT INTO `db_bonus_list` VALUES (3978, 'dens', 217, 14, 1423386092, 1423472492);
INSERT INTO `db_bonus_list` VALUES (3977, 'shpionka', 166, 47, 1423384706, 1423471106);
INSERT INTO `db_bonus_list` VALUES (3976, 'Vagan', 253, 23, 1423384456, 1423470856);
INSERT INTO `db_bonus_list` VALUES (3975, 'amince', 244, 23, 1423382478, 1423468878);
INSERT INTO `db_bonus_list` VALUES (3974, 'w2mwwm', 183, 17, 1423380591, 1423466991);
INSERT INTO `db_bonus_list` VALUES (3973, 'denplast', 135, 20, 1423377784, 1423464184);
INSERT INTO `db_bonus_list` VALUES (3972, 'kukanik', 194, 40, 1423377166, 1423463566);
INSERT INTO `db_bonus_list` VALUES (3971, 'toys', 243, 42, 1423376607, 1423463007);
INSERT INTO `db_bonus_list` VALUES (3970, 'karolina55', 239, 72, 1423373832, 1423460232);
INSERT INTO `db_bonus_list` VALUES (3969, 'Kastaneda', 155, 14, 1423348204, 1423434604);
INSERT INTO `db_bonus_list` VALUES (3968, 'tornadosta', 260, 10, 1423342911, 1423429311);
INSERT INTO `db_bonus_list` VALUES (3967, 'bhbirf906', 221, 21, 1423339141, 1423425541);
INSERT INTO `db_bonus_list` VALUES (3966, 'volume', 237, 29, 1423338844, 1423425244);
INSERT INTO `db_bonus_list` VALUES (3965, 'mixail', 148, 50, 1423332520, 1423418920);
INSERT INTO `db_bonus_list` VALUES (3964, 'palpalyh', 231, 29, 1423329327, 1423415727);
INSERT INTO `db_bonus_list` VALUES (3963, 'stupak62', 201, 39, 1423326042, 1423412442);
INSERT INTO `db_bonus_list` VALUES (3962, 'izadora', 284, 40, 1423325508, 1423411908);
INSERT INTO `db_bonus_list` VALUES (3961, 'GetLens', 216, 12, 1423323188, 1423409588);
INSERT INTO `db_bonus_list` VALUES (3960, 'udovitskiy', 268, 68, 1423318064, 1423404464);
INSERT INTO `db_bonus_list` VALUES (3959, 'a100500q', 252, 16, 1423299769, 1423386169);
INSERT INTO `db_bonus_list` VALUES (3958, 'tverdun927', 280, 48, 1423298977, 1423385377);
INSERT INTO `db_bonus_list` VALUES (3957, 'cariden', 270, 13, 1423298718, 1423385118);
INSERT INTO `db_bonus_list` VALUES (3956, 'Bakeshi', 281, 10, 1423294244, 1423380644);
INSERT INTO `db_bonus_list` VALUES (3955, 'w2mwwm', 183, 69, 1423293621, 1423380021);
INSERT INTO `db_bonus_list` VALUES (3954, 'mimi877', 105, 44, 1423292383, 1423378783);
INSERT INTO `db_bonus_list` VALUES (3953, 'Mixaluch', 228, 23, 1423281564, 1423367964);
INSERT INTO `db_bonus_list` VALUES (3952, 'Nogar', 213, 36, 1423269055, 1423355455);
INSERT INTO `db_bonus_list` VALUES (3951, 'ganne', 283, 22, 1423268060, 1423354460);
INSERT INTO `db_bonus_list` VALUES (3950, 'Evgeniy888', 279, 51, 1423264267, 1423350667);
INSERT INTO `db_bonus_list` VALUES (3949, 'tornadosta', 260, 33, 1423256420, 1423342820);
INSERT INTO `db_bonus_list` VALUES (3948, 'dens', 217, 14, 1423253851, 1423340251);
INSERT INTO `db_bonus_list` VALUES (3947, 'bhbirf906', 221, 20, 1423252386, 1423338786);
INSERT INTO `db_bonus_list` VALUES (3946, 'karolina55', 239, 46, 1423251777, 1423338177);
INSERT INTO `db_bonus_list` VALUES (3945, 'SUMRAC', 277, 72, 1423248426, 1423334826);
INSERT INTO `db_bonus_list` VALUES (3944, 'ZET1', 219, 25, 1423244279, 1423330679);
INSERT INTO `db_bonus_list` VALUES (3943, 'iris1502', 204, 43, 1423241828, 1423328228);
INSERT INTO `db_bonus_list` VALUES (3942, 'mixail', 148, 46, 1423241252, 1423327652);
INSERT INTO `db_bonus_list` VALUES (3941, 'aleksana', 172, 31, 1423233780, 1423320180);
INSERT INTO `db_bonus_list` VALUES (3940, 'tanda13', 96, 32, 1423232102, 1423318502);
INSERT INTO `db_bonus_list` VALUES (3939, 'levft', 180, 12, 1423226652, 1423313052);
INSERT INTO `db_bonus_list` VALUES (3938, 'vitaminka', 185, 13, 1423223399, 1423309799);
INSERT INTO `db_bonus_list` VALUES (3937, 'imkatla', 225, 18, 1423220567, 1423306967);
INSERT INTO `db_bonus_list` VALUES (3936, 'rj3111', 85, 33, 1423219975, 1423306375);
INSERT INTO `db_bonus_list` VALUES (3935, 'Vagan', 253, 13, 1423218924, 1423305324);
INSERT INTO `db_bonus_list` VALUES (3934, 'denplast', 135, 22, 1423218213, 1423304613);
INSERT INTO `db_bonus_list` VALUES (3933, 'missklv', 282, 21, 1423217578, 1423303978);
INSERT INTO `db_bonus_list` VALUES (3932, 'cariden', 270, 33, 1423212282, 1423298682);
INSERT INTO `db_bonus_list` VALUES (3931, 'w2mwwm', 183, 21, 1423207204, 1423293604);
INSERT INTO `db_bonus_list` VALUES (3930, 'toys', 243, 65, 1423206336, 1423292736);
INSERT INTO `db_bonus_list` VALUES (3929, 'shpionka', 166, 11, 1423204119, 1423290519);
INSERT INTO `db_bonus_list` VALUES (3928, 'mishanja30', 271, 54, 1423202965, 1423289365);
INSERT INTO `db_bonus_list` VALUES (3927, 'palpalyh', 231, 28, 1423199892, 1423286292);
INSERT INTO `db_bonus_list` VALUES (3926, 'kukanik', 194, 11, 1423195446, 1423281846);
INSERT INTO `db_bonus_list` VALUES (3925, 'Mixaluch', 228, 47, 1423195160, 1423281560);
INSERT INTO `db_bonus_list` VALUES (3924, 'GetLens', 216, 61, 1423194482, 1423280882);
INSERT INTO `db_bonus_list` VALUES (3923, 'Bakeshi', 281, 13, 1423192298, 1423278698);
INSERT INTO `db_bonus_list` VALUES (3922, 'tverdun927', 280, 31, 1423173197, 1423259597);
INSERT INTO `db_bonus_list` VALUES (3921, 'KOLJUNJA', 161, 21, 1423172258, 1423258658);
INSERT INTO `db_bonus_list` VALUES (3920, 'Kastaneda', 155, 77, 1423171415, 1423257815);
INSERT INTO `db_bonus_list` VALUES (3919, 'volume', 237, 13, 1423170345, 1423256745);
INSERT INTO `db_bonus_list` VALUES (3918, 'stupak62', 201, 18, 1423165924, 1423252324);
INSERT INTO `db_bonus_list` VALUES (3917, 'bhbirf906', 221, 79, 1423165460, 1423251860);
INSERT INTO `db_bonus_list` VALUES (3916, 'Deit15', 207, 18, 1423164048, 1423250448);
INSERT INTO `db_bonus_list` VALUES (3915, 'Evgeniy888', 279, 34, 1423163157, 1423249557);
INSERT INTO `db_bonus_list` VALUES (3914, 'sarapul', 198, 31, 1423158688, 1423245088);
INSERT INTO `db_bonus_list` VALUES (3913, 'karolina55', 239, 12, 1423158335, 1423244735);
INSERT INTO `db_bonus_list` VALUES (3912, 'tornadosta', 260, 29, 1423158228, 1423244628);
INSERT INTO `db_bonus_list` VALUES (3911, 'Asasins123', 278, 49, 1423155112, 1423241512);
INSERT INTO `db_bonus_list` VALUES (3910, 'treder', 73, 63, 1423151075, 1423237475);
INSERT INTO `db_bonus_list` VALUES (3909, 'kelmonda', 196, 48, 1423149243, 1423235643);
INSERT INTO `db_bonus_list` VALUES (3908, 'olegator74', 232, 16, 1423146658, 1423233058);
INSERT INTO `db_bonus_list` VALUES (3907, 'SUMRAC', 277, 11, 1423139332, 1423225732);
INSERT INTO `db_bonus_list` VALUES (3906, 'denplast', 135, 42, 1423131584, 1423217984);
INSERT INTO `db_bonus_list` VALUES (3905, 'imkatla', 225, 18, 1423130895, 1423217295);
INSERT INTO `db_bonus_list` VALUES (3904, 'iris1502', 204, 65, 1423129518, 1423215918);
INSERT INTO `db_bonus_list` VALUES (3903, 'mixail', 148, 26, 1423128866, 1423215266);
INSERT INTO `db_bonus_list` VALUES (3902, 'Vagan', 253, 10, 1423124357, 1423210757);
INSERT INTO `db_bonus_list` VALUES (3901, 'mimi877', 105, 34, 1423123608, 1423210008);
INSERT INTO `db_bonus_list` VALUES (3900, 'amince', 244, 22, 1423123600, 1423210000);
INSERT INTO `db_bonus_list` VALUES (3899, 'w2mwwm', 183, 50, 1423120737, 1423207137);
INSERT INTO `db_bonus_list` VALUES (3898, 'toys', 243, 35, 1423117136, 1423203536);
INSERT INTO `db_bonus_list` VALUES (3897, 'palpalyh', 231, 58, 1423113068, 1423199468);
INSERT INTO `db_bonus_list` VALUES (3896, 'ZET1', 219, 26, 1423102540, 1423188940);
INSERT INTO `db_bonus_list` VALUES (3895, 'Nogar', 213, 43, 1423091428, 1423177828);
INSERT INTO `db_bonus_list` VALUES (3894, 'brost', 81, 47, 1423087884, 1423174284);
INSERT INTO `db_bonus_list` VALUES (3893, 'bananan', 95, 12, 1423086115, 1423172515);
INSERT INTO `db_bonus_list` VALUES (3892, 'rj3111', 85, 12, 1423079189, 1423165589);
INSERT INTO `db_bonus_list` VALUES (3891, 'cariden', 270, 21, 1423077289, 1423163689);
INSERT INTO `db_bonus_list` VALUES (3890, 'bhbirf906', 221, 17, 1423077151, 1423163551);
INSERT INTO `db_bonus_list` VALUES (3889, 'Deit15', 207, 27, 1423074230, 1423160630);
INSERT INTO `db_bonus_list` VALUES (3888, 'volume', 237, 44, 1423073041, 1423159441);
INSERT INTO `db_bonus_list` VALUES (3887, 'tornadosta', 260, 57, 1423070339, 1423156739);
INSERT INTO `db_bonus_list` VALUES (3886, 'stupak2691', 275, 56, 1423067057, 1423153457);
INSERT INTO `db_bonus_list` VALUES (3885, 'dima12321', 274, 13, 1423067056, 1423153456);
INSERT INTO `db_bonus_list` VALUES (3884, 'Mixaluch', 228, 42, 1423063421, 1423149821);
INSERT INTO `db_bonus_list` VALUES (3883, 'vitaminka', 185, 57, 1423061730, 1423148130);
INSERT INTO `db_bonus_list` VALUES (3882, 'kukanik', 194, 22, 1423058953, 1423145353);
INSERT INTO `db_bonus_list` VALUES (3881, 'udacha2802', 102, 20, 1423053549, 1423139949);
INSERT INTO `db_bonus_list` VALUES (3880, 'GetLens', 216, 10, 1423049799, 1423136199);
INSERT INTO `db_bonus_list` VALUES (3879, 'shpionka', 166, 39, 1423046351, 1423132751);
INSERT INTO `db_bonus_list` VALUES (3878, 'denplast', 135, 32, 1423044790, 1423131190);
INSERT INTO `db_bonus_list` VALUES (3877, 'imkatla', 225, 14, 1423043293, 1423129693);
INSERT INTO `db_bonus_list` VALUES (3876, 'w2mwwm', 183, 35, 1423034309, 1423120709);
INSERT INTO `db_bonus_list` VALUES (3875, 'dens', 217, 64, 1423034065, 1423120465);
INSERT INTO `db_bonus_list` VALUES (3874, 'toys', 243, 17, 1423025866, 1423112266);
INSERT INTO `db_bonus_list` VALUES (3873, 'palpalyh', 231, 22, 1423025814, 1423112214);
INSERT INTO `db_bonus_list` VALUES (3872, 'RUSSkir', 156, 12, 1423025327, 1423111727);
INSERT INTO `db_bonus_list` VALUES (3871, 'ZET1', 219, 21, 1423009086, 1423095486);
INSERT INTO `db_bonus_list` VALUES (3870, 'karolina55', 239, 21, 1423004002, 1423090402);
INSERT INTO `db_bonus_list` VALUES (3869, 'mishanja30', 271, 41, 1422999973, 1423086373);
INSERT INTO `db_bonus_list` VALUES (3868, 'tanda13', 96, 37, 1422999836, 1423086236);
INSERT INTO `db_bonus_list` VALUES (3867, 'Kastaneda', 155, 43, 1422998549, 1423084949);
INSERT INTO `db_bonus_list` VALUES (3866, 'KOLJUNJA', 161, 37, 1422992362, 1423078762);
INSERT INTO `db_bonus_list` VALUES (3865, '23232323', 129, 19, 1422991789, 1423078189);
INSERT INTO `db_bonus_list` VALUES (3864, 'rj3111', 85, 21, 1422990997, 1423077397);
INSERT INTO `db_bonus_list` VALUES (3863, 'bhbirf906', 221, 15, 1422989865, 1423076265);
INSERT INTO `db_bonus_list` VALUES (3862, 'oksolin', 189, 83, 1422989129, 1423075529);
INSERT INTO `db_bonus_list` VALUES (3861, 'cariden', 270, 22, 1422984704, 1423071104);
INSERT INTO `db_bonus_list` VALUES (3860, 'mixail', 148, 83, 1422982628, 1423069028);
INSERT INTO `db_bonus_list` VALUES (3859, 'vitya1998', 76, 26, 1422980424, 1423066824);
INSERT INTO `db_bonus_list` VALUES (3858, 'tornadosta', 260, 38, 1422980010, 1423066410);
INSERT INTO `db_bonus_list` VALUES (3857, 'stupak62', 201, 20, 1422979487, 1423065887);
INSERT INTO `db_bonus_list` VALUES (3856, 'olegator74', 232, 44, 1422978382, 1423064782);
INSERT INTO `db_bonus_list` VALUES (3855, 'mimi877', 105, 41, 1422976958, 1423063358);
INSERT INTO `db_bonus_list` VALUES (3854, 'zorin', 165, 12, 1422975867, 1423062267);
INSERT INTO `db_bonus_list` VALUES (3853, 'andron1144', 250, 10, 1422972713, 1423059113);
INSERT INTO `db_bonus_list` VALUES (3852, 'bodev', 269, 61, 1422972062, 1423058462);
INSERT INTO `db_bonus_list` VALUES (3851, 'kukanik', 194, 13, 1422970801, 1423057201);
INSERT INTO `db_bonus_list` VALUES (3850, 'udovitskiy', 268, 11, 1422967294, 1423053694);
INSERT INTO `db_bonus_list` VALUES (3849, 'Kizil', 88, 67, 1422966522, 1423052922);
INSERT INTO `db_bonus_list` VALUES (3848, 'shpionka', 166, 88, 1422959692, 1423046092);
INSERT INTO `db_bonus_list` VALUES (3847, 'denplast', 135, 31, 1422957304, 1423043704);
INSERT INTO `db_bonus_list` VALUES (3846, 'imkatla', 225, 30, 1422955614, 1423042014);
INSERT INTO `db_bonus_list` VALUES (3845, 'lema', 242, 22, 1422953655, 1423040055);
INSERT INTO `db_bonus_list` VALUES (3844, 'w2mwwm', 183, 48, 1422945614, 1423032014);
INSERT INTO `db_bonus_list` VALUES (3843, 'iris1502', 204, 63, 1422944213, 1423030613);
INSERT INTO `db_bonus_list` VALUES (3842, 'palpalyh', 231, 37, 1422937421, 1423023821);
INSERT INTO `db_bonus_list` VALUES (3841, 'vitaminka', 185, 20, 1422934106, 1423020506);
INSERT INTO `db_bonus_list` VALUES (3840, 'volume', 237, 51, 1422916783, 1423003183);
INSERT INTO `db_bonus_list` VALUES (3839, 'ZET1', 219, 10, 1422907893, 1422994293);
INSERT INTO `db_bonus_list` VALUES (3838, 'karolina55', 239, 30, 1422906782, 1422993182);
INSERT INTO `db_bonus_list` VALUES (3837, 'dens', 217, 12, 1422905013, 1422991413);
INSERT INTO `db_bonus_list` VALUES (3836, 'Mixaluch', 228, 77, 1422904833, 1422991233);
INSERT INTO `db_bonus_list` VALUES (3835, 'rty6ty', 267, 17, 1422900506, 1422986906);
INSERT INTO `db_bonus_list` VALUES (3834, 'toys', 243, 17, 1422898198, 1422984598);
INSERT INTO `db_bonus_list` VALUES (3833, 'rj3111', 85, 18, 1422896862, 1422983262);
INSERT INTO `db_bonus_list` VALUES (3832, 'pijik68', 122, 16, 1422881461, 1422967861);
INSERT INTO `db_bonus_list` VALUES (3831, 'oksolin', 189, 37, 1422874502, 1422960902);
INSERT INTO `db_bonus_list` VALUES (3830, 'aleksana', 172, 32, 1422874151, 1422960551);
INSERT INTO `db_bonus_list` VALUES (3829, 'shpionka', 166, 76, 1422873191, 1422959591);
INSERT INTO `db_bonus_list` VALUES (3828, 'andron1144', 250, 19, 1422872808, 1422959208);
INSERT INTO `db_bonus_list` VALUES (3827, 'tornadosta', 260, 16, 1422870473, 1422956873);
INSERT INTO `db_bonus_list` VALUES (3826, 'udacha2802', 102, 11, 1422869775, 1422956175);
INSERT INTO `db_bonus_list` VALUES (3825, 'denplast', 135, 33, 1422869529, 1422955929);
INSERT INTO `db_bonus_list` VALUES (3824, 'imkatla', 225, 45, 1422866806, 1422953206);
INSERT INTO `db_bonus_list` VALUES (3823, 'Denis69', 130, 20, 1422866418, 1422952818);
INSERT INTO `db_bonus_list` VALUES (3822, 'Best', 63, 11, 1422858248, 1422944648);
INSERT INTO `db_bonus_list` VALUES (3821, 'stupak62', 201, 15, 1422851675, 1422938075);
INSERT INTO `db_bonus_list` VALUES (3820, 'romka', 235, 12, 1422850840, 1422937240);
INSERT INTO `db_bonus_list` VALUES (3819, 'morr', 265, 24, 1422847001, 1422933401);
INSERT INTO `db_bonus_list` VALUES (3818, 'Nogar', 213, 40, 1422832716, 1422919116);
INSERT INTO `db_bonus_list` VALUES (3817, 'volume', 237, 21, 1422828567, 1422914967);
INSERT INTO `db_bonus_list` VALUES (3816, 'fktrc906', 209, 14, 1422828278, 1422914678);
INSERT INTO `db_bonus_list` VALUES (3815, 'FeeLing', 263, 25, 1422823711, 1422910111);
INSERT INTO `db_bonus_list` VALUES (3814, 'RUSSkir', 156, 70, 1422822789, 1422909189);
INSERT INTO `db_bonus_list` VALUES (3813, 'mixail', 148, 40, 1422822544, 1422908944);
INSERT INTO `db_bonus_list` VALUES (3812, 'Kastaneda', 155, 32, 1422821947, 1422908347);
INSERT INTO `db_bonus_list` VALUES (3811, 'karolina55', 239, 23, 1422819669, 1422906069);
INSERT INTO `db_bonus_list` VALUES (3810, '77777', 113, 17, 1422817796, 1422904196);
INSERT INTO `db_bonus_list` VALUES (3809, 'piratka', 170, 46, 1422817732, 1422904132);
INSERT INTO `db_bonus_list` VALUES (3808, 'vlad64', 139, 10, 1422816072, 1422902472);
INSERT INTO `db_bonus_list` VALUES (3807, 'GetLens', 216, 25, 1422809373, 1422895773);
INSERT INTO `db_bonus_list` VALUES (3806, 'iris1502', 204, 14, 1422808796, 1422895196);
INSERT INTO `db_bonus_list` VALUES (3805, 'kukanik', 194, 10, 1422805157, 1422891557);
INSERT INTO `db_bonus_list` VALUES (3804, 'rj3111', 85, 16, 1422801860, 1422888260);
INSERT INTO `db_bonus_list` VALUES (3803, 'toys', 243, 10, 1422800312, 1422886712);
INSERT INTO `db_bonus_list` VALUES (3802, 'MishelSCH', 87, 15, 1422794447, 1422880847);
INSERT INTO `db_bonus_list` VALUES (3801, 'Aleksandr1', 50, 50, 1422794287, 1422880687);
INSERT INTO `db_bonus_list` VALUES (3800, 'vigenpt', 160, 58, 1422793857, 1422880257);
INSERT INTO `db_bonus_list` VALUES (3799, 'FLINT333', 84, 12, 1422791346, 1422877746);
INSERT INTO `db_bonus_list` VALUES (3798, 'sarapul', 198, 14, 1422786682, 1422873082);
INSERT INTO `db_bonus_list` VALUES (3797, 'shpionka', 166, 20, 1422786233, 1422872633);
INSERT INTO `db_bonus_list` VALUES (3796, 'andron1144', 250, 17, 1422786092, 1422872492);
INSERT INTO `db_bonus_list` VALUES (3795, 'mimi877', 105, 16, 1422783225, 1422869625);
INSERT INTO `db_bonus_list` VALUES (3794, 'denplast', 135, 11, 1422781721, 1422868121);
INSERT INTO `db_bonus_list` VALUES (3793, 'olegator74', 232, 66, 1422775854, 1422862254);
INSERT INTO `db_bonus_list` VALUES (3792, 'amince', 244, 51, 1422775556, 1422861956);
INSERT INTO `db_bonus_list` VALUES (3791, 'Denis69', 130, 13, 1422773044, 1422859444);
INSERT INTO `db_bonus_list` VALUES (3790, 'Lada60', 106, 27, 1422772994, 1422859394);
INSERT INTO `db_bonus_list` VALUES (3789, 'w2mwwm', 183, 10, 1422771962, 1422858362);
INSERT INTO `db_bonus_list` VALUES (3788, 'bhbirf906', 221, 11, 1422768831, 1422855231);
INSERT INTO `db_bonus_list` VALUES (3787, 'ZET1', 219, 29, 1422742634, 1422829034);
INSERT INTO `db_bonus_list` VALUES (3786, 'imkatla', 225, 16, 1422740788, 1422827188);
INSERT INTO `db_bonus_list` VALUES (3785, 'fktrc906', 209, 45, 1422739163, 1422825563);
INSERT INTO `db_bonus_list` VALUES (3784, 'snezhana', 234, 44, 1422737420, 1422823820);
INSERT INTO `db_bonus_list` VALUES (3783, 'Best', 63, 98, 1422730094, 1422816494);
INSERT INTO `db_bonus_list` VALUES (3782, 'Mixaluch', 228, 41, 1422728586, 1422814986);
INSERT INTO `db_bonus_list` VALUES (3781, 'Gennadiy77', 257, 45, 1422726618, 1422813018);
INSERT INTO `db_bonus_list` VALUES (3780, 'volume', 237, 17, 1422724146, 1422810546);
INSERT INTO `db_bonus_list` VALUES (3779, 'Erejep', 245, 41, 1422719964, 1422806364);
INSERT INTO `db_bonus_list` VALUES (3778, 'Doshs', 256, 21, 1422718907, 1422805307);
INSERT INTO `db_bonus_list` VALUES (3777, 'xxx555', 255, 37, 1422717632, 1422804032);
INSERT INTO `db_bonus_list` VALUES (3776, 'rj3111', 85, 10, 1422711845, 1422798245);
INSERT INTO `db_bonus_list` VALUES (3775, 'Vagan', 253, 19, 1422711096, 1422797496);
INSERT INTO `db_bonus_list` VALUES (3774, 'GetLens', 216, 29, 1422707981, 1422794381);
INSERT INTO `db_bonus_list` VALUES (3773, 'Swent', 140, 36, 1422707199, 1422793599);
INSERT INTO `db_bonus_list` VALUES (3772, 'kukanik', 194, 48, 1422706357, 1422792757);
INSERT INTO `db_bonus_list` VALUES (3771, 'CrazyLegen', 236, 12, 1422706028, 1422792428);
INSERT INTO `db_bonus_list` VALUES (3770, 'vitaminka', 185, 12, 1422704671, 1422791071);
INSERT INTO `db_bonus_list` VALUES (3769, 'iris1502', 204, 36, 1422701319, 1422787719);
INSERT INTO `db_bonus_list` VALUES (3768, 'shpionka', 166, 33, 1422699821, 1422786221);
INSERT INTO `db_bonus_list` VALUES (3767, 'a100500q', 252, 17, 1422699488, 1422785888);
INSERT INTO `db_bonus_list` VALUES (3766, 'scorpion66', 251, 40, 1422696781, 1422783181);
INSERT INTO `db_bonus_list` VALUES (3765, 'andron1144', 250, 84, 1422695523, 1422781923);
INSERT INTO `db_bonus_list` VALUES (3764, 'denplast', 135, 47, 1422693947, 1422780347);
INSERT INTO `db_bonus_list` VALUES (3763, 'mimi877', 105, 63, 1422693122, 1422779522);
INSERT INTO `db_bonus_list` VALUES (3762, 'swerg', 249, 43, 1422691468, 1422777868);
INSERT INTO `db_bonus_list` VALUES (3761, 'valter', 192, 70, 1422685390, 1422771790);
INSERT INTO `db_bonus_list` VALUES (3760, 'w2mwwm', 183, 22, 1422685140, 1422771540);
INSERT INTO `db_bonus_list` VALUES (4085, 'piratka', 170, 18, 1423760051, 1423846451);
INSERT INTO `db_bonus_list` VALUES (4086, 'GetLens', 216, 29, 1423761331, 1423847731);
INSERT INTO `db_bonus_list` VALUES (4087, 'imkatla', 225, 53, 1423771219, 1423857619);
INSERT INTO `db_bonus_list` VALUES (4088, 'SUMRAC', 277, 59, 1423771841, 1423858241);
INSERT INTO `db_bonus_list` VALUES (4089, 'bhbirf906', 221, 10, 1423772906, 1423859306);
INSERT INTO `db_bonus_list` VALUES (4090, 'ganne', 283, 32, 1423777240, 1423863640);
INSERT INTO `db_bonus_list` VALUES (4091, 'Evgeniy888', 279, 10, 1423777359, 1423863759);
INSERT INTO `db_bonus_list` VALUES (4092, 'tanda13', 96, 23, 1423784355, 1423870755);
INSERT INTO `db_bonus_list` VALUES (4093, 'stupak62', 201, 20, 1423798982, 1423885382);
INSERT INTO `db_bonus_list` VALUES (4094, 'Bakeshi', 281, 51, 1423806117, 1423892517);
INSERT INTO `db_bonus_list` VALUES (4095, 'w2mwwm', 183, 48, 1423813930, 1423900330);
INSERT INTO `db_bonus_list` VALUES (4096, 'denplast', 135, 61, 1423816505, 1423902905);
INSERT INTO `db_bonus_list` VALUES (4097, 'cariden', 270, 24, 1423819633, 1423906033);
INSERT INTO `db_bonus_list` VALUES (4098, 'alexsoft59', 297, 20, 1423819985, 1423906385);
INSERT INTO `db_bonus_list` VALUES (4099, 'shpionka', 166, 36, 1423824559, 1423910959);
INSERT INTO `db_bonus_list` VALUES (4100, 'palpalyh', 231, 10, 1423826416, 1423912816);
INSERT INTO `db_bonus_list` VALUES (4101, 'volume', 237, 38, 1423827883, 1423914283);
INSERT INTO `db_bonus_list` VALUES (4102, 'kukanik', 194, 10, 1423831118, 1423917518);
INSERT INTO `db_bonus_list` VALUES (4103, 'Vagan', 253, 28, 1423839223, 1423925623);
INSERT INTO `db_bonus_list` VALUES (4104, 'Mixaluch', 228, 30, 1423844601, 1423931001);
INSERT INTO `db_bonus_list` VALUES (4105, 'Admin', 1, 55, 1462611690, 1462698090);
INSERT INTO `db_bonus_list` VALUES (4106, 'MegaScript', 299, 66, 1462619061, 1462705461);
INSERT INTO `db_bonus_list` VALUES (4107, 'Admin', 1, 13, 1464025496, 1464111896);
INSERT INTO `db_bonus_list` VALUES (4108, 'romdik', 300, 13, 1473091310, 1473177710);
INSERT INTO `db_bonus_list` VALUES (4109, 'romdik', 300, 30, 1473225910, 1473312310);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_competition`
-- 

CREATE TABLE `db_competition` (
  `id` int(11) NOT NULL auto_increment,
  `1m` double NOT NULL default '0',
  `2m` double NOT NULL default '0',
  `3m` double NOT NULL default '0',
  `user_1` varchar(10) NOT NULL default '',
  `user_2` varchar(10) NOT NULL default '',
  `user_3` varchar(10) NOT NULL default '',
  `status` int(1) NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  `date_end` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=11 ;

-- 
-- ���� ������ ������� `db_competition`
-- 


-- --------------------------------------------------------

-- 
-- ��������� ������� `db_competition_users`
-- 

CREATE TABLE `db_competition_users` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(10) NOT NULL default '',
  `user_id` int(11) NOT NULL default '0',
  `points` double NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=6 ;

-- 
-- ���� ������ ������� `db_competition_users`
-- 


-- --------------------------------------------------------

-- 
-- ��������� ������� `db_conabrul`
-- 

CREATE TABLE `db_conabrul` (
  `id` int(11) NOT NULL auto_increment,
  `rules` text NOT NULL,
  `about` text NOT NULL,
  `contacts` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

-- 
-- ���� ������ ������� `db_conabrul`
-- 

INSERT INTO `db_conabrul` VALUES (1, '<strong>Общие Положения</strong><br /> <br />\r\n\r\n\r\n<strong>1.</strong> Зарегистрировавшись на проекте, Вы соглашаетесь с данными  правилами в полном объёме. Аккаунты пользователей, которые грубо  нарушили правила проекта, восстановлению не подлежат. Степень нарушений  определяется администрацией.<br /> \r\n\r\n<strong>2.</strong> Администрация не несёт ответственности за возможный ущерб, нанесённый Вам в результате использования данного проекта.<br /> \r\n\r\n<strong>3.</strong> В случае игнорирования данных правил или их несоблюдения  аккаунт подлежит блокировке или, в случае грубых нарушений, удалению.  Денежные средства нарушителям не возвращаются.<br /> \r\n\r\n<strong>4.</strong> Администрация может вносить в эти правила изменения без предупреждения пользователей.<br /> \r\n\r\n<strong>5.</strong> Администрация не несёт ответственности за возможный взлом  аккаунтов. Для того, чтобы не позволить злоумышленникам проникать в свои  аккаунты, необходимо использовать на проекте уникальный, нигде ранее не  указываемый Вами, пароль, состоящий при этом из множества символов.<br /> \r\n\r\n<strong>6.</strong> Регистрируясь на проекте, пользователь соглашается быть  чьим-либо партнером, и обязуется не выражать свои претензии по этому  поводу администрации.<br /> \r\n\r\n<strong>7.</strong> При оплате каких-либо услуг, а затем отказа от их использования, денежные средства не возвращаются.<br />\r\n\r\n<br /><br /><strong>Обязаности Проекта<br /></strong><br /> \r\n\r\n<strong>1.</strong> Сохранять конфиденциальность информации зарегистрированного пользователя, полученной от него при регистрации.<br /> \r\n\r\n<strong>2.</strong> При возникновении технических проблем возобновить работу проекта в течении 5-х суток.<br /> \r\n\r\n<strong>3.</strong> Выплачивать денежные средства пользователям в течении 3-х суток, с момента заказа выплаты.<br />\r\n\r\n<strong>4.</strong> Отвечать на письма, присланные в службу технической поддержки в течении 24-х часов. <br /><br /> \r\n\r\n<strong>Обязаности пользователей<br /></strong><br /> \r\n\r\n<strong>1.</strong> При регистрации указывать правдивую информацию во всех полях регистрационной формы.<br /> \r\n\r\n<strong>2.</strong> Знакомиться с данными правилами минимум один раз в месяц.<br /> <strong>3.3.</strong> Не выводить средства более чем с трёх аккаунтов на один кошелёк.<br /> \r\n\r\n<strong>3.</strong> При обнаружении неисправностей либо некоторых погрешностей проекта сообщать в службу поддержки.<br /> \r\n\r\n<strong>4.</strong> Не проводить попыток взлома проекта и не использовать возможные ошибки.<br /> \r\n\r\n<strong>5.</strong> Не публиковать оскорбительных сообщений, клевету и иные виды сообщений, портящих репутацию проекта или пользователей.<br /> \r\n\r\n<strong>6.</strong> Не выражать недовольство по поводу проекта и его работы, не спорить с администрацией, не попрошайничать.<br /> \r\n\r\n<strong>7.</strong> Не обвинять администрацию, не угрожать ей и не оказывать давление, не отправлять спам на почту.<br /> \r\n\r\n<strong>8.</strong> Заходить в свой аккаунт минимум один раз в месяц.<br /> ', '«Пираты Карибского Моря» — это новая экономическая онлайн игра. Вы зарабатываете игровые деньги - а выводите реальные!<br><br>\n\n1. Заходите в ''Рынок'' и покупаете корабль.<br>\n2. Ждем 10 минут и ''забираем прибыль''.<br>\n3. ''Продаем золото'' и получаем реальные деньги.<br><br>\n\nКурс обмена: 150 золота = 1 рубль<br><br>\n\nВы можете выводить деньги с проекта, либо приобрести еще больше кораблей, чтобы они приносили вам еще больше прибыли!<br><br>\n\nНо и главное, не забывайте приглашать в игру всех Ваших друзей и знакомых! Это поможет Вам заработать еще больше денег и получать разнообразные призы от нашего проекта!', 'По поводу технических и финансовых проблем обращайтесь по контактам технической поддержки:<br><br>\r\n\r\n<strong>E-mail</strong>: <span>yura.boss@yandex.ua</span><br>  <strong><span style="color: blue;">Skype</span></strong>: admin.superoc</p>\r\n<p style="font-size: 12px;">*Обращаясь в тех. поддержку не забудьте указать свой никнейм, ID и  e-mail на проекте, это может значительно ускорить скорость решения  проблемы.</p>\r\n<p>Вопросы относительно системы игры, а также идеи, пожелания и замечния просьба писать в официальной группе проекта:<br /> <strong>Мы ВКонтакте</strong>: <a href="http://vk.com/club84236902" target="_blank">vk.com/piratescaribbea</a></p>');

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_config`
-- 

CREATE TABLE `db_config` (
  `id` int(11) NOT NULL auto_increment,
  `admin` varchar(10) NOT NULL default '',
  `pass` varchar(20) NOT NULL default '',
  `min_pay` double NOT NULL default '15',
  `ser_per_wmr` int(11) NOT NULL default '1000',
  `ser_per_wmz` int(11) NOT NULL default '3300',
  `ser_per_wme` int(11) NOT NULL default '4200',
  `percent_swap` int(11) NOT NULL default '0',
  `percent_sell` int(2) NOT NULL default '10',
  `items_per_coin` int(11) NOT NULL default '7',
  `a_in_h` int(11) NOT NULL default '0',
  `b_in_h` int(11) NOT NULL default '0',
  `c_in_h` int(11) NOT NULL default '0',
  `d_in_h` int(11) NOT NULL default '0',
  `e_in_h` int(11) NOT NULL default '0',
  `amount_a_t` int(11) NOT NULL default '0',
  `amount_b_t` int(11) NOT NULL default '0',
  `amount_c_t` int(11) NOT NULL default '0',
  `amount_d_t` int(11) NOT NULL default '0',
  `amount_e_t` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

-- 
-- ���� ������ ������� `db_config`
-- 

INSERT INTO `db_config` VALUES (1, 'adminsuper', 'gandonvonnaxyulolka', 20, 100, 3300, 4200, 5, 35, 150, 7, 70, 370, 1920, 9650, 100, 1000, 5000, 25000, 100000);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_games_knb`
-- 

CREATE TABLE `db_games_knb` (
  `id` int(11) NOT NULL auto_increment,
  `summa` decimal(7,2) NOT NULL default '0.00',
  `item` int(1) NOT NULL default '0',
  `login` varchar(10) NOT NULL default '',
  `dat` datetime NOT NULL default '0000-00-00 00:00:00',
  `last` int(1) NOT NULL default '0',
  `gamer` varchar(10) NOT NULL default '',
  `win` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=182 DEFAULT CHARSET=utf8 AUTO_INCREMENT=182 ;

-- 
-- ���� ������ ������� `db_games_knb`
-- 

INSERT INTO `db_games_knb` VALUES (181, 10.00, 1, 'Admin', '2016-05-07 14:21:54', 0, '', 0);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_insert_money`
-- 

CREATE TABLE `db_insert_money` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(10) NOT NULL default '',
  `user_id` int(11) NOT NULL default '0',
  `money` double NOT NULL default '0',
  `serebro` int(11) NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  `date_del` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=35 ;

-- 
-- ���� ������ ������� `db_insert_money`
-- 


-- --------------------------------------------------------

-- 
-- ��������� ������� `db_news`
-- 

CREATE TABLE `db_news` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `news` text NOT NULL,
  `date_add` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=6 ;

-- 
-- ���� ������ ������� `db_news`
-- 

INSERT INTO `db_news` VALUES (4, '�������', '������ �������� http://moneyscript.ru/', 1473083505);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_payeer_insert`
-- 

CREATE TABLE `db_payeer_insert` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `user` varchar(10) NOT NULL default '',
  `sum` double NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  `days` varchar(55) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=212 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=212 ;

-- 
-- ���� ������ ������� `db_payeer_insert`
-- 

INSERT INTO `db_payeer_insert` VALUES (196, 249, 'swerg', 5, 1423054366, 0, '1423140766');
INSERT INTO `db_payeer_insert` VALUES (195, 273, 'chelton085', 5, 1423037736, 0, '1425629736');
INSERT INTO `db_payeer_insert` VALUES (194, 272, '2069321', 0, 1423037490, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (193, 203, 'jayzy', 5, 1422949598, 0, '1425541598');
INSERT INTO `db_payeer_insert` VALUES (192, 249, 'swerg', 0, 1422830545, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (191, 148, 'mixail', 5, 1422822599, 0, '1425414599');
INSERT INTO `db_payeer_insert` VALUES (190, 258, 'galstya', 5, 1422798655, 0, '1414072255');
INSERT INTO `db_payeer_insert` VALUES (189, 256, 'Doshs', 0, 1422718886, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (188, 255, 'xxx555', 1, 1422717782, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (187, 252, 'a100500q', 100, 1422700014, 1, '0');
INSERT INTO `db_payeer_insert` VALUES (186, 201, 'stupak62', 251, 1422644762, 1, '0');
INSERT INTO `db_payeer_insert` VALUES (185, 201, 'stupak62', 250, 1422644741, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (184, 201, 'stupak62', 10, 1422644714, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (183, 201, 'stupak62', 251, 1422644657, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (182, 245, 'Erejep', 0, 1422628983, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (181, 243, 'toys', 5, 1422610215, 1, '1422696615');
INSERT INTO `db_payeer_insert` VALUES (180, 243, 'toys', 200, 1422609880, 1, '0');
INSERT INTO `db_payeer_insert` VALUES (179, 166, 'shpionka', 500, 1422606350, 1, '0');
INSERT INTO `db_payeer_insert` VALUES (178, 242, 'lema', 5, 1422602576, 0, '1422688976');
INSERT INTO `db_payeer_insert` VALUES (203, 297, 'alexsoft59', 0, 1423820295, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (202, 292, 'maks2108', 0, 1423562781, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (201, 288, 'Diknoa', 0, 1423497470, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (200, 287, 'admin1', 10, 1423487776, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (199, 287, 'admin1', 10, 1423487761, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (198, 280, 'tverdun927', 5, 1423434917, 0, '1423521317');
INSERT INTO `db_payeer_insert` VALUES (197, 1, 'Admin', 100, 1423307124, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (204, 1, 'Admin', 0, 1462619575, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (205, 1, 'Admin', 0, 1462619611, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (206, 1, 'Admin', 0, 1462619621, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (207, 1, 'Admin', 0, 1462619630, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (208, 1, 'Admin', 0, 1462619653, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (209, 1, 'Admin', 0, 1462619667, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (210, 1, 'Admin', 0, 1462619693, 0, '0');
INSERT INTO `db_payeer_insert` VALUES (211, 1, 'Admin', 643, 1462619730, 0, '0');

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_payment`
-- 

CREATE TABLE `db_payment` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(10) NOT NULL default '',
  `user_id` int(11) NOT NULL default '0',
  `purse` varchar(20) NOT NULL default '',
  `sum` double NOT NULL default '0',
  `comission` double NOT NULL default '0',
  `valuta` char(3) NOT NULL default 'RUB',
  `serebro` int(11) NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  `pay_sys` varchar(100) NOT NULL default '0',
  `pay_sys_id` int(11) NOT NULL default '0',
  `response` int(1) NOT NULL default '0',
  `payment_id` int(11) NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  `date_del` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=87 ;

-- 
-- ���� ������ ������� `db_payment`
-- 

INSERT INTO `db_payment` VALUES (68, 'shpionka', 166, 'P11845349', 0.51, 0, 'RUB', 51, 3, '0', 0, 0, 41945922, 1422609365, 0);
INSERT INTO `db_payment` VALUES (76, 'stupak62', 201, 'P12576989', 1.2, 0, 'RUB', 120, 3, '0', 0, 0, 42094174, 1422697489, 0);
INSERT INTO `db_payment` VALUES (77, 'shpionka', 166, 'P11845349', 16.52, 0, 'RUB', 1652, 3, '0', 0, 0, 42100021, 1422699903, 0);
INSERT INTO `db_payment` VALUES (78, 'shpionka', 166, 'P11845349', 15.9, 0, 'RUB', 1590, 3, '0', 0, 0, 42239150, 1422786406, 0);
INSERT INTO `db_payment` VALUES (79, 'Admin', 1, 'P3022977', 4.56, 0, 'RUB', 456, 3, '0', 0, 0, 42267879, 1422799180, 0);
INSERT INTO `db_payment` VALUES (80, 'stupak62', 201, 'P12576989', 3.9, 0, 'RUB', 390, 3, '0', 0, 0, 42341620, 1422851798, 0);
INSERT INTO `db_payment` VALUES (83, 'Admin', 1, 'P2186234', 5, 0, 'RUB', 500, 3, '0', 0, 0, 42453937, 1422904464, 0);
INSERT INTO `db_payment` VALUES (82, 'shpionka', 166, 'P11845349', 16.13, 0, 'RUB', 1613, 3, '0', 0, 0, 42377038, 1422873226, 0);
INSERT INTO `db_payment` VALUES (84, 'shpionka', 166, 'P11845349', 16.19, 0, 'RUB', 1619, 3, '0', 0, 0, 42524943, 1422959709, 0);
INSERT INTO `db_payment` VALUES (85, 'shpionka', 166, 'P11845349', 16.35, 0, 'RUB', 1635, 3, '0', 0, 0, 42670679, 1423046371, 0);
INSERT INTO `db_payment` VALUES (86, 'shpionka', 166, 'P11845349', 16.45, 0, 'RUB', 1645, 3, '0', 0, 0, 42816703, 1423132905, 0);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_recovery`
-- 

CREATE TABLE `db_recovery` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(50) NOT NULL default '',
  `ip` int(10) unsigned NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  `date_del` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=7 ;

-- 
-- ���� ������ ������� `db_recovery`
-- 

INSERT INTO `db_recovery` VALUES (6, 'kentavr190@yandex.ru', 627256495, 1422792515, 1422793415);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_regkey`
-- 

CREATE TABLE `db_regkey` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(50) NOT NULL default '',
  `referer_id` int(11) NOT NULL default '0',
  `referer_name` varchar(10) NOT NULL default '',
  `date_add` int(11) NOT NULL default '0',
  `date_del` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- 
-- ���� ������ ������� `db_regkey`
-- 


-- --------------------------------------------------------

-- 
-- ��������� ������� `db_sell_items`
-- 

CREATE TABLE `db_sell_items` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(10) NOT NULL default '',
  `user_id` int(11) NOT NULL default '0',
  `a_s` int(11) NOT NULL default '0',
  `b_s` int(11) NOT NULL default '0',
  `c_s` int(11) NOT NULL default '0',
  `d_s` int(11) NOT NULL default '0',
  `e_s` int(11) NOT NULL default '0',
  `amount` double NOT NULL default '0',
  `all_sell` int(11) NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  `date_del` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1542 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1542 ;

-- 
-- ���� ������ ������� `db_sell_items`
-- 

INSERT INTO `db_sell_items` VALUES (1108, 'volume', 237, 1082, 0, 0, 0, 0, 7.21, 1082, 1422779788, 1424075788);
INSERT INTO `db_sell_items` VALUES (1109, 'bhbirf906', 221, 122, 0, 0, 0, 0, 0.81, 122, 1422780596, 1424076596);
INSERT INTO `db_sell_items` VALUES (1107, 'a100500q', 252, 58, 582, 308, 0, 0, 6.32, 948, 1422778000, 1424074000);
INSERT INTO `db_sell_items` VALUES (1105, 'kukanik', 194, 196, 0, 0, 0, 0, 1.31, 196, 1422774349, 1424070349);
INSERT INTO `db_sell_items` VALUES (1106, 'a100500q', 252, 2044, 27250, 0, 0, 0, 195.29, 29294, 1422776505, 1424072505);
INSERT INTO `db_sell_items` VALUES (1104, 'shpionka', 166, 5973, 6636, 42873, 40450, 203304, 1994.91, 299236, 1422770211, 1424066211);
INSERT INTO `db_sell_items` VALUES (1103, 'bhbirf906', 221, 46, 0, 0, 0, 0, 0.31, 46, 1422770105, 1424066105);
INSERT INTO `db_sell_items` VALUES (1102, 'bhbirf906', 221, 505, 0, 0, 0, 0, 3.37, 505, 1422765428, 1424061428);
INSERT INTO `db_sell_items` VALUES (1100, 'w2mwwm', 183, 178, 0, 0, 0, 0, 1.19, 178, 1422741591, 1424037591);
INSERT INTO `db_sell_items` VALUES (1101, 'ZET1', 219, 295, 0, 0, 0, 0, 1.97, 295, 1422742684, 1424038684);
INSERT INTO `db_sell_items` VALUES (1099, 'fktrc906', 209, 168, 0, 0, 0, 0, 1.12, 168, 1422739133, 1424035133);
INSERT INTO `db_sell_items` VALUES (1098, 'rj3111', 85, 51, 506, 0, 0, 0, 3.71, 557, 1422737893, 1424033893);
INSERT INTO `db_sell_items` VALUES (1096, 'shpionka', 166, 1994, 2361, 15253, 14391, 72332, 708.87, 106331, 1422732287, 1424028287);
INSERT INTO `db_sell_items` VALUES (1097, 'scorpion66', 251, 61, 0, 0, 0, 0, 0.41, 61, 1422733041, 1424029041);
INSERT INTO `db_sell_items` VALUES (1095, 'volume', 237, 643, 0, 0, 0, 0, 4.29, 643, 1422724152, 1424020152);
INSERT INTO `db_sell_items` VALUES (1093, 'Erejep', 245, 178, 0, 0, 0, 0, 1.19, 178, 1422720028, 1424016028);
INSERT INTO `db_sell_items` VALUES (1094, 'kukanik', 194, 34, 0, 0, 0, 0, 0.23, 34, 1422724054, 1424020054);
INSERT INTO `db_sell_items` VALUES (1092, 'shpionka', 166, 2581, 3318, 21438, 20226, 101657, 994.8, 149220, 1422718796, 1424014796);
INSERT INTO `db_sell_items` VALUES (1091, 'w2mwwm', 183, 181, 0, 0, 0, 0, 1.21, 181, 1422718714, 1424014714);
INSERT INTO `db_sell_items` VALUES (1090, 'bhbirf906', 221, 83, 0, 0, 0, 0, 0.55, 83, 1422713461, 1424009461);
INSERT INTO `db_sell_items` VALUES (1089, 'rj3111', 85, 96, 964, 0, 0, 0, 7.07, 1060, 1422711855, 1424007855);
INSERT INTO `db_sell_items` VALUES (1088, 'a100500q', 252, 96, 1274, 0, 0, 0, 9.13, 1370, 1422706435, 1424002435);
INSERT INTO `db_sell_items` VALUES (1087, 'kukanik', 194, 56, 0, 0, 0, 0, 0.37, 56, 1422706370, 1424002370);
INSERT INTO `db_sell_items` VALUES (1086, 'a100500q', 252, 71, 948, 0, 0, 0, 6.79, 1019, 1422703157, 1423999157);
INSERT INTO `db_sell_items` VALUES (1084, 'scorpion66', 251, 10, 0, 0, 0, 0, 0.07, 10, 1422701856, 1423997856);
INSERT INTO `db_sell_items` VALUES (1085, 'bhbirf906', 221, 17, 0, 0, 0, 0, 0.11, 17, 1422702811, 1423998811);
INSERT INTO `db_sell_items` VALUES (1083, 'a100500q', 252, 8, 262, 0, 0, 0, 1.8, 270, 1422700719, 1423996719);
INSERT INTO `db_sell_items` VALUES (1071, 'rj3111', 85, 0, 840, 0, 0, 0, 5.6, 840, 1422662284, 1423958284);
INSERT INTO `db_sell_items` VALUES (1072, 'w2mwwm', 183, 128, 0, 0, 0, 0, 0.85, 128, 1422680244, 1423976244);
INSERT INTO `db_sell_items` VALUES (1073, 'bhbirf906', 221, 196, 0, 0, 0, 0, 1.31, 196, 1422682687, 1423978687);
INSERT INTO `db_sell_items` VALUES (1074, 'volume', 237, 419, 0, 0, 0, 0, 2.79, 419, 1422682788, 1423978788);
INSERT INTO `db_sell_items` VALUES (1075, 'shpionka', 166, 4812, 7000, 50873, 47998, 241239, 2346.15, 351922, 1422684692, 1423980692);
INSERT INTO `db_sell_items` VALUES (1076, 'w2mwwm', 183, 24, 0, 0, 0, 0, 0.16, 24, 1422686518, 1423982518);
INSERT INTO `db_sell_items` VALUES (1077, 'w2mwwm', 183, 4, 0, 0, 0, 0, 0.03, 4, 1422687599, 1423983599);
INSERT INTO `db_sell_items` VALUES (1078, 'bhbirf906', 221, 38, 0, 0, 0, 0, 0.25, 38, 1422689171, 1423985171);
INSERT INTO `db_sell_items` VALUES (1079, 'bhbirf906', 221, 48, 0, 0, 0, 0, 0.32, 48, 1422697389, 1423993389);
INSERT INTO `db_sell_items` VALUES (1080, 'stupak62', 201, 716, 6138, 48669, 0, 0, 370.15, 55523, 1422697401, 1423993401);
INSERT INTO `db_sell_items` VALUES (1081, 'shpionka', 166, 1767, 2650, 17120, 16153, 81183, 792.49, 118873, 1422699834, 1423995834);
INSERT INTO `db_sell_items` VALUES (1082, 'bhbirf906', 221, 15, 0, 0, 0, 0, 0.1, 15, 1422699907, 1423995907);
INSERT INTO `db_sell_items` VALUES (1517, 'amince', 244, 1948, 0, 0, 0, 0, 12.99, 1948, 1423816641, 1425112641);
INSERT INTO `db_sell_items` VALUES (1518, 'bhbirf906', 221, 1041, 0, 0, 0, 0, 6.94, 1041, 1423816677, 1425112677);
INSERT INTO `db_sell_items` VALUES (1519, 'bhbirf906', 221, 97, 0, 0, 0, 0, 0.65, 97, 1423817862, 1425113862);
INSERT INTO `db_sell_items` VALUES (1520, 'bhbirf906', 221, 140, 0, 0, 0, 0, 0.93, 140, 1423819581, 1425115581);
INSERT INTO `db_sell_items` VALUES (1521, 'bhbirf906', 221, 184, 0, 0, 0, 0, 1.23, 184, 1423821841, 1425117841);
INSERT INTO `db_sell_items` VALUES (1522, 'bhbirf906', 221, 75, 0, 0, 0, 0, 0.5, 75, 1423822762, 1425118762);
INSERT INTO `db_sell_items` VALUES (1523, 'w2mwwm', 183, 485, 0, 0, 0, 0, 3.23, 485, 1423823202, 1425119202);
INSERT INTO `db_sell_items` VALUES (1524, 'tornadosta', 260, 930, 0, 0, 0, 0, 6.2, 930, 1423823845, 1425119845);
INSERT INTO `db_sell_items` VALUES (1525, 'shpionka', 166, 6575, 11476, 19673, 17014, 85515, 935.02, 140253, 1423824574, 1425120574);
INSERT INTO `db_sell_items` VALUES (1526, 'palpalyh', 231, 1054, 0, 0, 0, 0, 7.03, 1054, 1423826401, 1425122401);
INSERT INTO `db_sell_items` VALUES (1527, 'volume', 237, 9948, 0, 0, 0, 0, 66.32, 9948, 1423827895, 1425123895);
INSERT INTO `db_sell_items` VALUES (1528, 'kukanik', 194, 1147, 0, 0, 0, 0, 7.65, 1147, 1423831130, 1425127130);
INSERT INTO `db_sell_items` VALUES (1529, 'bhbirf906', 221, 760, 0, 0, 0, 0, 5.07, 760, 1423831853, 1425127853);
INSERT INTO `db_sell_items` VALUES (1530, 'Vagan', 253, 1435, 0, 0, 0, 0, 9.57, 1435, 1423839236, 1425135236);
INSERT INTO `db_sell_items` VALUES (1515, 'denplast', 135, 1003, 0, 0, 0, 0, 6.69, 1003, 1423814769, 1425110769);
INSERT INTO `db_sell_items` VALUES (1516, 'w2mwwm', 183, 613, 0, 0, 0, 0, 4.09, 613, 1423814895, 1425110895);
INSERT INTO `db_sell_items` VALUES (1514, 'Bakeshi', 281, 76, 0, 0, 0, 0, 0.51, 76, 1423813884, 1425109884);
INSERT INTO `db_sell_items` VALUES (1513, 'shpionka', 166, 23492, 39154, 70956, 61367, 308435, 3356.03, 503404, 1423808623, 1425104623);
INSERT INTO `db_sell_items` VALUES (1512, 'Bakeshi', 281, 681, 0, 0, 0, 0, 4.54, 681, 1423806101, 1425102101);
INSERT INTO `db_sell_items` VALUES (1511, 'w2mwwm', 183, 3511, 0, 0, 0, 0, 23.41, 3511, 1423804392, 1425100392);
INSERT INTO `db_sell_items` VALUES (1510, 'bhbirf906', 221, 2396, 0, 0, 0, 0, 15.97, 2396, 1423803925, 1425099925);
INSERT INTO `db_sell_items` VALUES (1509, 'stupak62', 201, 5828, 43711, 256713, 0, 0, 2041.68, 306252, 1423799018, 1425095018);
INSERT INTO `db_sell_items` VALUES (1508, 'toys', 243, 6466, 24631, 65097, 42225, 0, 922.79, 138419, 1423798514, 1425094514);
INSERT INTO `db_sell_items` VALUES (1507, 'Kastaneda', 155, 993, 0, 0, 0, 0, 6.62, 993, 1423780509, 1425076509);
INSERT INTO `db_sell_items` VALUES (1506, 'Evgeniy888', 279, 653, 0, 0, 0, 0, 4.35, 653, 1423777370, 1425073370);
INSERT INTO `db_sell_items` VALUES (1505, 'ganne', 283, 1286, 0, 0, 0, 0, 8.57, 1286, 1423777265, 1425073265);
INSERT INTO `db_sell_items` VALUES (1504, 'bhbirf906', 221, 1570, 0, 0, 0, 0, 10.47, 1570, 1423773892, 1425069892);
INSERT INTO `db_sell_items` VALUES (1502, 'SUMRAC', 277, 674, 0, 0, 0, 0, 4.49, 674, 1423771814, 1425067814);
INSERT INTO `db_sell_items` VALUES (1503, 'rj3111', 85, 2107, 2107, 0, 0, 0, 28.09, 4214, 1423773734, 1425069734);
INSERT INTO `db_sell_items` VALUES (1501, 'tornadosta', 260, 582, 0, 0, 0, 0, 3.88, 582, 1423770712, 1425066712);
INSERT INTO `db_sell_items` VALUES (1500, 'mitya777', 295, 166, 0, 0, 0, 0, 1.11, 166, 1423767474, 1425063474);
INSERT INTO `db_sell_items` VALUES (1499, 'GetLens', 216, 1055, 0, 0, 0, 0, 7.03, 1055, 1423761340, 1425057340);
INSERT INTO `db_sell_items` VALUES (1498, 'andron1144', 250, 1579, 0, 0, 0, 0, 10.53, 1579, 1423759679, 1425055679);
INSERT INTO `db_sell_items` VALUES (1496, 'kukanik', 194, 178, 0, 0, 0, 0, 1.19, 178, 1423757382, 1425053382);
INSERT INTO `db_sell_items` VALUES (1497, 'tverdun927', 280, 154, 0, 0, 0, 0, 1.03, 154, 1423759536, 1425055536);
INSERT INTO `db_sell_items` VALUES (1495, 'bhbirf906', 221, 1926, 0, 0, 0, 0, 12.84, 1926, 1423754187, 1425050187);
INSERT INTO `db_sell_items` VALUES (1494, 'shpionka', 166, 8964, 15609, 28287, 24464, 122957, 1335.21, 200281, 1423751095, 1425047095);
INSERT INTO `db_sell_items` VALUES (1493, 'volume', 237, 7666, 0, 0, 0, 0, 51.11, 7666, 1423749189, 1425045189);
INSERT INTO `db_sell_items` VALUES (1491, 'w2mwwm', 183, 3766, 0, 0, 0, 0, 25.11, 3766, 1423742122, 1425038122);
INSERT INTO `db_sell_items` VALUES (1492, 'kukanik', 194, 142, 0, 0, 0, 0, 0.95, 142, 1423744284, 1425040284);
INSERT INTO `db_sell_items` VALUES (1490, 'Mixaluch', 228, 6957, 0, 0, 0, 0, 46.38, 6957, 1423741790, 1425037790);
INSERT INTO `db_sell_items` VALUES (1488, 'stupak2691', 275, 1304, 0, 0, 0, 0, 8.69, 1304, 1423737842, 1425033842);
INSERT INTO `db_sell_items` VALUES (1489, 'tverdun927', 280, 27, 0, 0, 0, 0, 0.18, 27, 1423739759, 1425035759);
INSERT INTO `db_sell_items` VALUES (1487, 'tornadosta', 260, 1278, 0, 0, 0, 0, 8.52, 1278, 1423737466, 1425033466);
INSERT INTO `db_sell_items` VALUES (1485, 'palpalyh', 231, 840, 0, 0, 0, 0, 5.6, 840, 1423736029, 1425032029);
INSERT INTO `db_sell_items` VALUES (1486, 'Bakeshi', 281, 253, 0, 0, 0, 0, 1.69, 253, 1423736042, 1425032042);
INSERT INTO `db_sell_items` VALUES (1484, 'kukanik', 194, 1246, 0, 0, 0, 0, 8.31, 1246, 1423733890, 1425029890);
INSERT INTO `db_sell_items` VALUES (1483, 'bhbirf906', 221, 177, 0, 0, 0, 0, 1.18, 177, 1423729421, 1425025421);
INSERT INTO `db_sell_items` VALUES (1482, 'denplast', 135, 1006, 0, 0, 0, 0, 6.71, 1006, 1423728794, 1425024794);
INSERT INTO `db_sell_items` VALUES (1481, 'shpionka', 166, 2869, 5124, 9286, 8031, 40364, 437.83, 65674, 1423728155, 1425024155);
INSERT INTO `db_sell_items` VALUES (1480, 'bhbirf906', 221, 166, 0, 0, 0, 0, 1.11, 166, 1423727097, 1425023097);
INSERT INTO `db_sell_items` VALUES (1479, 'ZET1', 219, 880, 0, 0, 0, 0, 5.87, 880, 1423725922, 1425021922);
INSERT INTO `db_sell_items` VALUES (1477, 'bhbirf906', 221, 691, 0, 0, 0, 0, 4.61, 691, 1423724900, 1425020900);
INSERT INTO `db_sell_items` VALUES (1478, 'tverdun927', 280, 246, 0, 0, 0, 0, 1.64, 246, 1423725870, 1425021870);
INSERT INTO `db_sell_items` VALUES (1476, 'mimi877', 105, 1861, 0, 0, 0, 0, 12.41, 1861, 1423724844, 1425020844);
INSERT INTO `db_sell_items` VALUES (1474, 'toys', 243, 4081, 15547, 41090, 26653, 0, 582.47, 87371, 1423719342, 1425015342);
INSERT INTO `db_sell_items` VALUES (1475, 'shpionka', 166, 32106, 52958, 104970, 90785, 456290, 4914.06, 737109, 1423720626, 1425016626);
INSERT INTO `db_sell_items` VALUES (1473, 'bhbirf906', 221, 2164, 0, 0, 0, 0, 14.43, 2164, 1423715786, 1425011786);
INSERT INTO `db_sell_items` VALUES (1471, 'Nogar', 213, 1032, 0, 0, 0, 0, 6.88, 1032, 1423699395, 1424995395);
INSERT INTO `db_sell_items` VALUES (1472, 'Bakeshi', 281, 558, 0, 0, 0, 0, 3.72, 558, 1423710011, 1425006011);
INSERT INTO `db_sell_items` VALUES (1470, 'Kastaneda', 155, 1036, 0, 0, 0, 0, 6.91, 1036, 1423695415, 1424991415);
INSERT INTO `db_sell_items` VALUES (1469, 'bhbirf906', 221, 262, 0, 0, 0, 0, 1.75, 262, 1423687247, 1424983247);
INSERT INTO `db_sell_items` VALUES (1467, 'SUMRAC', 277, 511, 0, 0, 0, 0, 3.41, 511, 1423685214, 1424981214);
INSERT INTO `db_sell_items` VALUES (1468, 'volume', 237, 4235, 0, 0, 0, 0, 28.23, 4235, 1423685601, 1424981601);
INSERT INTO `db_sell_items` VALUES (1466, 'mishanja30', 271, 567, 0, 0, 0, 0, 3.78, 567, 1423684094, 1424980094);
INSERT INTO `db_sell_items` VALUES (1465, 'bhbirf906', 221, 525, 0, 0, 0, 0, 3.5, 525, 1423683704, 1424979704);
INSERT INTO `db_sell_items` VALUES (1463, 'w2mwwm', 183, 1181, 0, 0, 0, 0, 7.87, 1181, 1423672956, 1424968956);
INSERT INTO `db_sell_items` VALUES (1464, 'bhbirf906', 221, 708, 0, 0, 0, 0, 4.72, 708, 1423676612, 1424972612);
INSERT INTO `db_sell_items` VALUES (1462, 'mixail', 148, 160, 0, 0, 0, 0, 1.07, 160, 1423672501, 1424968501);
INSERT INTO `db_sell_items` VALUES (1460, 'toys', 243, 3421, 13032, 34442, 22341, 0, 488.24, 73236, 1423669374, 1424965374);
INSERT INTO `db_sell_items` VALUES (1461, 'GetLens', 216, 1165, 0, 0, 0, 0, 7.77, 1165, 1423670947, 1424966947);
INSERT INTO `db_sell_items` VALUES (1458, 'Evgeniy888', 279, 544, 0, 0, 0, 0, 3.63, 544, 1423665400, 1424961400);
INSERT INTO `db_sell_items` VALUES (1459, 'bhbirf906', 221, 268, 0, 0, 0, 0, 1.79, 268, 1423666757, 1424962757);
INSERT INTO `db_sell_items` VALUES (1457, 'rj3111', 85, 167, 185, 0, 0, 0, 2.35, 352, 1423665391, 1424961391);
INSERT INTO `db_sell_items` VALUES (1456, 'bhbirf906', 221, 1606, 0, 0, 0, 0, 10.71, 1606, 1423663032, 1424959032);
INSERT INTO `db_sell_items` VALUES (1455, 'rj3111', 85, 1391, 1545, 0, 0, 0, 19.57, 2936, 1423655858, 1424951858);
INSERT INTO `db_sell_items` VALUES (1453, 'Vagan', 253, 410, 0, 0, 0, 0, 2.73, 410, 1423654787, 1424950787);
INSERT INTO `db_sell_items` VALUES (1454, 'tornadosta', 260, 855, 0, 0, 0, 0, 5.7, 855, 1423655328, 1424951328);
INSERT INTO `db_sell_items` VALUES (1452, 'Bakeshi', 281, 70, 0, 0, 0, 0, 0.47, 70, 1423652664, 1424948664);
INSERT INTO `db_sell_items` VALUES (1451, 'w2mwwm', 183, 436, 0, 0, 0, 0, 2.91, 436, 1423650457, 1424946457);
INSERT INTO `db_sell_items` VALUES (1450, 'palpalyh', 231, 865, 0, 0, 0, 0, 5.77, 865, 1423649594, 1424945594);
INSERT INTO `db_sell_items` VALUES (1449, 'volume', 237, 5680, 0, 0, 0, 0, 37.87, 5680, 1423648050, 1424944050);
INSERT INTO `db_sell_items` VALUES (1448, 'Bakeshi', 281, 134, 0, 0, 0, 0, 0.89, 134, 1423645420, 1424941420);
INSERT INTO `db_sell_items` VALUES (1447, 'fktrc906', 209, 1009, 0, 0, 0, 0, 6.73, 1009, 1423644717, 1424940717);
INSERT INTO `db_sell_items` VALUES (1445, 'kukanik', 194, 1997, 0, 0, 0, 0, 13.31, 1997, 1423642378, 1424938378);
INSERT INTO `db_sell_items` VALUES (1446, 'denplast', 135, 859, 0, 0, 0, 0, 5.73, 859, 1423642566, 1424938566);
INSERT INTO `db_sell_items` VALUES (1443, 'bhbirf906', 221, 269, 0, 0, 0, 0, 1.79, 269, 1423640714, 1424936714);
INSERT INTO `db_sell_items` VALUES (1444, 'w2mwwm', 183, 2263, 0, 0, 0, 0, 15.09, 2263, 1423641842, 1424937842);
INSERT INTO `db_sell_items` VALUES (1442, 'bhbirf906', 221, 224, 0, 0, 0, 0, 1.49, 224, 1423636876, 1424932876);
INSERT INTO `db_sell_items` VALUES (1441, 'shpionka', 166, 31534, 48643, 106391, 92014, 462466, 4940.32, 741048, 1423635519, 1424931519);
INSERT INTO `db_sell_items` VALUES (1439, 'bhbirf906', 221, 2351, 0, 0, 0, 0, 15.67, 2351, 1423633666, 1424929666);
INSERT INTO `db_sell_items` VALUES (1440, 'ZET1', 219, 884, 0, 0, 0, 0, 5.89, 884, 1423635447, 1424931447);
INSERT INTO `db_sell_items` VALUES (1438, 'Bakeshi', 281, 31, 0, 0, 0, 0, 0.21, 31, 1423628268, 1424924268);
INSERT INTO `db_sell_items` VALUES (1437, 'toys', 243, 4373, 17730, 49982, 32421, 0, 696.71, 104506, 1423627479, 1424923479);
INSERT INTO `db_sell_items` VALUES (1436, 'Bakeshi', 281, 242, 0, 0, 0, 0, 1.61, 242, 1423624214, 1424920214);
INSERT INTO `db_sell_items` VALUES (1435, 'Kastaneda', 155, 1029, 0, 0, 0, 0, 6.86, 1029, 1423606615, 1424902615);
INSERT INTO `db_sell_items` VALUES (1434, 'tornadosta', 260, 486, 0, 0, 0, 0, 3.24, 486, 1423600337, 1424896337);
INSERT INTO `db_sell_items` VALUES (1433, 'bhbirf906', 221, 101, 0, 0, 0, 0, 0.67, 101, 1423600085, 1424896085);
INSERT INTO `db_sell_items` VALUES (1432, 'tverdun927', 280, 355, 0, 0, 0, 0, 2.37, 355, 1423599565, 1424895565);
INSERT INTO `db_sell_items` VALUES (1430, 'SUMRAC', 277, 652, 0, 0, 0, 0, 4.35, 652, 1423597689, 1424893689);
INSERT INTO `db_sell_items` VALUES (1431, 'bhbirf906', 221, 288, 0, 0, 0, 0, 1.92, 288, 1423598646, 1424894646);
INSERT INTO `db_sell_items` VALUES (1429, 'w2mwwm', 183, 1400, 0, 0, 0, 0, 9.33, 1400, 1423597072, 1424893072);
INSERT INTO `db_sell_items` VALUES (1428, 'volume', 237, 8779, 0, 0, 0, 0, 58.53, 8779, 1423595888, 1424891888);
INSERT INTO `db_sell_items` VALUES (1426, 'Bakeshi', 281, 189, 0, 0, 0, 0, 1.26, 189, 1423593126, 1424889126);
INSERT INTO `db_sell_items` VALUES (1427, 'bhbirf906', 221, 253, 0, 0, 0, 0, 1.69, 253, 1423594537, 1424890537);
INSERT INTO `db_sell_items` VALUES (1425, 'bhbirf906', 221, 1486, 0, 0, 0, 0, 9.91, 1486, 1423590817, 1424886817);
INSERT INTO `db_sell_items` VALUES (1424, 'mixail', 148, 223, 0, 0, 0, 0, 1.49, 223, 1423589978, 1424885978);
INSERT INTO `db_sell_items` VALUES (1423, 'Vagan', 253, 660, 0, 0, 0, 0, 4.4, 660, 1423584519, 1424880519);
INSERT INTO `db_sell_items` VALUES (1421, 'sarapul', 198, 289, 0, 0, 0, 0, 1.93, 289, 1423575873, 1424871873);
INSERT INTO `db_sell_items` VALUES (1422, 'rj3111', 85, 1485, 1857, 0, 0, 0, 22.28, 3342, 1423576398, 1424872398);
INSERT INTO `db_sell_items` VALUES (1420, 'Evgeniy888', 279, 560, 0, 0, 0, 0, 3.73, 560, 1423572079, 1424868079);
INSERT INTO `db_sell_items` VALUES (1419, 'GetLens', 216, 711, 0, 0, 0, 0, 4.74, 711, 1423571063, 1424867063);
INSERT INTO `db_sell_items` VALUES (1418, 'bhbirf906', 221, 176, 0, 0, 0, 0, 1.17, 176, 1423568972, 1424864972);
INSERT INTO `db_sell_items` VALUES (1417, 'Bakeshi', 281, 7, 0, 0, 0, 0, 0.05, 7, 1423568845, 1424864845);
INSERT INTO `db_sell_items` VALUES (1416, 'w2mwwm', 183, 957, 0, 0, 0, 0, 6.38, 957, 1423568264, 1424864264);
INSERT INTO `db_sell_items` VALUES (1415, 'Bakeshi', 281, 14, 0, 0, 0, 0, 0.09, 14, 1423567918, 1424863918);
INSERT INTO `db_sell_items` VALUES (1413, 'bhbirf906', 221, 1217, 0, 0, 0, 0, 8.11, 1217, 1423566308, 1424862308);
INSERT INTO `db_sell_items` VALUES (1414, 'toys', 243, 5686, 23050, 64980, 42149, 0, 905.77, 135865, 1423566690, 1424862690);
INSERT INTO `db_sell_items` VALUES (1412, 'amince', 244, 564, 0, 0, 0, 0, 3.76, 564, 1423566236, 1424862236);
INSERT INTO `db_sell_items` VALUES (1410, 'mimi877', 105, 1608, 0, 0, 0, 0, 10.72, 1608, 1423565323, 1424861323);
INSERT INTO `db_sell_items` VALUES (1411, 'Bakeshi', 281, 57, 0, 0, 0, 0, 0.38, 57, 1423565491, 1424861491);
INSERT INTO `db_sell_items` VALUES (1409, 'tornadosta', 260, 657, 0, 0, 0, 0, 4.38, 657, 1423564608, 1424860608);
INSERT INTO `db_sell_items` VALUES (1407, 'Bakeshi', 281, 72, 0, 0, 0, 0, 0.48, 72, 1423555759, 1424851759);
INSERT INTO `db_sell_items` VALUES (1408, 'palpalyh', 231, 695, 0, 0, 0, 0, 4.63, 695, 1423560606, 1424856606);
INSERT INTO `db_sell_items` VALUES (1406, 'denplast', 135, 831, 0, 0, 0, 0, 5.54, 831, 1423554215, 1424850215);
INSERT INTO `db_sell_items` VALUES (1405, 'shpionka', 166, 20716, 30071, 70643, 61097, 307074, 3264.01, 489601, 1423549252, 1424845252);
INSERT INTO `db_sell_items` VALUES (1404, 'stupak62', 201, 5208, 39057, 229383, 0, 0, 1824.32, 273648, 1423549245, 1424845245);
INSERT INTO `db_sell_items` VALUES (1402, 'w2mwwm', 183, 3569, 0, 0, 0, 0, 23.79, 3569, 1423547761, 1424843761);
INSERT INTO `db_sell_items` VALUES (1403, 'bhbirf906', 221, 182, 0, 0, 0, 0, 1.21, 182, 1423547904, 1424843904);
INSERT INTO `db_sell_items` VALUES (1400, 'ZET1', 219, 1184, 0, 0, 0, 0, 7.89, 1184, 1423544518, 1424840518);
INSERT INTO `db_sell_items` VALUES (1401, 'bhbirf906', 221, 1986, 0, 0, 0, 0, 13.24, 1986, 1423545083, 1424841083);
INSERT INTO `db_sell_items` VALUES (1399, 'Bakeshi', 281, 228, 0, 0, 0, 0, 1.52, 228, 1423543483, 1424839483);
INSERT INTO `db_sell_items` VALUES (1398, 'Best', 63, 126, 0, 0, 0, 0, 0.84, 126, 1423542624, 1424838624);
INSERT INTO `db_sell_items` VALUES (1396, 'tornadosta', 260, 573, 0, 0, 0, 0, 3.82, 573, 1423516335, 1424812335);
INSERT INTO `db_sell_items` VALUES (1397, 'Nogar', 213, 328, 0, 0, 0, 0, 2.19, 328, 1423522450, 1424818450);
INSERT INTO `db_sell_items` VALUES (1394, 'bhbirf906', 221, 861, 0, 0, 0, 0, 5.74, 861, 1423512369, 1424808369);
INSERT INTO `db_sell_items` VALUES (1395, 'bhbirf906', 221, 109, 0, 0, 0, 0, 0.73, 109, 1423514130, 1424810130);
INSERT INTO `db_sell_items` VALUES (1392, 'Bakeshi', 281, 78, 0, 0, 0, 0, 0.52, 78, 1423504463, 1424800463);
INSERT INTO `db_sell_items` VALUES (1393, 'Best', 63, 1268, 0, 0, 0, 0, 8.45, 1268, 1423510350, 1424806350);
INSERT INTO `db_sell_items` VALUES (1391, 'volume', 237, 976, 0, 0, 0, 0, 6.51, 976, 1423503742, 1424799742);
INSERT INTO `db_sell_items` VALUES (1390, 'Kastaneda', 155, 1187, 0, 0, 0, 0, 7.91, 1187, 1423500768, 1424796768);
INSERT INTO `db_sell_items` VALUES (1389, 'bhbirf906', 221, 156, 0, 0, 0, 0, 1.04, 156, 1423498530, 1424794530);
INSERT INTO `db_sell_items` VALUES (1387, 'GetLens', 216, 856, 0, 0, 0, 0, 5.71, 856, 1423497886, 1424793886);
INSERT INTO `db_sell_items` VALUES (1388, 'vitaminka', 185, 1070, 0, 0, 0, 0, 7.13, 1070, 1423498450, 1424794450);
INSERT INTO `db_sell_items` VALUES (1386, 'bhbirf906', 221, 1274, 0, 0, 0, 0, 8.49, 1274, 1423495944, 1424791944);
INSERT INTO `db_sell_items` VALUES (1385, 'volume', 237, 12011, 0, 0, 0, 0, 80.07, 12011, 1423493283, 1424789283);
INSERT INTO `db_sell_items` VALUES (1384, 'shpionka', 166, 6442, 9717, 22828, 19743, 99229, 1053.06, 157959, 1423491974, 1424787974);
INSERT INTO `db_sell_items` VALUES (1383, 'andron1144', 250, 3012, 0, 0, 0, 0, 20.08, 3012, 1423489042, 1424785042);
INSERT INTO `db_sell_items` VALUES (1382, 'toys', 243, 7129, 28083, 91347, 59252, 0, 1238.74, 185811, 1423487660, 1424783660);
INSERT INTO `db_sell_items` VALUES (1381, 'Bakeshi', 281, 16, 0, 0, 0, 0, 0.11, 16, 1423484435, 1424780435);
INSERT INTO `db_sell_items` VALUES (1380, 'rj3111', 85, 1261, 1801, 0, 0, 0, 20.41, 3062, 1423480905, 1424776905);
INSERT INTO `db_sell_items` VALUES (1379, 'Bakeshi', 281, 3, 0, 0, 0, 0, 0.02, 3, 1423480431, 1424776431);
INSERT INTO `db_sell_items` VALUES (1378, 'Bakeshi', 281, 19, 0, 0, 0, 0, 0.13, 19, 1423479552, 1424775552);
INSERT INTO `db_sell_items` VALUES (1377, 'mixail', 148, 135, 0, 0, 0, 0, 0.9, 135, 1423475383, 1424771383);
INSERT INTO `db_sell_items` VALUES (1376, 'bhbirf906', 221, 867, 0, 0, 0, 0, 5.78, 867, 1423474804, 1424770804);
INSERT INTO `db_sell_items` VALUES (1374, 'tornadosta', 260, 553, 0, 0, 0, 0, 3.69, 553, 1423474249, 1424770249);
INSERT INTO `db_sell_items` VALUES (1375, 'Bakeshi', 281, 13, 0, 0, 0, 0, 0.09, 13, 1423474697, 1424770697);
INSERT INTO `db_sell_items` VALUES (1373, 'shpionka', 166, 1172, 1772, 4323, 3739, 18791, 198.65, 29797, 1423473465, 1424769465);
INSERT INTO `db_sell_items` VALUES (1372, 'Bakeshi', 281, 5, 0, 0, 0, 0, 0.03, 5, 1423471468, 1424767468);
INSERT INTO `db_sell_items` VALUES (1371, 'Vagan', 253, 267, 0, 0, 0, 0, 1.78, 267, 1423471297, 1424767297);
INSERT INTO `db_sell_items` VALUES (1369, 'palpalyh', 231, 589, 0, 0, 0, 0, 3.93, 589, 1423471182, 1424767182);
INSERT INTO `db_sell_items` VALUES (1370, 'kukanik', 194, 914, 0, 0, 0, 0, 6.09, 914, 1423471230, 1424767230);
INSERT INTO `db_sell_items` VALUES (1368, 'Bakeshi', 281, 30, 0, 0, 0, 0, 0.2, 30, 1423470182, 1424766182);
INSERT INTO `db_sell_items` VALUES (1367, 'shpionka', 166, 2183, 2954, 8146, 7045, 35410, 371.59, 55738, 1423469960, 1424765960);
INSERT INTO `db_sell_items` VALUES (1365, 'denplast', 135, 884, 0, 0, 0, 0, 5.89, 884, 1423468715, 1424764715);
INSERT INTO `db_sell_items` VALUES (1366, 'amince', 244, 507, 0, 0, 0, 0, 3.38, 507, 1423469496, 1424765496);
INSERT INTO `db_sell_items` VALUES (1364, 'w2mwwm', 183, 2843, 0, 0, 0, 0, 18.95, 2843, 1423464318, 1424760318);
INSERT INTO `db_sell_items` VALUES (1362, 'Bakeshi', 281, 9, 0, 0, 0, 0, 0.06, 9, 1423462592, 1424758592);
INSERT INTO `db_sell_items` VALUES (1363, 'shpionka', 166, 26005, 35183, 97026, 83915, 421759, 4425.92, 663888, 1423463355, 1424759355);
INSERT INTO `db_sell_items` VALUES (1361, 'bhbirf906', 221, 1943, 0, 0, 0, 0, 12.95, 1943, 1423459944, 1424755944);
INSERT INTO `db_sell_items` VALUES (1360, 'Bakeshi', 281, 9, 0, 0, 0, 0, 0.06, 9, 1423457808, 1424753808);
INSERT INTO `db_sell_items` VALUES (1359, 'Bakeshi', 281, 5, 0, 0, 0, 0, 0.03, 5, 1423453153, 1424749153);
INSERT INTO `db_sell_items` VALUES (1358, 'Bakeshi', 281, 67, 0, 0, 0, 0, 0.45, 67, 1423450378, 1424746378);
INSERT INTO `db_sell_items` VALUES (1357, 'ganne', 283, 348, 0, 0, 0, 0, 2.32, 348, 1423446548, 1424742548);
INSERT INTO `db_sell_items` VALUES (1356, 'Nogar', 213, 658, 0, 0, 0, 0, 4.39, 658, 1423438157, 1424734157);
INSERT INTO `db_sell_items` VALUES (1354, 'SUMRAC', 277, 353, 0, 0, 0, 0, 2.35, 353, 1423430089, 1424726089);
INSERT INTO `db_sell_items` VALUES (1355, 'KOLJUNJA', 161, 501, 0, 0, 0, 0, 3.34, 501, 1423430366, 1424726366);
INSERT INTO `db_sell_items` VALUES (1352, 'sarapul', 198, 523, 0, 0, 0, 0, 3.49, 523, 1423427438, 1424723438);
INSERT INTO `db_sell_items` VALUES (1353, 'Evgeniy888', 279, 637, 0, 0, 0, 0, 4.25, 637, 1423428062, 1424724062);
INSERT INTO `db_sell_items` VALUES (1351, 'tornadosta', 260, 328, 0, 0, 0, 0, 2.19, 328, 1423426821, 1424722821);
INSERT INTO `db_sell_items` VALUES (1349, 'bhbirf906', 221, 338, 0, 0, 0, 0, 2.25, 338, 1423423182, 1424719182);
INSERT INTO `db_sell_items` VALUES (1350, 'bhbirf906', 221, 174, 0, 0, 0, 0, 1.16, 174, 1423426627, 1424722627);
INSERT INTO `db_sell_items` VALUES (1347, 'bhbirf906', 221, 860, 0, 0, 0, 0, 5.73, 860, 1423416489, 1424712489);
INSERT INTO `db_sell_items` VALUES (1348, 'tverdun927', 280, 475, 0, 0, 0, 0, 3.17, 475, 1423417217, 1424713217);
INSERT INTO `db_sell_items` VALUES (1346, 'Bakeshi', 281, 156, 0, 0, 0, 0, 1.04, 156, 1423415701, 1424711701);
INSERT INTO `db_sell_items` VALUES (1345, 'GetLens', 216, 505, 0, 0, 0, 0, 3.37, 505, 1423409856, 1424705856);
INSERT INTO `db_sell_items` VALUES (1344, 'mixail', 148, 143, 0, 0, 0, 0, 0.95, 143, 1423406084, 1424702084);
INSERT INTO `db_sell_items` VALUES (1342, 'mimi877', 105, 1046, 0, 0, 0, 0, 6.97, 1046, 1423399930, 1424695930);
INSERT INTO `db_sell_items` VALUES (1343, 'Vagan', 253, 714, 0, 0, 0, 0, 4.76, 714, 1423402583, 1424698583);
INSERT INTO `db_sell_items` VALUES (1341, 'bhbirf906', 221, 362, 0, 0, 0, 0, 2.41, 362, 1423399485, 1424695485);
INSERT INTO `db_sell_items` VALUES (1340, 'tornadosta', 260, 651, 0, 0, 0, 0, 4.34, 651, 1423398690, 1424694690);
INSERT INTO `db_sell_items` VALUES (1339, 'palpalyh', 231, 385, 0, 0, 0, 0, 2.57, 385, 1423395408, 1424691408);
INSERT INTO `db_sell_items` VALUES (1338, 'w2mwwm', 183, 638, 0, 0, 0, 0, 4.25, 638, 1423394690, 1424690690);
INSERT INTO `db_sell_items` VALUES (1337, 'mishanja30', 271, 369, 0, 0, 0, 0, 2.46, 369, 1423392673, 1424688673);
INSERT INTO `db_sell_items` VALUES (1336, 'bhbirf906', 221, 228, 0, 0, 0, 0, 1.52, 228, 1423392317, 1424688317);
INSERT INTO `db_sell_items` VALUES (1335, 'ZET1', 219, 863, 0, 0, 0, 0, 5.75, 863, 1423392280, 1424688280);
INSERT INTO `db_sell_items` VALUES (1333, 'cariden', 270, 446, 0, 0, 0, 0, 2.97, 446, 1423389780, 1424685780);
INSERT INTO `db_sell_items` VALUES (1334, 'izadora', 284, 125, 0, 0, 0, 0, 0.83, 125, 1423389887, 1424685887);
INSERT INTO `db_sell_items` VALUES (1332, 'rj3111', 85, 1066, 1776, 0, 0, 0, 18.95, 2842, 1423388295, 1424684295);
INSERT INTO `db_sell_items` VALUES (1331, 'bhbirf906', 221, 2351, 0, 0, 0, 0, 15.67, 2351, 1423387807, 1424683807);
INSERT INTO `db_sell_items` VALUES (1330, 'shpionka', 166, 30933, 42859, 108345, 102222, 513771, 5320.87, 798130, 1423384689, 1424680689);
INSERT INTO `db_sell_items` VALUES (1328, 'w2mwwm', 183, 1732, 0, 0, 0, 0, 11.55, 1732, 1423378278, 1424674278);
INSERT INTO `db_sell_items` VALUES (1329, 'amince', 244, 1007, 0, 0, 0, 0, 6.71, 1007, 1423382518, 1424678518);
INSERT INTO `db_sell_items` VALUES (1327, 'denplast', 135, 1241, 0, 0, 0, 0, 8.27, 1241, 1423377797, 1424673797);
INSERT INTO `db_sell_items` VALUES (1326, 'kukanik', 194, 756, 0, 0, 0, 0, 5.04, 756, 1423377177, 1424673177);
INSERT INTO `db_sell_items` VALUES (1325, 'toys', 243, 4922, 22853, 74335, 48217, 0, 1002.18, 150327, 1423376562, 1424672562);
INSERT INTO `db_sell_items` VALUES (1324, 'Kastaneda', 155, 1031, 0, 0, 0, 0, 6.87, 1031, 1423348195, 1424644195);
INSERT INTO `db_sell_items` VALUES (1323, 'tornadosta', 260, 45, 0, 0, 0, 0, 0.3, 45, 1423342922, 1424638922);
INSERT INTO `db_sell_items` VALUES (1322, 'bhbirf906', 221, 79, 0, 0, 0, 0, 0.53, 79, 1423341298, 1424637298);
INSERT INTO `db_sell_items` VALUES (1320, 'SUMRAC', 277, 565, 0, 0, 0, 0, 3.77, 565, 1423339261, 1424635261);
INSERT INTO `db_sell_items` VALUES (1321, 'bhbirf906', 221, 221, 0, 0, 0, 0, 1.47, 221, 1423339684, 1424635684);
INSERT INTO `db_sell_items` VALUES (1319, 'tornadosta', 260, 205, 0, 0, 0, 0, 1.37, 205, 1423339024, 1424635024);
INSERT INTO `db_sell_items` VALUES (1317, 'Bakeshi', 281, 7, 0, 0, 0, 0, 0.05, 7, 1423335539, 1424631539);
INSERT INTO `db_sell_items` VALUES (1318, 'volume', 237, 5287, 0, 0, 0, 0, 35.25, 5287, 1423338849, 1424634849);
INSERT INTO `db_sell_items` VALUES (1316, 'bhbirf906', 221, 939, 0, 0, 0, 0, 6.26, 939, 1423335128, 1424631128);
INSERT INTO `db_sell_items` VALUES (1315, 'mixail', 148, 177, 0, 0, 0, 0, 1.18, 177, 1423332538, 1424628538);
INSERT INTO `db_sell_items` VALUES (1314, 'cariden', 270, 992, 0, 0, 0, 0, 6.61, 992, 1423332428, 1424628428);
INSERT INTO `db_sell_items` VALUES (1312, 'palpalyh', 231, 755, 0, 0, 0, 0, 5.03, 755, 1423329345, 1424625345);
INSERT INTO `db_sell_items` VALUES (1313, 'Bakeshi', 281, 73, 0, 0, 0, 0, 0.49, 73, 1423331844, 1424627844);
INSERT INTO `db_sell_items` VALUES (1311, 'w2mwwm', 183, 1123, 0, 0, 0, 0, 7.49, 1123, 1423328801, 1424624801);
INSERT INTO `db_sell_items` VALUES (1310, 'stupak62', 201, 1764, 11760, 93242, 0, 0, 711.77, 106766, 1423326061, 1424622061);
INSERT INTO `db_sell_items` VALUES (1308, 'sarita', 72, 1566, 26106, 0, 0, 0, 184.48, 27672, 1423319447, 1424615447);
INSERT INTO `db_sell_items` VALUES (1309, 'GetLens', 216, 751, 0, 0, 0, 0, 5.01, 751, 1423323201, 1424619201);
INSERT INTO `db_sell_items` VALUES (1307, 'udovitskiy', 268, 682, 0, 0, 0, 0, 4.55, 682, 1423318027, 1424614027);
INSERT INTO `db_sell_items` VALUES (1306, 'tornadosta', 260, 598, 0, 0, 0, 0, 3.99, 598, 1423317975, 1424613975);
INSERT INTO `db_sell_items` VALUES (1305, 'bhbirf906', 221, 838, 0, 0, 0, 0, 5.59, 838, 1423315010, 1424611010);
INSERT INTO `db_sell_items` VALUES (1304, 'a100500q', 252, 23581, 188650, 99715, 0, 0, 2079.64, 311946, 1423299750, 1424595750);
INSERT INTO `db_sell_items` VALUES (1303, 'rj3111', 85, 748, 1497, 0, 0, 0, 14.97, 2245, 1423296949, 1424592949);
INSERT INTO `db_sell_items` VALUES (1302, 'bhbirf906', 221, 351, 0, 0, 0, 0, 2.34, 351, 1423296281, 1424592281);
INSERT INTO `db_sell_items` VALUES (1301, 'w2mwwm', 183, 2092, 0, 0, 0, 0, 13.95, 2092, 1423294826, 1424590826);
INSERT INTO `db_sell_items` VALUES (1300, 'Bakeshi', 281, 137, 0, 0, 0, 0, 0.91, 137, 1423294236, 1424590236);
INSERT INTO `db_sell_items` VALUES (1299, 'mimi877', 105, 643, 0, 0, 0, 0, 4.29, 643, 1423292371, 1424588371);
INSERT INTO `db_sell_items` VALUES (1298, 'shpionka', 166, 15317, 21327, 56364, 53179, 267278, 2756.43, 413465, 1423288855, 1424584855);
INSERT INTO `db_sell_items` VALUES (1296, 'toys', 243, 3260, 18629, 65646, 42581, 0, 867.44, 130116, 1423286156, 1424582156);
INSERT INTO `db_sell_items` VALUES (1297, 'bhbirf906', 221, 1424, 0, 0, 0, 0, 9.49, 1424, 1423288070, 1424584070);
INSERT INTO `db_sell_items` VALUES (1295, 'Mixaluch', 228, 4026, 0, 0, 0, 0, 26.84, 4026, 1423281573, 1424577573);
INSERT INTO `db_sell_items` VALUES (1294, 'kukanik', 194, 658, 0, 0, 0, 0, 4.39, 658, 1423280035, 1424576035);
INSERT INTO `db_sell_items` VALUES (1293, 'Nogar', 213, 181, 0, 0, 0, 0, 1.21, 181, 1423269041, 1424565041);
INSERT INTO `db_sell_items` VALUES (1292, 'Evgeniy888', 279, 197, 0, 0, 0, 0, 1.31, 197, 1423264281, 1424560281);
INSERT INTO `db_sell_items` VALUES (1291, 'tornadosta', 260, 240, 0, 0, 0, 0, 1.6, 240, 1423256430, 1424552430);
INSERT INTO `db_sell_items` VALUES (1290, 'bhbirf906', 221, 320, 0, 0, 0, 0, 2.13, 320, 1423254791, 1424550791);
INSERT INTO `db_sell_items` VALUES (1289, 'volume', 237, 3770, 0, 0, 0, 0, 25.13, 3770, 1423251137, 1424547137);
INSERT INTO `db_sell_items` VALUES (1288, 'bhbirf906', 221, 1439, 0, 0, 0, 0, 9.59, 1439, 1423246961, 1424542961);
INSERT INTO `db_sell_items` VALUES (1286, 'mixail', 148, 219, 0, 0, 0, 0, 1.46, 219, 1423241289, 1424537289);
INSERT INTO `db_sell_items` VALUES (1287, 'ZET1', 219, 827, 0, 0, 0, 0, 5.51, 827, 1423244295, 1424540295);
INSERT INTO `db_sell_items` VALUES (1284, 'tornadosta', 260, 136, 0, 0, 0, 0, 0.91, 136, 1423231700, 1424527700);
INSERT INTO `db_sell_items` VALUES (1285, 'shpionka', 166, 10383, 13572, 39456, 37227, 187103, 1918.27, 287741, 1423238999, 1424534999);
INSERT INTO `db_sell_items` VALUES (1283, 'w2mwwm', 183, 1734, 0, 0, 0, 0, 11.56, 1734, 1423226170, 1424522170);
INSERT INTO `db_sell_items` VALUES (1282, 'stupak62', 201, 399, 2657, 21070, 0, 0, 160.84, 24126, 1423225258, 1424521258);
INSERT INTO `db_sell_items` VALUES (1281, 'Bakeshi', 281, 13, 0, 0, 0, 0, 0.09, 13, 1423223874, 1424519874);
INSERT INTO `db_sell_items` VALUES (1280, 'vitaminka', 185, 223, 0, 0, 0, 0, 1.49, 223, 1423223408, 1424519408);
INSERT INTO `db_sell_items` VALUES (1279, 'rj3111', 85, 683, 1708, 0, 0, 0, 15.94, 2391, 1423219983, 1424515983);
INSERT INTO `db_sell_items` VALUES (1278, 'Vagan', 253, 184, 0, 0, 0, 0, 1.23, 184, 1423218938, 1424514938);
INSERT INTO `db_sell_items` VALUES (1277, 'denplast', 135, 505, 0, 0, 0, 0, 3.37, 505, 1423218226, 1424514226);
INSERT INTO `db_sell_items` VALUES (1276, 'Bakeshi', 281, 5, 0, 0, 0, 0, 0.03, 5, 1423217264, 1424513264);
INSERT INTO `db_sell_items` VALUES (1275, 'Bakeshi', 281, 43, 0, 0, 0, 0, 0.29, 43, 1423214514, 1424510514);
INSERT INTO `db_sell_items` VALUES (1274, 'tornadosta', 260, 357, 0, 0, 0, 0, 2.38, 357, 1423214198, 1424510198);
INSERT INTO `db_sell_items` VALUES (1273, 'bhbirf906', 221, 1578, 0, 0, 0, 0, 10.52, 1578, 1423209959, 1424505959);
INSERT INTO `db_sell_items` VALUES (1272, 'mimi877', 105, 669, 0, 0, 0, 0, 4.46, 669, 1423209641, 1424505641);
INSERT INTO `db_sell_items` VALUES (1271, 'toys', 243, 2214, 11598, 44583, 28919, 0, 582.09, 87314, 1423206318, 1424502318);
INSERT INTO `db_sell_items` VALUES (1270, 'shpionka', 166, 20354, 24923, 80505, 75955, 381754, 3889.94, 583491, 1423204097, 1424500097);
INSERT INTO `db_sell_items` VALUES (1269, 'mishanja30', 271, 267, 0, 0, 0, 0, 1.78, 267, 1423202992, 1424498992);
INSERT INTO `db_sell_items` VALUES (1268, 'stupak62', 201, 642, 4280, 33937, 0, 0, 259.06, 38859, 1423202480, 1424498480);
INSERT INTO `db_sell_items` VALUES (1267, 'palpalyh', 231, 338, 0, 0, 0, 0, 2.25, 338, 1423199908, 1424495908);
INSERT INTO `db_sell_items` VALUES (1266, 'kukanik', 194, 796, 0, 0, 0, 0, 5.31, 796, 1423195458, 1424491458);
INSERT INTO `db_sell_items` VALUES (1265, 'GetLens', 216, 563, 0, 0, 0, 0, 3.75, 563, 1423194465, 1424490465);
INSERT INTO `db_sell_items` VALUES (1264, 'Nogar', 213, 164, 0, 0, 0, 0, 1.09, 164, 1423175875, 1424471875);
INSERT INTO `db_sell_items` VALUES (1263, 'Kastaneda', 155, 349, 0, 0, 0, 0, 2.33, 349, 1423171406, 1424467406);
INSERT INTO `db_sell_items` VALUES (1262, 'volume', 237, 779, 0, 0, 0, 0, 5.19, 779, 1423170350, 1424466350);
INSERT INTO `db_sell_items` VALUES (1261, 'tornadosta', 260, 215, 0, 0, 0, 0, 1.43, 215, 1423168339, 1424464339);
INSERT INTO `db_sell_items` VALUES (1260, 'bhbirf906', 221, 227, 0, 0, 0, 0, 1.51, 227, 1423167245, 1424463245);
INSERT INTO `db_sell_items` VALUES (1259, 'stupak62', 201, 3260, 21733, 172312, 0, 0, 1315.37, 197305, 1423165793, 1424461793);
INSERT INTO `db_sell_items` VALUES (1258, 'w2mwwm', 183, 474, 0, 0, 0, 0, 3.16, 474, 1423162488, 1424458488);
INSERT INTO `db_sell_items` VALUES (1257, 'bhbirf906', 221, 85, 0, 0, 0, 0, 0.57, 85, 1423160758, 1424456758);
INSERT INTO `db_sell_items` VALUES (1256, 'sarapul', 198, 723, 0, 0, 0, 0, 4.82, 723, 1423158657, 1424454657);
INSERT INTO `db_sell_items` VALUES (1255, 'bhbirf906', 221, 267, 0, 0, 0, 0, 1.78, 267, 1423158198, 1424454198);
INSERT INTO `db_sell_items` VALUES (1254, 'Asasins123', 278, 2, 0, 0, 0, 0, 0.01, 2, 1423155953, 1424451953);
INSERT INTO `db_sell_items` VALUES (1253, 'volume', 237, 1520, 0, 0, 0, 0, 10.13, 1520, 1423152927, 1424448927);
INSERT INTO `db_sell_items` VALUES (1252, 'toys', 243, 1428, 7482, 28763, 18657, 0, 375.53, 56330, 1423152097, 1424448097);
INSERT INTO `db_sell_items` VALUES (1251, 'treder', 73, 9849, 17191, 90861, 0, 0, 786.01, 117901, 1423151217, 1424447217);
INSERT INTO `db_sell_items` VALUES (1250, 'bhbirf906', 221, 2246, 0, 0, 0, 0, 14.97, 2246, 1423150125, 1424446125);
INSERT INTO `db_sell_items` VALUES (1249, 'kelmonda', 196, 174, 0, 0, 0, 0, 1.16, 174, 1423149311, 1424445311);
INSERT INTO `db_sell_items` VALUES (1248, 'olegator74', 232, 654, 0, 0, 0, 0, 4.36, 654, 1423146717, 1424442717);
INSERT INTO `db_sell_items` VALUES (1247, 'w2mwwm', 183, 509, 0, 0, 0, 0, 3.39, 509, 1423143742, 1424439742);
INSERT INTO `db_sell_items` VALUES (1246, 'tornadosta', 260, 72, 0, 0, 0, 0, 0.48, 72, 1423140738, 1424436738);
INSERT INTO `db_sell_items` VALUES (1245, 'shpionka', 166, 219, 268, 867, 818, 4112, 41.89, 6284, 1423132890, 1424428890);
INSERT INTO `db_sell_items` VALUES (1244, 'rj3111', 85, 525, 1312, 0, 0, 0, 12.25, 1837, 1423132144, 1424428144);
INSERT INTO `db_sell_items` VALUES (1243, 'shpionka', 166, 2980, 3751, 12116, 11431, 57455, 584.89, 87733, 1423132122, 1424428122);
INSERT INTO `db_sell_items` VALUES (1242, 'denplast', 135, 506, 0, 0, 0, 0, 3.37, 506, 1423131600, 1424427600);
INSERT INTO `db_sell_items` VALUES (1241, 'mixail', 148, 118, 0, 0, 0, 0, 0.79, 118, 1423128889, 1424424889);
INSERT INTO `db_sell_items` VALUES (1240, 'tornadosta', 260, 281, 0, 0, 0, 0, 1.87, 281, 1423128441, 1424424441);
INSERT INTO `db_sell_items` VALUES (1239, 'fktrc906', 209, 578, 0, 0, 0, 0, 3.85, 578, 1423125611, 1424421611);
INSERT INTO `db_sell_items` VALUES (1238, 'Vagan', 253, 804, 0, 0, 0, 0, 5.36, 804, 1423124369, 1424420369);
INSERT INTO `db_sell_items` VALUES (1237, 'amince', 244, 984, 0, 0, 0, 0, 6.56, 984, 1423123650, 1424419650);
INSERT INTO `db_sell_items` VALUES (1236, 'mimi877', 105, 419, 0, 0, 0, 0, 2.79, 419, 1423123591, 1424419591);
INSERT INTO `db_sell_items` VALUES (1235, 'w2mwwm', 183, 922, 0, 0, 0, 0, 6.15, 922, 1423121937, 1424417937);
INSERT INTO `db_sell_items` VALUES (1234, 'shpionka', 166, 16579, 18948, 68855, 64964, 326513, 3305.73, 495859, 1423121405, 1424417405);
INSERT INTO `db_sell_items` VALUES (1233, 'toys', 243, 2332, 11105, 46958, 30459, 0, 605.69, 90854, 1423117110, 1424413110);
INSERT INTO `db_sell_items` VALUES (1232, 'volume', 237, 1658, 0, 0, 0, 0, 11.05, 1658, 1423115696, 1424411696);
INSERT INTO `db_sell_items` VALUES (1231, 'palpalyh', 231, 170, 0, 0, 0, 0, 1.13, 170, 1423113092, 1424409092);
INSERT INTO `db_sell_items` VALUES (1230, 'vitaminka', 185, 91, 0, 0, 0, 0, 0.61, 91, 1423108484, 1424404484);
INSERT INTO `db_sell_items` VALUES (1229, 'ZET1', 219, 167, 0, 0, 0, 0, 1.11, 167, 1423102554, 1424398554);
INSERT INTO `db_sell_items` VALUES (1228, 'Kastaneda', 155, 323, 0, 0, 0, 0, 2.15, 323, 1423081696, 1424377696);
INSERT INTO `db_sell_items` VALUES (1227, 'tornadosta', 260, 151, 0, 0, 0, 0, 1.01, 151, 1423080190, 1424376190);
INSERT INTO `db_sell_items` VALUES (1226, 'w2mwwm', 183, 536, 0, 0, 0, 0, 3.57, 536, 1423078849, 1424374849);
INSERT INTO `db_sell_items` VALUES (1225, 'bhbirf906', 221, 163, 0, 0, 0, 0, 1.09, 163, 1423077948, 1424373948);
INSERT INTO `db_sell_items` VALUES (1224, 'cariden', 270, 180, 0, 0, 0, 0, 1.2, 180, 1423077321, 1424373321);
INSERT INTO `db_sell_items` VALUES (1223, 'volume', 237, 2659, 0, 0, 0, 0, 17.73, 2659, 1423073053, 1424369053);
INSERT INTO `db_sell_items` VALUES (1222, 'bhbirf906', 221, 374, 0, 0, 0, 0, 2.49, 374, 1423072342, 1424368342);
INSERT INTO `db_sell_items` VALUES (1221, 'mixail', 148, 148, 0, 0, 0, 0, 0.99, 148, 1423068031, 1424364031);
INSERT INTO `db_sell_items` VALUES (1220, 'mishanja30', 271, 127, 0, 0, 0, 0, 0.85, 127, 1423065480, 1424361480);
INSERT INTO `db_sell_items` VALUES (1219, 'rj3111', 85, 430, 1432, 0, 0, 0, 12.41, 1862, 1423064668, 1424360668);
INSERT INTO `db_sell_items` VALUES (1218, 'shpionka', 166, 3716, 4404, 16003, 15099, 75887, 767.39, 115109, 1423060501, 1424356501);
INSERT INTO `db_sell_items` VALUES (1217, 'toys', 243, 1185, 5642, 23859, 15476, 0, 307.75, 46162, 1423059999, 1424355999);
INSERT INTO `db_sell_items` VALUES (1216, 'ZET1', 219, 197, 0, 0, 0, 0, 1.31, 197, 1423059723, 1424355723);
INSERT INTO `db_sell_items` VALUES (1215, 'bhbirf906', 221, 1669, 0, 0, 0, 0, 11.13, 1669, 1423059524, 1424355524);
INSERT INTO `db_sell_items` VALUES (1214, 'kukanik', 194, 194, 0, 0, 0, 0, 1.29, 194, 1423058968, 1424354968);
INSERT INTO `db_sell_items` VALUES (1213, 'swerg', 249, 706, 0, 0, 0, 0, 4.71, 706, 1423054281, 1424350281);
INSERT INTO `db_sell_items` VALUES (1212, 'mimi877', 105, 291, 0, 0, 0, 0, 1.94, 291, 1423051848, 1424347848);
INSERT INTO `db_sell_items` VALUES (1211, 'w2mwwm', 183, 261, 0, 0, 0, 0, 1.74, 261, 1423051300, 1424347300);
INSERT INTO `db_sell_items` VALUES (1210, 'sarita', 72, 407, 6787, 0, 0, 0, 47.96, 7194, 1423050926, 1424346926);
INSERT INTO `db_sell_items` VALUES (1209, 'GetLens', 216, 2043, 0, 0, 0, 0, 13.62, 2043, 1423049813, 1424345813);
INSERT INTO `db_sell_items` VALUES (1208, 'shpionka', 166, 1000, 1203, 4373, 4126, 20737, 209.59, 31439, 1423046347, 1424342347);
INSERT INTO `db_sell_items` VALUES (1207, 'tornadosta', 260, 258, 0, 0, 0, 0, 1.72, 258, 1423046276, 1424342276);
INSERT INTO `db_sell_items` VALUES (1206, 'denplast', 135, 340, 0, 0, 0, 0, 2.27, 340, 1423044802, 1424340802);
INSERT INTO `db_sell_items` VALUES (1205, 'shpionka', 166, 15455, 16391, 68074, 64227, 322809, 3246.37, 486956, 1423042478, 1424338478);
INSERT INTO `db_sell_items` VALUES (1204, 'w2mwwm', 183, 86, 0, 0, 0, 0, 0.57, 86, 1423036364, 1424332364);
INSERT INTO `db_sell_items` VALUES (1203, 'toys', 243, 210, 1000, 4228, 2742, 0, 54.53, 8180, 1423030981, 1424326981);
INSERT INTO `db_sell_items` VALUES (1202, 'w2mwwm', 183, 646, 0, 0, 0, 0, 4.31, 646, 1423030823, 1424326823);
INSERT INTO `db_sell_items` VALUES (1201, 'toys', 243, 1750, 8332, 35234, 22854, 0, 454.47, 68170, 1423025842, 1424321842);
INSERT INTO `db_sell_items` VALUES (1200, 'palpalyh', 231, 172, 0, 0, 0, 0, 1.15, 172, 1423025832, 1424321832);
INSERT INTO `db_sell_items` VALUES (1199, 'kukanik', 194, 320, 0, 0, 0, 0, 2.13, 320, 1423025632, 1424321632);
INSERT INTO `db_sell_items` VALUES (1198, 'ZET1', 219, 394, 0, 0, 0, 0, 2.63, 394, 1423009096, 1424305096);
INSERT INTO `db_sell_items` VALUES (1197, 'Kastaneda', 155, 343, 0, 0, 0, 0, 2.29, 343, 1422998539, 1424294539);
INSERT INTO `db_sell_items` VALUES (1196, 'bhbirf906', 221, 96, 0, 0, 0, 0, 0.64, 96, 1422998239, 1424294239);
INSERT INTO `db_sell_items` VALUES (1195, 'bhbirf906', 221, 188, 0, 0, 0, 0, 1.25, 188, 1422994422, 1424290422);
INSERT INTO `db_sell_items` VALUES (1194, 'volume', 237, 1314, 0, 0, 0, 0, 8.76, 1314, 1422992625, 1424288625);
INSERT INTO `db_sell_items` VALUES (1193, 'mixail', 148, 18, 0, 0, 0, 0, 0.12, 18, 1422991887, 1424287887);
INSERT INTO `db_sell_items` VALUES (1192, 'rj3111', 85, 549, 1830, 0, 0, 0, 15.86, 2379, 1422991003, 1424287003);
INSERT INTO `db_sell_items` VALUES (1191, 'w2mwwm', 183, 569, 0, 0, 0, 0, 3.79, 569, 1422989304, 1424285304);
INSERT INTO `db_sell_items` VALUES (1190, 'bhbirf906', 221, 1772, 0, 0, 0, 0, 11.81, 1772, 1422986991, 1424282991);
INSERT INTO `db_sell_items` VALUES (1189, 'toys', 243, 887, 4927, 20833, 13513, 0, 267.73, 40160, 1422983003, 1424279003);
INSERT INTO `db_sell_items` VALUES (1188, 'mixail', 148, 225, 0, 0, 0, 0, 1.5, 225, 1422982668, 1424278668);
INSERT INTO `db_sell_items` VALUES (1187, 'shpionka', 166, 1940, 2106, 8745, 8251, 41468, 416.73, 62510, 1422982267, 1424278267);
INSERT INTO `db_sell_items` VALUES (1186, 'sarita', 72, 380, 9503, 0, 0, 0, 65.89, 9883, 1422981118, 1424277118);
INSERT INTO `db_sell_items` VALUES (1185, 'tornadosta', 260, 48, 0, 0, 0, 0, 0.32, 48, 1422979991, 1424275991);
INSERT INTO `db_sell_items` VALUES (1184, 'stupak62', 201, 2237, 14912, 118229, 0, 0, 902.52, 135378, 1422979508, 1424275508);
INSERT INTO `db_sell_items` VALUES (1183, 'olegator74', 232, 394, 0, 0, 0, 0, 2.63, 394, 1422978358, 1424274358);
INSERT INTO `db_sell_items` VALUES (1182, 'mimi877', 105, 446, 0, 0, 0, 0, 2.97, 446, 1422976946, 1424272946);
INSERT INTO `db_sell_items` VALUES (1181, 'shpionka', 166, 3637, 3752, 16783, 15835, 79586, 797.29, 119593, 1422974530, 1424270530);
INSERT INTO `db_sell_items` VALUES (1180, 'andron1144', 250, 389, 0, 0, 0, 0, 2.59, 389, 1422972740, 1424268740);
INSERT INTO `db_sell_items` VALUES (1179, 'kukanik', 194, 764, 0, 0, 0, 0, 5.09, 764, 1422970812, 1424266812);
INSERT INTO `db_sell_items` VALUES (1178, 'shpionka', 166, 1729, 1784, 7978, 7527, 37833, 379.01, 56851, 1422959685, 1424255685);
INSERT INTO `db_sell_items` VALUES (1177, 'toys', 243, 247, 1373, 5807, 3766, 0, 74.62, 11193, 1422957651, 1424253651);
INSERT INTO `db_sell_items` VALUES (1176, 'denplast', 135, 341, 0, 0, 0, 0, 2.27, 341, 1422957321, 1424253321);
INSERT INTO `db_sell_items` VALUES (1175, 'tornadosta', 260, 106, 0, 0, 0, 0, 0.71, 106, 1422955073, 1424251073);
INSERT INTO `db_sell_items` VALUES (1174, 'shpionka', 166, 1932, 2058, 9206, 8686, 43656, 436.92, 65538, 1422952629, 1424248629);
INSERT INTO `db_sell_items` VALUES (1173, 'toys', 243, 1427, 9172, 43096, 27954, 0, 544.33, 81649, 1422950589, 1424246589);
INSERT INTO `db_sell_items` VALUES (1172, 'volume', 237, 980, 0, 0, 0, 0, 6.53, 980, 1422950387, 1424246387);
INSERT INTO `db_sell_items` VALUES (1171, 'w2mwwm', 183, 49, 0, 0, 0, 0, 0.33, 49, 1422947496, 1424243496);
INSERT INTO `db_sell_items` VALUES (1170, 'shpionka', 166, 10353, 10618, 51448, 48541, 243968, 2432.85, 364928, 1422944486, 1424240486);
INSERT INTO `db_sell_items` VALUES (1169, 'w2mwwm', 183, 1006, 0, 0, 0, 0, 6.71, 1006, 1422943254, 1424239254);
INSERT INTO `db_sell_items` VALUES (1168, 'volume', 237, 291, 0, 0, 0, 0, 1.94, 291, 1422916779, 1424212779);
INSERT INTO `db_sell_items` VALUES (1167, 'bhbirf906', 221, 33, 0, 0, 0, 0, 0.22, 33, 1422911049, 1424207049);
INSERT INTO `db_sell_items` VALUES (1166, 'bhbirf906', 221, 55, 0, 0, 0, 0, 0.37, 55, 1422909506, 1424205506);
INSERT INTO `db_sell_items` VALUES (1165, 'ZET1', 219, 230, 0, 0, 0, 0, 1.53, 230, 1422907907, 1424203907);
INSERT INTO `db_sell_items` VALUES (1164, 'bhbirf906', 221, 326, 0, 0, 0, 0, 2.17, 326, 1422906949, 1424202949);
INSERT INTO `db_sell_items` VALUES (1163, 'volume', 237, 1809, 0, 0, 0, 0, 12.06, 1809, 1422906081, 1424202081);
INSERT INTO `db_sell_items` VALUES (1162, 'tornadosta', 260, 31, 0, 0, 0, 0, 0.21, 31, 1422900689, 1424196689);
INSERT INTO `db_sell_items` VALUES (1161, 'shpionka', 166, 2884, 3090, 14973, 14127, 71003, 707.18, 106077, 1422898981, 1424194981);
INSERT INTO `db_sell_items` VALUES (1160, 'toys', 243, 833, 4759, 25153, 16316, 0, 313.74, 47061, 1422898174, 1424194174);
INSERT INTO `db_sell_items` VALUES (1159, 'rj3111', 85, 429, 2146, 0, 0, 0, 17.17, 2575, 1422896873, 1424192873);
INSERT INTO `db_sell_items` VALUES (1158, 'bhbirf906', 221, 473, 0, 0, 0, 0, 3.15, 473, 1422891706, 1424187706);
INSERT INTO `db_sell_items` VALUES (1157, 'shpionka', 166, 279, 298, 1446, 1364, 6857, 68.29, 10244, 1422885734, 1424181734);
INSERT INTO `db_sell_items` VALUES (1156, 'tornadosta', 260, 28, 0, 0, 0, 0, 0.19, 28, 1422884970, 1424180970);
INSERT INTO `db_sell_items` VALUES (1155, 'shpionka', 166, 761, 830, 4021, 3794, 19069, 189.83, 28475, 1422884455, 1424180455);
INSERT INTO `db_sell_items` VALUES (1154, 'sarita', 72, 147, 7328, 0, 0, 0, 49.83, 7475, 1422883376, 1424179376);
INSERT INTO `db_sell_items` VALUES (1153, 'shpionka', 166, 835, 945, 4580, 4321, 21718, 215.99, 32399, 1422880901, 1424176901);
INSERT INTO `db_sell_items` VALUES (1152, 'shpionka', 166, 742, 856, 4149, 3915, 19675, 195.58, 29337, 1422876847, 1424172847);
INSERT INTO `db_sell_items` VALUES (1151, 'shpionka', 166, 235, 274, 1328, 1253, 6299, 62.59, 9389, 1422873178, 1424169178);
INSERT INTO `db_sell_items` VALUES (1150, 'andron1144', 250, 165, 0, 0, 0, 0, 1.1, 165, 1422872763, 1424168763);
INSERT INTO `db_sell_items` VALUES (1149, 'shpionka', 166, 1088, 1293, 6266, 5911, 29711, 295.13, 44269, 1422872003, 1424168003);
INSERT INTO `db_sell_items` VALUES (1148, 'tornadosta', 260, 128, 0, 0, 0, 0, 0.85, 128, 1422870443, 1424166443);
INSERT INTO `db_sell_items` VALUES (1147, 'denplast', 135, 171, 0, 0, 0, 0, 1.14, 171, 1422869547, 1424165547);
INSERT INTO `db_sell_items` VALUES (1146, 'toys', 243, 1832, 10470, 55342, 35898, 0, 690.28, 103542, 1422867583, 1424163583);
INSERT INTO `db_sell_items` VALUES (1145, 'bhbirf906', 221, 58, 0, 0, 0, 0, 0.39, 58, 1422867385, 1424163385);
INSERT INTO `db_sell_items` VALUES (1144, 'mixail', 148, 86, 0, 0, 0, 0, 0.57, 86, 1422866996, 1424162996);
INSERT INTO `db_sell_items` VALUES (1143, 'shpionka', 166, 1463, 1792, 8683, 8192, 41173, 408.69, 61303, 1422866461, 1424162461);
INSERT INTO `db_sell_items` VALUES (1142, 'bhbirf906', 221, 144, 0, 0, 0, 0, 0.96, 144, 1422864067, 1424160067);
INSERT INTO `db_sell_items` VALUES (1141, 'mimi877', 105, 154, 0, 0, 0, 0, 1.03, 154, 1422862387, 1424158387);
INSERT INTO `db_sell_items` VALUES (1140, 'shpionka', 166, 402, 493, 2388, 2253, 11323, 112.39, 16859, 1422858781, 1424154781);
INSERT INTO `db_sell_items` VALUES (1139, 'Best', 63, 249, 0, 0, 0, 0, 1.66, 249, 1422858261, 1424154261);
INSERT INTO `db_sell_items` VALUES (1138, 'w2mwwm', 183, 14, 0, 0, 0, 0, 0.09, 14, 1422857026, 1424153026);
INSERT INTO `db_sell_items` VALUES (1137, 'shpionka', 166, 10660, 10877, 63243, 59669, 299901, 2962.33, 444350, 1422856670, 1424152670);
INSERT INTO `db_sell_items` VALUES (1136, 'bhbirf906', 221, 634, 0, 0, 0, 0, 4.23, 634, 1422855837, 1424151837);
INSERT INTO `db_sell_items` VALUES (1135, 'w2mwwm', 183, 1109, 0, 0, 0, 0, 7.39, 1109, 1422855636, 1424151636);
INSERT INTO `db_sell_items` VALUES (1134, 'stupak62', 201, 2700, 18001, 142721, 0, 0, 1089.48, 163422, 1422851694, 1424147694);
INSERT INTO `db_sell_items` VALUES (1133, 'andron1144', 250, 173, 0, 0, 0, 0, 1.15, 173, 1422830405, 1424126405);
INSERT INTO `db_sell_items` VALUES (1132, 'volume', 237, 948, 0, 0, 0, 0, 6.32, 948, 1422828555, 1424124555);
INSERT INTO `db_sell_items` VALUES (1131, 'fktrc906', 209, 173, 0, 0, 0, 0, 1.15, 173, 1422828258, 1424124258);
INSERT INTO `db_sell_items` VALUES (1130, 'Kastaneda', 155, 334, 0, 0, 0, 0, 2.23, 334, 1422821938, 1424117938);
INSERT INTO `db_sell_items` VALUES (1129, 'bhbirf906', 221, 31, 0, 0, 0, 0, 0.21, 31, 1422819586, 1424115586);
INSERT INTO `db_sell_items` VALUES (1128, 'Mixaluch', 228, 884, 0, 0, 0, 0, 5.89, 884, 1422818190, 1424114190);
INSERT INTO `db_sell_items` VALUES (1127, 'bhbirf906', 221, 242, 0, 0, 0, 0, 1.61, 242, 1422817615, 1424113615);
INSERT INTO `db_sell_items` VALUES (1126, 'a100500q', 252, 854, 8544, 4516, 0, 0, 92.76, 13914, 1422814649, 1424110649);
INSERT INTO `db_sell_items` VALUES (1125, 'sarita', 72, 1894, 0, 0, 0, 0, 12.63, 1894, 1422808003, 1424104003);
INSERT INTO `db_sell_items` VALUES (1124, 'IgorSap', 80, 566, 0, 0, 0, 0, 3.77, 566, 1422802990, 1424098990);
INSERT INTO `db_sell_items` VALUES (1123, 'bhbirf906', 221, 261, 0, 0, 0, 0, 1.74, 261, 1422802077, 1424098077);
INSERT INTO `db_sell_items` VALUES (1122, 'shpionka', 166, 179, 191, 1108, 1045, 5254, 51.85, 7777, 1422800729, 1424096729);
INSERT INTO `db_sell_items` VALUES (1121, 'toys', 243, 1879, 21925, 132448, 85912, 0, 1614.43, 242164, 1422800274, 1424096274);
INSERT INTO `db_sell_items` VALUES (1120, 'shpionka', 166, 1685, 1792, 10420, 9831, 49413, 487.61, 73141, 1422799752, 1424095752);
INSERT INTO `db_sell_items` VALUES (1119, 'a100500q', 252, 54, 539, 285, 0, 0, 5.85, 878, 1422792679, 1424088679);
INSERT INTO `db_sell_items` VALUES (1118, 'a100500q', 252, 517, 5170, 2733, 0, 0, 56.13, 8420, 1422791294, 1424087294);
INSERT INTO `db_sell_items` VALUES (1117, 'shpionka', 166, 758, 842, 4898, 4621, 23224, 228.95, 34343, 1422790546, 1424086546);
INSERT INTO `db_sell_items` VALUES (1116, 'ZET1', 219, 91, 0, 0, 0, 0, 0.61, 91, 1422789515, 1424085515);
INSERT INTO `db_sell_items` VALUES (1115, 'rj3111', 85, 94, 945, 0, 0, 0, 6.93, 1039, 1422786486, 1424082486);
INSERT INTO `db_sell_items` VALUES (1114, 'shpionka', 166, 2612, 3110, 18080, 17058, 85735, 843.97, 126595, 1422786202, 1424082202);
INSERT INTO `db_sell_items` VALUES (1113, 'andron1144', 250, 352, 0, 0, 0, 0, 2.35, 352, 1422786124, 1424082124);
INSERT INTO `db_sell_items` VALUES (1112, 'mimi877', 105, 175, 0, 0, 0, 0, 1.17, 175, 1422783202, 1424079202);
INSERT INTO `db_sell_items` VALUES (1111, 'bhbirf906', 221, 31, 0, 0, 0, 0, 0.21, 31, 1422782873, 1424078873);
INSERT INTO `db_sell_items` VALUES (1110, 'denplast', 135, 171, 0, 0, 0, 0, 1.14, 171, 1422781753, 1424077753);
INSERT INTO `db_sell_items` VALUES (1070, 'fktrc906', 209, 168, 0, 0, 0, 0, 1.12, 168, 1422652650, 1423948650);
INSERT INTO `db_sell_items` VALUES (1069, 'volume', 237, 147, 0, 0, 0, 0, 0.98, 147, 1422639709, 1423935709);
INSERT INTO `db_sell_items` VALUES (1068, 'shpionka', 166, 670, 1031, 7490, 7067, 35517, 345.17, 51775, 1422639692, 1423935692);
INSERT INTO `db_sell_items` VALUES (1067, 'toys', 243, 143, 1430, 10080, 6538, 0, 121.27, 18191, 1422639192, 1423935192);
INSERT INTO `db_sell_items` VALUES (1066, 'shpionka', 166, 789, 1262, 9172, 8654, 43495, 422.48, 63372, 1422633073, 1423929073);
INSERT INTO `db_sell_items` VALUES (1065, 'bhbirf906', 221, 29, 0, 0, 0, 0, 0.19, 29, 1422632233, 1423928233);
INSERT INTO `db_sell_items` VALUES (1064, 'toys', 243, 184, 1840, 12966, 8411, 0, 156.01, 23401, 1422626937, 1423922937);
INSERT INTO `db_sell_items` VALUES (1063, 'shpionka', 166, 108, 177, 1283, 1211, 6085, 59.09, 8864, 1422624955, 1423920955);
INSERT INTO `db_sell_items` VALUES (1062, 'bhbirf906', 221, 7, 0, 0, 0, 0, 0.05, 7, 1422624886, 1423920886);
INSERT INTO `db_sell_items` VALUES (1061, 'shpionka', 166, 247, 412, 2995, 2826, 14202, 137.88, 20682, 1422623818, 1423919818);
INSERT INTO `db_sell_items` VALUES (1060, 'shpionka', 166, 58, 97, 702, 662, 3329, 32.32, 4848, 1422621169, 1423917169);
INSERT INTO `db_sell_items` VALUES (1059, 'bhbirf906', 221, 3, 0, 0, 0, 0, 0.02, 3, 1422621067, 1423917067);
INSERT INTO `db_sell_items` VALUES (1058, 'shpionka', 166, 227, 387, 2814, 2655, 13344, 129.51, 19427, 1422620548, 1423916548);
INSERT INTO `db_sell_items` VALUES (1057, 'bhbirf906', 221, 17, 0, 0, 0, 0, 0.11, 17, 1422619322, 1423915322);
INSERT INTO `db_sell_items` VALUES (1056, 'volume', 237, 38, 0, 0, 0, 0, 0.25, 38, 1422619070, 1423915070);
INSERT INTO `db_sell_items` VALUES (1055, 'shpionka', 166, 176, 300, 2179, 2055, 10331, 100.27, 15041, 1422618058, 1423914058);
INSERT INTO `db_sell_items` VALUES (1054, 'amince', 244, 1, 0, 0, 0, 0, 0.01, 1, 1422617552, 1423913552);
INSERT INTO `db_sell_items` VALUES (1053, 'shpionka', 166, 70, 122, 890, 839, 4219, 40.93, 6140, 1422616132, 1423912132);
INSERT INTO `db_sell_items` VALUES (1052, 'shpionka', 166, 57, 99, 717, 676, 3399, 32.99, 4948, 1422615345, 1423911345);
INSERT INTO `db_sell_items` VALUES (1051, 'shpionka', 166, 54, 105, 767, 723, 3635, 35.23, 5284, 1422614713, 1423910713);
INSERT INTO `db_sell_items` VALUES (1050, 'shpionka', 166, 64, 124, 902, 851, 4278, 41.46, 6219, 1422614035, 1423910035);
INSERT INTO `db_sell_items` VALUES (1049, 'shpionka', 166, 249, 497, 3613, 3409, 17134, 166.01, 24902, 1422613235, 1423909235);
INSERT INTO `db_sell_items` VALUES (1048, 'toys', 243, 11, 105, 740, 480, 0, 8.91, 1336, 1422611187, 1423907187);
INSERT INTO `db_sell_items` VALUES (1047, 'bhbirf906', 221, 8, 0, 0, 0, 0, 0.05, 8, 1422610689, 1423906689);
INSERT INTO `db_sell_items` VALUES (1046, 'shpionka', 166, 54, 111, 805, 759, 3817, 36.97, 5546, 1422610039, 1423906039);
INSERT INTO `db_sell_items` VALUES (1045, 'volume', 237, 59, 0, 0, 0, 0, 0.39, 59, 1422609391, 1423905391);
INSERT INTO `db_sell_items` VALUES (1044, 'shpionka', 166, 48, 99, 719, 678, 3410, 33.03, 4954, 1422609329, 1423905329);
INSERT INTO `db_sell_items` VALUES (1043, 'shpionka', 166, 66, 135, 980, 925, 4648, 45.03, 6754, 1422608690, 1423904690);
INSERT INTO `db_sell_items` VALUES (1042, 'slava3201', 212, 1337, 0, 0, 0, 0, 8.91, 1337, 1422608289, 1423904289);
INSERT INTO `db_sell_items` VALUES (1041, 'shpionka', 166, 54, 115, 833, 786, 3951, 38.26, 5739, 1422607825, 1423903825);
INSERT INTO `db_sell_items` VALUES (1039, 'bhbirf906', 221, 1, 0, 0, 0, 0, 0.01, 1, 1422606788, 1423902788);
INSERT INTO `db_sell_items` VALUES (1040, 'shpionka', 166, 45, 96, 695, 656, 3297, 31.93, 4789, 1422607089, 1423903089);
INSERT INTO `db_sell_items` VALUES (1038, 'shpionka', 166, 1, 0, 0, 0, 0, 0.01, 1, 1422606183, 1423902183);
INSERT INTO `db_sell_items` VALUES (1037, 'bhbirf906', 221, 8, 0, 0, 0, 0, 0.05, 8, 1422606119, 1423902119);
INSERT INTO `db_sell_items` VALUES (1531, '', 1, 0, 0, 0, 0, 17182, 114.55, 17182, 1464020171, 1465316171);
INSERT INTO `db_sell_items` VALUES (1532, '', 1, 0, 0, 0, 0, 73541, 490.27, 73541, 1464025676, 1465321676);
INSERT INTO `db_sell_items` VALUES (1533, '', 300, 528, 0, 0, 0, 0, 3.52, 528, 1473090727, 1474386727);
INSERT INTO `db_sell_items` VALUES (1534, '', 300, 409, 0, 0, 0, 0, 2.73, 409, 1473160781, 1474456781);
INSERT INTO `db_sell_items` VALUES (1535, '', 300, 85, 0, 0, 0, 0, 0.57, 85, 1473175423, 1474471423);
INSERT INTO `db_sell_items` VALUES (1536, '', 300, 340, 0, 0, 0, 0, 2.27, 340, 1473233670, 1474529670);
INSERT INTO `db_sell_items` VALUES (1537, '', 300, 32, 0, 0, 0, 0, 0.21, 32, 1473239421, 1474535421);
INSERT INTO `db_sell_items` VALUES (1538, '', 300, 9, 0, 0, 0, 0, 0.06, 9, 1473241245, 1474537245);
INSERT INTO `db_sell_items` VALUES (1539, '', 300, 8, 0, 0, 0, 0, 0.05, 8, 1473242168, 1474538168);
INSERT INTO `db_sell_items` VALUES (1540, '', 300, 11, 0, 0, 0, 0, 0.07, 11, 1473244153, 1474540153);
INSERT INTO `db_sell_items` VALUES (1541, '', 300, 16, 0, 0, 0, 0, 0.11, 16, 1473246926, 1474542926);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_sender`
-- 

CREATE TABLE `db_sender` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `mess` text NOT NULL,
  `page` int(5) NOT NULL default '0',
  `sended` int(7) NOT NULL default '0',
  `status` int(1) NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=10 ;

-- 
-- ���� ������ ������� `db_sender`
-- 


-- --------------------------------------------------------

-- 
-- ��������� ������� `db_stats`
-- 

CREATE TABLE `db_stats` (
  `id` int(11) NOT NULL auto_increment,
  `all_users` int(11) NOT NULL default '0',
  `all_payments` double NOT NULL default '0',
  `all_insert` double NOT NULL default '0',
  `donations` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

-- 
-- ���� ������ ������� `db_stats`
-- 

INSERT INTO `db_stats` VALUES (1, 301, 333.71, 1273, 475);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_stats_btree`
-- 

CREATE TABLE `db_stats_btree` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `user` varchar(10) NOT NULL default '',
  `tree_name` varchar(10) NOT NULL default '',
  `amount` double NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  `date_del` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1479 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1479 ;

-- 
-- ���� ������ ������� `db_stats_btree`
-- 

INSERT INTO `db_stats_btree` VALUES (830, 166, 'shpionka', 'Тенде', 100, 1422606653, 1423902653);
INSERT INTO `db_stats_btree` VALUES (829, 166, 'shpionka', 'Тенде', 100, 1422606651, 1423902651);
INSERT INTO `db_stats_btree` VALUES (828, 166, 'shpionka', 'Тенде', 100, 1422606650, 1423902650);
INSERT INTO `db_stats_btree` VALUES (827, 166, 'shpionka', 'Тенде', 100, 1422606572, 1423902572);
INSERT INTO `db_stats_btree` VALUES (826, 166, 'shpionka', 'Тенде', 100, 1422606571, 1423902571);
INSERT INTO `db_stats_btree` VALUES (824, 166, 'shpionka', 'Тенде', 100, 1422606569, 1423902569);
INSERT INTO `db_stats_btree` VALUES (825, 166, 'shpionka', 'Тенде', 100, 1422606570, 1423902570);
INSERT INTO `db_stats_btree` VALUES (823, 166, 'shpionka', 'Тенде', 100, 1422606567, 1423902567);
INSERT INTO `db_stats_btree` VALUES (822, 166, 'shpionka', 'Тенде', 100, 1422606566, 1423902566);
INSERT INTO `db_stats_btree` VALUES (821, 166, 'shpionka', 'Тенде', 100, 1422606564, 1423902564);
INSERT INTO `db_stats_btree` VALUES (820, 166, 'shpionka', 'Тенде', 100, 1422606563, 1423902563);
INSERT INTO `db_stats_btree` VALUES (819, 166, 'shpionka', 'Тенде', 100, 1422606562, 1423902562);
INSERT INTO `db_stats_btree` VALUES (818, 166, 'shpionka', 'Тенде', 100, 1422606561, 1423902561);
INSERT INTO `db_stats_btree` VALUES (817, 166, 'shpionka', 'Тенде', 100, 1422606560, 1423902560);
INSERT INTO `db_stats_btree` VALUES (816, 166, 'shpionka', 'Бриг', 5000, 1422606556, 1423902556);
INSERT INTO `db_stats_btree` VALUES (815, 166, 'shpionka', 'Бриг', 5000, 1422606554, 1423902554);
INSERT INTO `db_stats_btree` VALUES (814, 166, 'shpionka', 'Бриг', 5000, 1422606552, 1423902552);
INSERT INTO `db_stats_btree` VALUES (813, 166, 'shpionka', 'Тенде', 100, 1422606545, 1423902545);
INSERT INTO `db_stats_btree` VALUES (812, 166, 'shpionka', 'Тенде', 100, 1422606544, 1423902544);
INSERT INTO `db_stats_btree` VALUES (811, 166, 'shpionka', 'Корве', 25000, 1422606535, 1423902535);
INSERT INTO `db_stats_btree` VALUES (809, 166, 'shpionka', 'Бриг', 5000, 1422606531, 1423902531);
INSERT INTO `db_stats_btree` VALUES (810, 166, 'shpionka', 'Корве', 25000, 1422606533, 1423902533);
INSERT INTO `db_stats_btree` VALUES (808, 166, 'shpionka', 'Бриг', 5000, 1422606525, 1423902525);
INSERT INTO `db_stats_btree` VALUES (807, 166, 'shpionka', 'Бриг', 5000, 1422606523, 1423902523);
INSERT INTO `db_stats_btree` VALUES (806, 166, 'shpionka', 'Бриг', 5000, 1422606522, 1423902522);
INSERT INTO `db_stats_btree` VALUES (805, 166, 'shpionka', 'Бриг', 5000, 1422606521, 1423902521);
INSERT INTO `db_stats_btree` VALUES (803, 166, 'shpionka', 'Тенде', 100, 1422605418, 1423901418);
INSERT INTO `db_stats_btree` VALUES (804, 166, 'shpionka', 'Бриг', 5000, 1422606519, 1423902519);
INSERT INTO `db_stats_btree` VALUES (799, 209, 'fktrc906', 'Тенде', 100, 1422566432, 1423862432);
INSERT INTO `db_stats_btree` VALUES (800, 237, 'volume', 'Тенде', 100, 1422578896, 1423874896);
INSERT INTO `db_stats_btree` VALUES (801, 216, 'GetLens', 'Тенде', 100, 1422592187, 1423888187);
INSERT INTO `db_stats_btree` VALUES (802, 221, 'bhbirf906', 'Тенде', 100, 1422601862, 1423897862);
INSERT INTO `db_stats_btree` VALUES (1220, 166, 'shpionka', 'Тенде', 100, 1423288906, 1424584906);
INSERT INTO `db_stats_btree` VALUES (1219, 166, 'shpionka', 'Тенде', 100, 1423288903, 1424584903);
INSERT INTO `db_stats_btree` VALUES (1218, 166, 'shpionka', 'Тенде', 100, 1423288901, 1424584901);
INSERT INTO `db_stats_btree` VALUES (1217, 166, 'shpionka', 'Тенде', 100, 1423288899, 1424584899);
INSERT INTO `db_stats_btree` VALUES (1216, 166, 'shpionka', 'Шхуна', 1000, 1423288896, 1424584896);
INSERT INTO `db_stats_btree` VALUES (1215, 243, 'toys', 'Тенде', 100, 1423286229, 1424582229);
INSERT INTO `db_stats_btree` VALUES (1214, 243, 'toys', 'Тенде', 100, 1423286227, 1424582227);
INSERT INTO `db_stats_btree` VALUES (1213, 243, 'toys', 'Тенде', 100, 1423286224, 1424582224);
INSERT INTO `db_stats_btree` VALUES (1212, 243, 'toys', 'Тенде', 100, 1423286222, 1424582222);
INSERT INTO `db_stats_btree` VALUES (1211, 243, 'toys', 'Тенде', 100, 1423286219, 1424582219);
INSERT INTO `db_stats_btree` VALUES (1210, 243, 'toys', 'Тенде', 100, 1423286216, 1424582216);
INSERT INTO `db_stats_btree` VALUES (1209, 243, 'toys', 'Тенде', 100, 1423286214, 1424582214);
INSERT INTO `db_stats_btree` VALUES (1208, 243, 'toys', 'Шхуна', 1000, 1423286210, 1424582210);
INSERT INTO `db_stats_btree` VALUES (1207, 228, 'Mixaluch', 'Тенде', 100, 1423281577, 1424577577);
INSERT INTO `db_stats_btree` VALUES (1206, 213, 'Nogar', 'Тенде', 100, 1423269077, 1424565077);
INSERT INTO `db_stats_btree` VALUES (1205, 279, 'Evgeniy888', 'Тенде', 100, 1423264290, 1424560290);
INSERT INTO `db_stats_btree` VALUES (1204, 221, 'bhbirf906', 'Тенде', 100, 1423254801, 1424550801);
INSERT INTO `db_stats_btree` VALUES (1203, 217, 'dens', 'Тенде', 100, 1423253948, 1424549948);
INSERT INTO `db_stats_btree` VALUES (1202, 237, 'volume', 'Тенде', 100, 1423251163, 1424547163);
INSERT INTO `db_stats_btree` VALUES (1201, 237, 'volume', 'Тенде', 100, 1423251163, 1424547163);
INSERT INTO `db_stats_btree` VALUES (1200, 237, 'volume', 'Тенде', 100, 1423251162, 1424547162);
INSERT INTO `db_stats_btree` VALUES (1199, 237, 'volume', 'Тенде', 100, 1423251161, 1424547161);
INSERT INTO `db_stats_btree` VALUES (1198, 237, 'volume', 'Тенде', 100, 1423251151, 1424547151);
INSERT INTO `db_stats_btree` VALUES (1197, 237, 'volume', 'Тенде', 100, 1423251150, 1424547150);
INSERT INTO `db_stats_btree` VALUES (1196, 237, 'volume', 'Тенде', 100, 1423251149, 1424547149);
INSERT INTO `db_stats_btree` VALUES (1195, 183, 'w2mwwm', 'Тенде', 100, 1423248586, 1424544586);
INSERT INTO `db_stats_btree` VALUES (1194, 277, 'SUMRAC', 'Тенде', 100, 1423248463, 1424544463);
INSERT INTO `db_stats_btree` VALUES (1193, 221, 'bhbirf906', 'Тенде', 100, 1423247004, 1424543004);
INSERT INTO `db_stats_btree` VALUES (1192, 166, 'shpionka', 'Тенде', 100, 1423239040, 1424535040);
INSERT INTO `db_stats_btree` VALUES (1191, 166, 'shpionka', 'Тенде', 100, 1423239038, 1424535038);
INSERT INTO `db_stats_btree` VALUES (1190, 166, 'shpionka', 'Тенде', 100, 1423239035, 1424535035);
INSERT INTO `db_stats_btree` VALUES (1189, 166, 'shpionka', 'Тенде', 100, 1423239033, 1424535033);
INSERT INTO `db_stats_btree` VALUES (1188, 166, 'shpionka', 'Тенде', 100, 1423239031, 1424535031);
INSERT INTO `db_stats_btree` VALUES (1187, 166, 'shpionka', 'Шхуна', 1000, 1423239028, 1424535028);
INSERT INTO `db_stats_btree` VALUES (1186, 166, 'shpionka', 'Шхуна', 1000, 1423239025, 1424535025);
INSERT INTO `db_stats_btree` VALUES (1185, 172, 'aleksana', 'Тенде', 100, 1423233816, 1424529816);
INSERT INTO `db_stats_btree` VALUES (1184, 260, 'tornadosta', 'Тенде', 100, 1423231706, 1424527706);
INSERT INTO `db_stats_btree` VALUES (1183, 183, 'w2mwwm', 'Тенде', 100, 1423226176, 1424522176);
INSERT INTO `db_stats_btree` VALUES (1182, 185, 'vitaminka', 'Тенде', 100, 1423223421, 1424519421);
INSERT INTO `db_stats_btree` VALUES (1181, 85, 'rj3111', 'Тенде', 100, 1423219987, 1424515987);
INSERT INTO `db_stats_btree` VALUES (1180, 253, 'Vagan', 'Тенде', 100, 1423218953, 1424514953);
INSERT INTO `db_stats_btree` VALUES (1179, 135, 'denplast', 'Тенде', 100, 1423218233, 1424514233);
INSERT INTO `db_stats_btree` VALUES (1178, 221, 'bhbirf906', 'Тенде', 100, 1423209971, 1424505971);
INSERT INTO `db_stats_btree` VALUES (1177, 243, 'toys', 'Шхуна', 1000, 1423206394, 1424502394);
INSERT INTO `db_stats_btree` VALUES (1176, 166, 'shpionka', 'Тенде', 100, 1423204109, 1424500109);
INSERT INTO `db_stats_btree` VALUES (1175, 166, 'shpionka', 'Тенде', 100, 1423204108, 1424500108);
INSERT INTO `db_stats_btree` VALUES (1174, 166, 'shpionka', 'Тенде', 100, 1423204107, 1424500107);
INSERT INTO `db_stats_btree` VALUES (1173, 166, 'shpionka', 'Тенде', 100, 1423204107, 1424500107);
INSERT INTO `db_stats_btree` VALUES (1172, 166, 'shpionka', 'Тенде', 100, 1423204106, 1424500106);
INSERT INTO `db_stats_btree` VALUES (1171, 166, 'shpionka', 'Тенде', 100, 1423204104, 1424500104);
INSERT INTO `db_stats_btree` VALUES (1170, 166, 'shpionka', 'Шхуна', 1000, 1423204102, 1424500102);
INSERT INTO `db_stats_btree` VALUES (1169, 166, 'shpionka', 'Шхуна', 1000, 1423204101, 1424500101);
INSERT INTO `db_stats_btree` VALUES (1168, 231, 'palpalyh', 'Тенде', 100, 1423199915, 1424495915);
INSERT INTO `db_stats_btree` VALUES (1167, 194, 'kukanik', 'Тенде', 100, 1423195464, 1424491464);
INSERT INTO `db_stats_btree` VALUES (1166, 228, 'Mixaluch', 'Тенде', 100, 1423195170, 1424491170);
INSERT INTO `db_stats_btree` VALUES (1165, 216, 'GetLens', 'Тенде', 100, 1423194492, 1424490492);
INSERT INTO `db_stats_btree` VALUES (1164, 161, 'KOLJUNJA', 'Тенде', 100, 1423172645, 1424468645);
INSERT INTO `db_stats_btree` VALUES (1163, 155, 'Kastaneda', 'Тенде', 100, 1423171420, 1424467420);
INSERT INTO `db_stats_btree` VALUES (1162, 237, 'volume', 'Тенде', 100, 1423170352, 1424466352);
INSERT INTO `db_stats_btree` VALUES (1161, 221, 'bhbirf906', 'Тенде', 100, 1423167268, 1424463268);
INSERT INTO `db_stats_btree` VALUES (1160, 183, 'w2mwwm', 'Тенде', 100, 1423162492, 1424458492);
INSERT INTO `db_stats_btree` VALUES (1159, 221, 'bhbirf906', 'Тенде', 100, 1423160771, 1424456771);
INSERT INTO `db_stats_btree` VALUES (1158, 237, 'volume', 'Тенде', 100, 1423152930, 1424448930);
INSERT INTO `db_stats_btree` VALUES (1157, 237, 'volume', 'Тенде', 100, 1423152929, 1424448929);
INSERT INTO `db_stats_btree` VALUES (1156, 221, 'bhbirf906', 'Тенде', 100, 1423150141, 1424446141);
INSERT INTO `db_stats_btree` VALUES (1155, 183, 'w2mwwm', 'Тенде', 100, 1423143748, 1424439748);
INSERT INTO `db_stats_btree` VALUES (1154, 260, 'tornadosta', 'Тенде', 100, 1423140742, 1424436742);
INSERT INTO `db_stats_btree` VALUES (1153, 166, 'shpionka', 'Тенде', 100, 1423132130, 1424428130);
INSERT INTO `db_stats_btree` VALUES (1152, 166, 'shpionka', 'Тенде', 100, 1423132129, 1424428129);
INSERT INTO `db_stats_btree` VALUES (1151, 166, 'shpionka', 'Тенде', 100, 1423132128, 1424428128);
INSERT INTO `db_stats_btree` VALUES (1150, 166, 'shpionka', 'Тенде', 100, 1423132126, 1424428126);
INSERT INTO `db_stats_btree` VALUES (1149, 244, 'amince', 'Тенде', 100, 1423123680, 1424419680);
INSERT INTO `db_stats_btree` VALUES (1148, 105, 'mimi877', 'Тенде', 100, 1423123617, 1424419617);
INSERT INTO `db_stats_btree` VALUES (1147, 183, 'w2mwwm', 'Тенде', 100, 1423121942, 1424417942);
INSERT INTO `db_stats_btree` VALUES (1146, 166, 'shpionka', 'Тенде', 100, 1423121455, 1424417455);
INSERT INTO `db_stats_btree` VALUES (1145, 166, 'shpionka', 'Тенде', 100, 1423121453, 1424417453);
INSERT INTO `db_stats_btree` VALUES (1144, 166, 'shpionka', 'Тенде', 100, 1423121452, 1424417452);
INSERT INTO `db_stats_btree` VALUES (1143, 166, 'shpionka', 'Шхуна', 1000, 1423121451, 1424417451);
INSERT INTO `db_stats_btree` VALUES (1142, 166, 'shpionka', 'Шхуна', 1000, 1423121450, 1424417450);
INSERT INTO `db_stats_btree` VALUES (1141, 243, 'toys', 'Шхуна', 1000, 1423117118, 1424413118);
INSERT INTO `db_stats_btree` VALUES (1140, 237, 'volume', 'Тенде', 100, 1423115698, 1424411698);
INSERT INTO `db_stats_btree` VALUES (1139, 231, 'palpalyh', 'Тенде', 100, 1423113102, 1424409102);
INSERT INTO `db_stats_btree` VALUES (1138, 219, 'ZET1', 'Тенде', 100, 1423102564, 1424398564);
INSERT INTO `db_stats_btree` VALUES (1137, 213, 'Nogar', 'Тенде', 100, 1423091456, 1424387456);
INSERT INTO `db_stats_btree` VALUES (1136, 183, 'w2mwwm', 'Тенде', 100, 1423078858, 1424374858);
INSERT INTO `db_stats_btree` VALUES (1135, 221, 'bhbirf906', 'Тенде', 100, 1423077969, 1424373969);
INSERT INTO `db_stats_btree` VALUES (1134, 270, 'cariden', 'Тенде', 100, 1423077327, 1424373327);
INSERT INTO `db_stats_btree` VALUES (1133, 207, 'Deit15', 'Тенде', 100, 1423074272, 1424370272);
INSERT INTO `db_stats_btree` VALUES (1132, 237, 'volume', 'Тенде', 100, 1423073058, 1424369058);
INSERT INTO `db_stats_btree` VALUES (1131, 237, 'volume', 'Тенде', 100, 1423073057, 1424369057);
INSERT INTO `db_stats_btree` VALUES (1130, 237, 'volume', 'Тенде', 100, 1423073056, 1424369056);
INSERT INTO `db_stats_btree` VALUES (1129, 260, 'tornadosta', 'Тенде', 100, 1423070353, 1424366353);
INSERT INTO `db_stats_btree` VALUES (1128, 85, 'rj3111', 'Тенде', 100, 1423064671, 1424360671);
INSERT INTO `db_stats_btree` VALUES (1127, 228, 'Mixaluch', 'Тенде', 100, 1423063434, 1424359434);
INSERT INTO `db_stats_btree` VALUES (1126, 185, 'vitaminka', 'Тенде', 100, 1423061745, 1424357745);
INSERT INTO `db_stats_btree` VALUES (1125, 166, 'shpionka', 'Тенде', 100, 1423060530, 1424356530);
INSERT INTO `db_stats_btree` VALUES (1124, 166, 'shpionka', 'Тенде', 100, 1423060528, 1424356528);
INSERT INTO `db_stats_btree` VALUES (1123, 166, 'shpionka', 'Тенде', 100, 1423060528, 1424356528);
INSERT INTO `db_stats_btree` VALUES (1122, 166, 'shpionka', 'Тенде', 100, 1423060527, 1424356527);
INSERT INTO `db_stats_btree` VALUES (1121, 166, 'shpionka', 'Тенде', 100, 1423060526, 1424356526);
INSERT INTO `db_stats_btree` VALUES (1120, 221, 'bhbirf906', 'Тенде', 100, 1423059552, 1424355552);
INSERT INTO `db_stats_btree` VALUES (1119, 105, 'mimi877', 'Тенде', 100, 1423051873, 1424347873);
INSERT INTO `db_stats_btree` VALUES (1118, 183, 'w2mwwm', 'Тенде', 100, 1423051303, 1424347303);
INSERT INTO `db_stats_btree` VALUES (1117, 166, 'shpionka', 'Тенде', 100, 1423046380, 1424342380);
INSERT INTO `db_stats_btree` VALUES (1116, 166, 'shpionka', 'Тенде', 100, 1423046378, 1424342378);
INSERT INTO `db_stats_btree` VALUES (1115, 135, 'denplast', 'Тенде', 100, 1423044807, 1424340807);
INSERT INTO `db_stats_btree` VALUES (1114, 166, 'shpionka', 'Тенде', 100, 1423042496, 1424338496);
INSERT INTO `db_stats_btree` VALUES (1113, 166, 'shpionka', 'Шхуна', 1000, 1423042495, 1424338495);
INSERT INTO `db_stats_btree` VALUES (1112, 166, 'shpionka', 'Шхуна', 1000, 1423042494, 1424338494);
INSERT INTO `db_stats_btree` VALUES (1111, 183, 'w2mwwm', 'Тенде', 100, 1423036369, 1424332369);
INSERT INTO `db_stats_btree` VALUES (1110, 217, 'dens', 'Тенде', 100, 1423034314, 1424330314);
INSERT INTO `db_stats_btree` VALUES (1109, 155, 'Kastaneda', 'Тенде', 100, 1422998557, 1424294557);
INSERT INTO `db_stats_btree` VALUES (1108, 221, 'bhbirf906', 'Тенде', 100, 1422998269, 1424294269);
INSERT INTO `db_stats_btree` VALUES (1107, 237, 'volume', 'Тенде', 100, 1422992628, 1424288628);
INSERT INTO `db_stats_btree` VALUES (1106, 183, 'w2mwwm', 'Тенде', 100, 1422990121, 1424286121);
INSERT INTO `db_stats_btree` VALUES (1105, 221, 'bhbirf906', 'Тенде', 100, 1422987011, 1424283011);
INSERT INTO `db_stats_btree` VALUES (1104, 243, 'toys', 'Тенде', 100, 1422983131, 1424279131);
INSERT INTO `db_stats_btree` VALUES (1103, 243, 'toys', 'Тенде', 100, 1422983127, 1424279127);
INSERT INTO `db_stats_btree` VALUES (1102, 243, 'toys', 'Тенде', 100, 1422983123, 1424279123);
INSERT INTO `db_stats_btree` VALUES (1101, 166, 'shpionka', 'Тенде', 100, 1422982301, 1424278301);
INSERT INTO `db_stats_btree` VALUES (1100, 166, 'shpionka', 'Тенде', 100, 1422982299, 1424278299);
INSERT INTO `db_stats_btree` VALUES (1099, 166, 'shpionka', 'Тенде', 100, 1422982296, 1424278296);
INSERT INTO `db_stats_btree` VALUES (1098, 72, 'sarita', 'Тенде', 100, 1422981122, 1424277122);
INSERT INTO `db_stats_btree` VALUES (1097, 260, 'tornadosta', 'Тенде', 100, 1422980019, 1424276019);
INSERT INTO `db_stats_btree` VALUES (1096, 232, 'olegator74', 'Тенде', 100, 1422978401, 1424274401);
INSERT INTO `db_stats_btree` VALUES (1095, 166, 'shpionka', 'Тенде', 100, 1422974539, 1424270539);
INSERT INTO `db_stats_btree` VALUES (1094, 166, 'shpionka', 'Тенде', 100, 1422974537, 1424270537);
INSERT INTO `db_stats_btree` VALUES (1093, 166, 'shpionka', 'Тенде', 100, 1422974536, 1424270536);
INSERT INTO `db_stats_btree` VALUES (1092, 166, 'shpionka', 'Шхуна', 1000, 1422974534, 1424270534);
INSERT INTO `db_stats_btree` VALUES (1091, 250, 'andron1144', 'Тенде', 100, 1422972750, 1424268750);
INSERT INTO `db_stats_btree` VALUES (1090, 194, 'kukanik', 'Тенде', 100, 1422970817, 1424266817);
INSERT INTO `db_stats_btree` VALUES (1089, 166, 'shpionka', 'Тенде', 100, 1422952638, 1424248638);
INSERT INTO `db_stats_btree` VALUES (1088, 166, 'shpionka', 'Тенде', 100, 1422952636, 1424248636);
INSERT INTO `db_stats_btree` VALUES (1087, 166, 'shpionka', 'Тенде', 100, 1422952635, 1424248635);
INSERT INTO `db_stats_btree` VALUES (1086, 166, 'shpionka', 'Тенде', 100, 1422952634, 1424248634);
INSERT INTO `db_stats_btree` VALUES (1085, 243, 'toys', 'Тенде', 100, 1422950623, 1424246623);
INSERT INTO `db_stats_btree` VALUES (1084, 243, 'toys', 'Тенде', 100, 1422950620, 1424246620);
INSERT INTO `db_stats_btree` VALUES (1083, 243, 'toys', 'Тенде', 100, 1422950617, 1424246617);
INSERT INTO `db_stats_btree` VALUES (1082, 243, 'toys', 'Тенде', 100, 1422950614, 1424246614);
INSERT INTO `db_stats_btree` VALUES (1081, 243, 'toys', 'Шхуна', 1000, 1422950611, 1424246611);
INSERT INTO `db_stats_btree` VALUES (1080, 237, 'volume', 'Тенде', 100, 1422950390, 1424246390);
INSERT INTO `db_stats_btree` VALUES (1079, 183, 'w2mwwm', 'Тенде', 100, 1422947500, 1424243500);
INSERT INTO `db_stats_btree` VALUES (1078, 166, 'shpionka', 'Тенде', 100, 1422944500, 1424240500);
INSERT INTO `db_stats_btree` VALUES (1077, 166, 'shpionka', 'Тенде', 100, 1422944498, 1424240498);
INSERT INTO `db_stats_btree` VALUES (1076, 166, 'shpionka', 'Тенде', 100, 1422944496, 1424240496);
INSERT INTO `db_stats_btree` VALUES (1075, 166, 'shpionka', 'Тенде', 100, 1422944495, 1424240495);
INSERT INTO `db_stats_btree` VALUES (1074, 166, 'shpionka', 'Тенде', 100, 1422944494, 1424240494);
INSERT INTO `db_stats_btree` VALUES (1073, 166, 'shpionka', 'Шхуна', 1000, 1422944492, 1424240492);
INSERT INTO `db_stats_btree` VALUES (1072, 231, 'palpalyh', 'Тенде', 100, 1422937478, 1424233478);
INSERT INTO `db_stats_btree` VALUES (1071, 237, 'volume', 'Тенде', 100, 1422916789, 1424212789);
INSERT INTO `db_stats_btree` VALUES (1070, 221, 'bhbirf906', 'Тенде', 100, 1422911059, 1424207059);
INSERT INTO `db_stats_btree` VALUES (1069, 219, 'ZET1', 'Тенде', 100, 1422907921, 1424203921);
INSERT INTO `db_stats_btree` VALUES (1068, 239, 'karolina55', 'Тенде', 100, 1422907082, 1424203082);
INSERT INTO `db_stats_btree` VALUES (1067, 237, 'volume', 'Тенде', 100, 1422906085, 1424202085);
INSERT INTO `db_stats_btree` VALUES (1066, 237, 'volume', 'Тенде', 100, 1422906084, 1424202084);
INSERT INTO `db_stats_btree` VALUES (1065, 228, 'Mixaluch', 'Тенде', 100, 1422904845, 1424200845);
INSERT INTO `db_stats_btree` VALUES (1064, 166, 'shpionka', 'Тенде', 100, 1422898999, 1424194999);
INSERT INTO `db_stats_btree` VALUES (1063, 166, 'shpionka', 'Тенде', 100, 1422898996, 1424194996);
INSERT INTO `db_stats_btree` VALUES (1062, 166, 'shpionka', 'Тенде', 100, 1422898994, 1424194994);
INSERT INTO `db_stats_btree` VALUES (1061, 166, 'shpionka', 'Тенде', 100, 1422898992, 1424194992);
INSERT INTO `db_stats_btree` VALUES (1060, 166, 'shpionka', 'Тенде', 100, 1422898990, 1424194990);
INSERT INTO `db_stats_btree` VALUES (1059, 243, 'toys', 'Шхуна', 1000, 1422898211, 1424194211);
INSERT INTO `db_stats_btree` VALUES (1058, 85, 'rj3111', 'Тенде', 100, 1422896879, 1424192879);
INSERT INTO `db_stats_btree` VALUES (1057, 221, 'bhbirf906', 'Тенде', 100, 1422891802, 1424187802);
INSERT INTO `db_stats_btree` VALUES (1056, 166, 'shpionka', 'Тенде', 100, 1422884461, 1424180461);
INSERT INTO `db_stats_btree` VALUES (1055, 166, 'shpionka', 'Тенде', 100, 1422884459, 1424180459);
INSERT INTO `db_stats_btree` VALUES (1054, 72, 'sarita', 'Тенде', 100, 1422883383, 1424179383);
INSERT INTO `db_stats_btree` VALUES (1053, 166, 'shpionka', 'Тенде', 100, 1422880940, 1424176940);
INSERT INTO `db_stats_btree` VALUES (1052, 166, 'shpionka', 'Тенде', 100, 1422880939, 1424176939);
INSERT INTO `db_stats_btree` VALUES (1051, 166, 'shpionka', 'Тенде', 100, 1422880938, 1424176938);
INSERT INTO `db_stats_btree` VALUES (1050, 166, 'shpionka', 'Тенде', 100, 1422880907, 1424176907);
INSERT INTO `db_stats_btree` VALUES (1049, 160, 'vigenpt', 'Тенде', 100, 1422878890, 1424174890);
INSERT INTO `db_stats_btree` VALUES (1048, 166, 'shpionka', 'Тенде', 100, 1422876874, 1424172874);
INSERT INTO `db_stats_btree` VALUES (1047, 166, 'shpionka', 'Тенде', 100, 1422876873, 1424172873);
INSERT INTO `db_stats_btree` VALUES (1046, 166, 'shpionka', 'Тенде', 100, 1422873198, 1424169198);
INSERT INTO `db_stats_btree` VALUES (1045, 166, 'shpionka', 'Тенде', 100, 1422872025, 1424168025);
INSERT INTO `db_stats_btree` VALUES (1044, 166, 'shpionka', 'Тенде', 100, 1422872023, 1424168023);
INSERT INTO `db_stats_btree` VALUES (1043, 135, 'denplast', 'Тенде', 100, 1422869575, 1424165575);
INSERT INTO `db_stats_btree` VALUES (1042, 221, 'bhbirf906', 'Тенде', 100, 1422867398, 1424163398);
INSERT INTO `db_stats_btree` VALUES (1041, 166, 'shpionka', 'Тенде', 100, 1422866499, 1424162499);
INSERT INTO `db_stats_btree` VALUES (1040, 166, 'shpionka', 'Тенде', 100, 1422866497, 1424162497);
INSERT INTO `db_stats_btree` VALUES (1039, 166, 'shpionka', 'Тенде', 100, 1422866496, 1424162496);
INSERT INTO `db_stats_btree` VALUES (1038, 105, 'mimi877', 'Тенде', 100, 1422862405, 1424158405);
INSERT INTO `db_stats_btree` VALUES (1037, 183, 'w2mwwm', 'Тенде', 100, 1422857031, 1424153031);
INSERT INTO `db_stats_btree` VALUES (1036, 166, 'shpionka', 'Шхуна', 1000, 1422856677, 1424152677);
INSERT INTO `db_stats_btree` VALUES (1035, 166, 'shpionka', 'Шхуна', 1000, 1422856676, 1424152676);
INSERT INTO `db_stats_btree` VALUES (1034, 237, 'volume', 'Тенде', 100, 1422828578, 1424124578);
INSERT INTO `db_stats_btree` VALUES (1033, 237, 'volume', 'Тенде', 100, 1422828577, 1424124577);
INSERT INTO `db_stats_btree` VALUES (1032, 148, 'mixail', 'Тенде', 100, 1422822584, 1424118584);
INSERT INTO `db_stats_btree` VALUES (1031, 221, 'bhbirf906', 'Тенде', 100, 1422819595, 1424115595);
INSERT INTO `db_stats_btree` VALUES (1030, 228, 'Mixaluch', 'Тенде', 100, 1422818195, 1424114195);
INSERT INTO `db_stats_btree` VALUES (1029, 252, 'a100500q', 'Тенде', 100, 1422814662, 1424110662);
INSERT INTO `db_stats_btree` VALUES (1028, 252, 'a100500q', 'Тенде', 100, 1422814660, 1424110660);
INSERT INTO `db_stats_btree` VALUES (1027, 252, 'a100500q', 'Тенде', 100, 1422814659, 1424110659);
INSERT INTO `db_stats_btree` VALUES (1026, 252, 'a100500q', 'Тенде', 100, 1422814657, 1424110657);
INSERT INTO `db_stats_btree` VALUES (1025, 252, 'a100500q', 'Тенде', 100, 1422814656, 1424110656);
INSERT INTO `db_stats_btree` VALUES (1024, 216, 'GetLens', 'Тенде', 100, 1422809388, 1424105388);
INSERT INTO `db_stats_btree` VALUES (1023, 72, 'sarita', 'Шхуна', 1000, 1422808013, 1424104013);
INSERT INTO `db_stats_btree` VALUES (1022, 72, 'sarita', 'Шхуна', 1000, 1422808013, 1424104013);
INSERT INTO `db_stats_btree` VALUES (1021, 72, 'sarita', 'Шхуна', 1000, 1422808013, 1424104013);
INSERT INTO `db_stats_btree` VALUES (1020, 72, 'sarita', 'Шхуна', 1000, 1422808012, 1424104012);
INSERT INTO `db_stats_btree` VALUES (1019, 72, 'sarita', 'Шхуна', 1000, 1422808012, 1424104012);
INSERT INTO `db_stats_btree` VALUES (1018, 221, 'bhbirf906', 'Тенде', 100, 1422802088, 1424098088);
INSERT INTO `db_stats_btree` VALUES (1017, 166, 'shpionka', 'Тенде', 100, 1422800763, 1424096763);
INSERT INTO `db_stats_btree` VALUES (1016, 166, 'shpionka', 'Тенде', 100, 1422800761, 1424096761);
INSERT INTO `db_stats_btree` VALUES (1015, 166, 'shpionka', 'Тенде', 100, 1422800759, 1424096759);
INSERT INTO `db_stats_btree` VALUES (1014, 166, 'shpionka', 'Тенде', 100, 1422800757, 1424096757);
INSERT INTO `db_stats_btree` VALUES (1013, 243, 'toys', 'Тенде', 100, 1422800317, 1424096317);
INSERT INTO `db_stats_btree` VALUES (1012, 243, 'toys', 'Тенде', 100, 1422800297, 1424096297);
INSERT INTO `db_stats_btree` VALUES (1011, 243, 'toys', 'Тенде', 100, 1422800295, 1424096295);
INSERT INTO `db_stats_btree` VALUES (1010, 243, 'toys', 'Тенде', 100, 1422800293, 1424096293);
INSERT INTO `db_stats_btree` VALUES (1009, 243, 'toys', 'Тенде', 100, 1422800292, 1424096292);
INSERT INTO `db_stats_btree` VALUES (1008, 243, 'toys', 'Тенде', 100, 1422800290, 1424096290);
INSERT INTO `db_stats_btree` VALUES (1007, 243, 'toys', 'Тенде', 100, 1422800288, 1424096288);
INSERT INTO `db_stats_btree` VALUES (1006, 243, 'toys', 'Тенде', 100, 1422800286, 1424096286);
INSERT INTO `db_stats_btree` VALUES (1005, 243, 'toys', 'Шхуна', 1000, 1422800281, 1424096281);
INSERT INTO `db_stats_btree` VALUES (1004, 50, 'Aleksandr1', 'Тенде', 100, 1422794314, 1424090314);
INSERT INTO `db_stats_btree` VALUES (1003, 166, 'shpionka', 'Тенде', 100, 1422790552, 1424086552);
INSERT INTO `db_stats_btree` VALUES (1002, 166, 'shpionka', 'Тенде', 100, 1422790538, 1424086538);
INSERT INTO `db_stats_btree` VALUES (1001, 166, 'shpionka', 'Тенде', 100, 1422790536, 1424086536);
INSERT INTO `db_stats_btree` VALUES (1000, 166, 'shpionka', 'Тенде', 100, 1422790534, 1424086534);
INSERT INTO `db_stats_btree` VALUES (999, 198, 'sarapul', 'Тенде', 100, 1422786829, 1424082829);
INSERT INTO `db_stats_btree` VALUES (998, 85, 'rj3111', 'Тенде', 100, 1422786492, 1424082492);
INSERT INTO `db_stats_btree` VALUES (997, 166, 'shpionka', 'Тенде', 100, 1422786276, 1424082276);
INSERT INTO `db_stats_btree` VALUES (996, 166, 'shpionka', 'Тенде', 100, 1422786274, 1424082274);
INSERT INTO `db_stats_btree` VALUES (995, 166, 'shpionka', 'Тенде', 100, 1422786271, 1424082271);
INSERT INTO `db_stats_btree` VALUES (994, 166, 'shpionka', 'Тенде', 100, 1422786269, 1424082269);
INSERT INTO `db_stats_btree` VALUES (993, 166, 'shpionka', 'Тенде', 100, 1422786267, 1424082267);
INSERT INTO `db_stats_btree` VALUES (992, 166, 'shpionka', 'Тенде', 100, 1422786264, 1424082264);
INSERT INTO `db_stats_btree` VALUES (991, 221, 'bhbirf906', 'Тенде', 100, 1422780608, 1424076608);
INSERT INTO `db_stats_btree` VALUES (990, 252, 'a100500q', 'Тенде', 100, 1422776801, 1424072801);
INSERT INTO `db_stats_btree` VALUES (989, 252, 'a100500q', 'Тенде', 100, 1422776799, 1424072799);
INSERT INTO `db_stats_btree` VALUES (988, 252, 'a100500q', 'Тенде', 100, 1422776797, 1424072797);
INSERT INTO `db_stats_btree` VALUES (987, 252, 'a100500q', 'Бриг', 5000, 1422776794, 1424072794);
INSERT INTO `db_stats_btree` VALUES (986, 252, 'a100500q', 'Бриг', 5000, 1422776792, 1424072792);
INSERT INTO `db_stats_btree` VALUES (985, 252, 'a100500q', 'Тенде', 100, 1422776524, 1424072524);
INSERT INTO `db_stats_btree` VALUES (984, 252, 'a100500q', 'Тенде', 100, 1422776521, 1424072521);
INSERT INTO `db_stats_btree` VALUES (983, 232, 'olegator74', 'Тенде', 100, 1422775898, 1424071898);
INSERT INTO `db_stats_btree` VALUES (982, 166, 'shpionka', 'Тенде', 100, 1422770261, 1424066261);
INSERT INTO `db_stats_btree` VALUES (981, 166, 'shpionka', 'Тенде', 100, 1422770257, 1424066257);
INSERT INTO `db_stats_btree` VALUES (980, 166, 'shpionka', 'Тенде', 100, 1422770255, 1424066255);
INSERT INTO `db_stats_btree` VALUES (979, 166, 'shpionka', 'Шхуна', 1000, 1422770251, 1424066251);
INSERT INTO `db_stats_btree` VALUES (978, 221, 'bhbirf906', 'Тенде', 100, 1422770118, 1424066118);
INSERT INTO `db_stats_btree` VALUES (977, 219, 'ZET1', 'Тенде', 100, 1422742764, 1424038764);
INSERT INTO `db_stats_btree` VALUES (976, 183, 'w2mwwm', 'Тенде', 100, 1422741596, 1424037596);
INSERT INTO `db_stats_btree` VALUES (975, 166, 'shpionka', 'Тенде', 100, 1422732330, 1424028330);
INSERT INTO `db_stats_btree` VALUES (974, 166, 'shpionka', 'Тенде', 100, 1422732327, 1424028327);
INSERT INTO `db_stats_btree` VALUES (973, 166, 'shpionka', 'Тенде', 100, 1422732325, 1424028325);
INSERT INTO `db_stats_btree` VALUES (972, 166, 'shpionka', 'Тенде', 100, 1422732323, 1424028323);
INSERT INTO `db_stats_btree` VALUES (971, 166, 'shpionka', 'Тенде', 100, 1422732320, 1424028320);
INSERT INTO `db_stats_btree` VALUES (970, 63, 'Best', 'Тенде', 100, 1422730118, 1424026118);
INSERT INTO `db_stats_btree` VALUES (969, 228, 'Mixaluch', 'Тенде', 100, 1422728596, 1424024596);
INSERT INTO `db_stats_btree` VALUES (968, 237, 'volume', 'Тенде', 100, 1422724156, 1424020156);
INSERT INTO `db_stats_btree` VALUES (967, 237, 'volume', 'Тенде', 100, 1422724155, 1424020155);
INSERT INTO `db_stats_btree` VALUES (966, 194, 'kukanik', 'Тенде', 100, 1422724060, 1424020060);
INSERT INTO `db_stats_btree` VALUES (965, 245, 'Erejep', 'Тенде', 100, 1422720036, 1424016036);
INSERT INTO `db_stats_btree` VALUES (964, 166, 'shpionka', 'Тенде', 100, 1422718832, 1424014832);
INSERT INTO `db_stats_btree` VALUES (963, 166, 'shpionka', 'Тенде', 100, 1422718829, 1424014829);
INSERT INTO `db_stats_btree` VALUES (962, 166, 'shpionka', 'Тенде', 100, 1422718827, 1424014827);
INSERT INTO `db_stats_btree` VALUES (961, 166, 'shpionka', 'Тенде', 100, 1422718824, 1424014824);
INSERT INTO `db_stats_btree` VALUES (960, 166, 'shpionka', 'Тенде', 100, 1422718822, 1424014822);
INSERT INTO `db_stats_btree` VALUES (959, 166, 'shpionka', 'Тенде', 100, 1422718818, 1424014818);
INSERT INTO `db_stats_btree` VALUES (958, 183, 'w2mwwm', 'Тенде', 100, 1422718720, 1424014720);
INSERT INTO `db_stats_btree` VALUES (957, 221, 'bhbirf906', 'Тенде', 100, 1422713903, 1424009903);
INSERT INTO `db_stats_btree` VALUES (956, 221, 'bhbirf906', 'Тенде', 100, 1422702823, 1423998823);
INSERT INTO `db_stats_btree` VALUES (955, 252, 'a100500q', 'Тенде', 100, 1422700757, 1423996757);
INSERT INTO `db_stats_btree` VALUES (954, 252, 'a100500q', 'Тенде', 100, 1422700756, 1423996756);
INSERT INTO `db_stats_btree` VALUES (953, 252, 'a100500q', 'Тенде', 100, 1422700754, 1423996754);
INSERT INTO `db_stats_btree` VALUES (952, 252, 'a100500q', 'Тенде', 100, 1422700753, 1423996753);
INSERT INTO `db_stats_btree` VALUES (951, 252, 'a100500q', 'Тенде', 100, 1422700751, 1423996751);
INSERT INTO `db_stats_btree` VALUES (950, 252, 'a100500q', 'Тенде', 100, 1422700749, 1423996749);
INSERT INTO `db_stats_btree` VALUES (949, 252, 'a100500q', 'Тенде', 100, 1422700748, 1423996748);
INSERT INTO `db_stats_btree` VALUES (948, 252, 'a100500q', 'Тенде', 100, 1422700746, 1423996746);
INSERT INTO `db_stats_btree` VALUES (947, 252, 'a100500q', 'Тенде', 100, 1422700744, 1423996744);
INSERT INTO `db_stats_btree` VALUES (946, 252, 'a100500q', 'Шхуна', 1000, 1422700123, 1423996123);
INSERT INTO `db_stats_btree` VALUES (945, 252, 'a100500q', 'Шхуна', 1000, 1422700116, 1423996116);
INSERT INTO `db_stats_btree` VALUES (944, 252, 'a100500q', 'Шхуна', 1000, 1422700108, 1423996108);
INSERT INTO `db_stats_btree` VALUES (943, 252, 'a100500q', 'Шхуна', 1000, 1422700103, 1423996103);
INSERT INTO `db_stats_btree` VALUES (942, 252, 'a100500q', 'Шхуна', 1000, 1422700101, 1423996101);
INSERT INTO `db_stats_btree` VALUES (941, 252, 'a100500q', 'Шхуна', 1000, 1422700100, 1423996100);
INSERT INTO `db_stats_btree` VALUES (940, 252, 'a100500q', 'Шхуна', 1000, 1422700098, 1423996098);
INSERT INTO `db_stats_btree` VALUES (939, 252, 'a100500q', 'Шхуна', 1000, 1422700097, 1423996097);
INSERT INTO `db_stats_btree` VALUES (938, 252, 'a100500q', 'Шхуна', 1000, 1422700095, 1423996095);
INSERT INTO `db_stats_btree` VALUES (937, 252, 'a100500q', 'Шхуна', 1000, 1422700094, 1423996094);
INSERT INTO `db_stats_btree` VALUES (936, 252, 'a100500q', 'Шхуна', 1000, 1422700092, 1423996092);
INSERT INTO `db_stats_btree` VALUES (935, 252, 'a100500q', 'Шхуна', 1000, 1422700090, 1423996090);
INSERT INTO `db_stats_btree` VALUES (934, 252, 'a100500q', 'Шхуна', 1000, 1422700089, 1423996089);
INSERT INTO `db_stats_btree` VALUES (933, 252, 'a100500q', 'Шхуна', 1000, 1422700086, 1423996086);
INSERT INTO `db_stats_btree` VALUES (932, 252, 'a100500q', 'Шхуна', 1000, 1422700085, 1423996085);
INSERT INTO `db_stats_btree` VALUES (931, 252, 'a100500q', 'Шхуна', 1000, 1422700083, 1423996083);
INSERT INTO `db_stats_btree` VALUES (930, 252, 'a100500q', 'Шхуна', 1000, 1422700080, 1423996080);
INSERT INTO `db_stats_btree` VALUES (929, 252, 'a100500q', 'Шхуна', 1000, 1422700078, 1423996078);
INSERT INTO `db_stats_btree` VALUES (928, 252, 'a100500q', 'Шхуна', 1000, 1422700074, 1423996074);
INSERT INTO `db_stats_btree` VALUES (927, 166, 'shpionka', 'Тенде', 100, 1422700054, 1423996054);
INSERT INTO `db_stats_btree` VALUES (926, 166, 'shpionka', 'Тенде', 100, 1422700051, 1423996051);
INSERT INTO `db_stats_btree` VALUES (925, 166, 'shpionka', 'Тенде', 100, 1422700049, 1423996049);
INSERT INTO `db_stats_btree` VALUES (924, 166, 'shpionka', 'Тенде', 100, 1422700047, 1423996047);
INSERT INTO `db_stats_btree` VALUES (923, 166, 'shpionka', 'Тенде', 100, 1422699933, 1423995933);
INSERT INTO `db_stats_btree` VALUES (922, 166, 'shpionka', 'Тенде', 100, 1422699931, 1423995931);
INSERT INTO `db_stats_btree` VALUES (921, 166, 'shpionka', 'Тенде', 100, 1422699928, 1423995928);
INSERT INTO `db_stats_btree` VALUES (920, 166, 'shpionka', 'Тенде', 100, 1422699926, 1423995926);
INSERT INTO `db_stats_btree` VALUES (919, 166, 'shpionka', 'Тенде', 100, 1422699924, 1423995924);
INSERT INTO `db_stats_btree` VALUES (918, 166, 'shpionka', 'Тенде', 100, 1422699921, 1423995921);
INSERT INTO `db_stats_btree` VALUES (917, 201, 'stupak62', 'Тенде', 100, 1422697426, 1423993426);
INSERT INTO `db_stats_btree` VALUES (916, 201, 'stupak62', 'Тенде', 100, 1422697424, 1423993424);
INSERT INTO `db_stats_btree` VALUES (915, 250, 'andron1144', 'Тенде', 100, 1422695574, 1423991574);
INSERT INTO `db_stats_btree` VALUES (914, 135, 'denplast', 'Тенде', 100, 1422693994, 1423989994);
INSERT INTO `db_stats_btree` VALUES (913, 105, 'mimi877', 'Тенде', 100, 1422693143, 1423989143);
INSERT INTO `db_stats_btree` VALUES (912, 183, 'w2mwwm', 'Тенде', 100, 1422687603, 1423983603);
INSERT INTO `db_stats_btree` VALUES (911, 166, 'shpionka', 'Тенде', 100, 1422684719, 1423980719);
INSERT INTO `db_stats_btree` VALUES (910, 166, 'shpionka', 'Тенде', 100, 1422684716, 1423980716);
INSERT INTO `db_stats_btree` VALUES (909, 166, 'shpionka', 'Тенде', 100, 1422684714, 1423980714);
INSERT INTO `db_stats_btree` VALUES (908, 166, 'shpionka', 'Тенде', 100, 1422684712, 1423980712);
INSERT INTO `db_stats_btree` VALUES (907, 166, 'shpionka', 'Тенде', 100, 1422684709, 1423980709);
INSERT INTO `db_stats_btree` VALUES (906, 166, 'shpionka', 'Шхуна', 1000, 1422684706, 1423980706);
INSERT INTO `db_stats_btree` VALUES (905, 237, 'volume', 'Тенде', 100, 1422682793, 1423978793);
INSERT INTO `db_stats_btree` VALUES (904, 237, 'volume', 'Тенде', 100, 1422682792, 1423978792);
INSERT INTO `db_stats_btree` VALUES (903, 237, 'volume', 'Тенде', 100, 1422682791, 1423978791);
INSERT INTO `db_stats_btree` VALUES (902, 221, 'bhbirf906', 'Тенде', 100, 1422682696, 1423978696);
INSERT INTO `db_stats_btree` VALUES (901, 183, 'w2mwwm', 'Тенде', 100, 1422680251, 1423976251);
INSERT INTO `db_stats_btree` VALUES (900, 194, 'kukanik', 'Тенде', 100, 1422677532, 1423973532);
INSERT INTO `db_stats_btree` VALUES (899, 85, 'rj3111', 'Тенде', 100, 1422662299, 1423958299);
INSERT INTO `db_stats_btree` VALUES (898, 155, 'Kastaneda', 'Тенде', 100, 1422649902, 1423945902);
INSERT INTO `db_stats_btree` VALUES (897, 228, 'Mixaluch', 'Тенде', 100, 1422646253, 1423942253);
INSERT INTO `db_stats_btree` VALUES (896, 201, 'stupak62', 'Тенде', 100, 1422644943, 1423940943);
INSERT INTO `db_stats_btree` VALUES (895, 201, 'stupak62', 'Тенде', 100, 1422644940, 1423940940);
INSERT INTO `db_stats_btree` VALUES (894, 201, 'stupak62', 'Бриг', 5000, 1422644927, 1423940927);
INSERT INTO `db_stats_btree` VALUES (893, 201, 'stupak62', 'Бриг', 5000, 1422644925, 1423940925);
INSERT INTO `db_stats_btree` VALUES (892, 201, 'stupak62', 'Бриг', 5000, 1422644846, 1423940846);
INSERT INTO `db_stats_btree` VALUES (891, 201, 'stupak62', 'Бриг', 5000, 1422644844, 1423940844);
INSERT INTO `db_stats_btree` VALUES (890, 201, 'stupak62', 'Бриг', 5000, 1422644842, 1423940842);
INSERT INTO `db_stats_btree` VALUES (889, 201, 'stupak62', 'Бриг', 5000, 1422644841, 1423940841);
INSERT INTO `db_stats_btree` VALUES (888, 201, 'stupak62', 'Бриг', 5000, 1422644839, 1423940839);
INSERT INTO `db_stats_btree` VALUES (887, 201, 'stupak62', 'Бриг', 5000, 1422644837, 1423940837);
INSERT INTO `db_stats_btree` VALUES (886, 201, 'stupak62', 'Бриг', 5000, 1422644835, 1423940835);
INSERT INTO `db_stats_btree` VALUES (885, 201, 'stupak62', 'Шхуна', 1000, 1422644817, 1423940817);
INSERT INTO `db_stats_btree` VALUES (884, 201, 'stupak62', 'Шхуна', 1000, 1422644815, 1423940815);
INSERT INTO `db_stats_btree` VALUES (883, 201, 'stupak62', 'Шхуна', 1000, 1422644814, 1423940814);
INSERT INTO `db_stats_btree` VALUES (882, 201, 'stupak62', 'Шхуна', 1000, 1422644811, 1423940811);
INSERT INTO `db_stats_btree` VALUES (881, 201, 'stupak62', 'Шхуна', 1000, 1422644808, 1423940808);
INSERT INTO `db_stats_btree` VALUES (880, 237, 'volume', 'Тенде', 100, 1422639713, 1423935713);
INSERT INTO `db_stats_btree` VALUES (879, 166, 'shpionka', 'Тенде', 100, 1422639708, 1423935708);
INSERT INTO `db_stats_btree` VALUES (878, 166, 'shpionka', 'Тенде', 100, 1422639704, 1423935704);
INSERT INTO `db_stats_btree` VALUES (877, 166, 'shpionka', 'Тенде', 100, 1422639701, 1423935701);
INSERT INTO `db_stats_btree` VALUES (876, 243, 'toys', 'Шхуна', 1000, 1422639214, 1423935214);
INSERT INTO `db_stats_btree` VALUES (875, 166, 'shpionka', 'Тенде', 100, 1422633085, 1423929085);
INSERT INTO `db_stats_btree` VALUES (874, 166, 'shpionka', 'Тенде', 100, 1422633081, 1423929081);
INSERT INTO `db_stats_btree` VALUES (873, 237, 'volume', 'Тенде', 100, 1422625795, 1423921795);
INSERT INTO `db_stats_btree` VALUES (872, 166, 'shpionka', 'Тенде', 100, 1422624960, 1423920960);
INSERT INTO `db_stats_btree` VALUES (871, 221, 'bhbirf906', 'Тенде', 100, 1422624897, 1423920897);
INSERT INTO `db_stats_btree` VALUES (870, 166, 'shpionka', 'Тенде', 100, 1422623824, 1423919824);
INSERT INTO `db_stats_btree` VALUES (869, 166, 'shpionka', 'Тенде', 100, 1422620551, 1423916551);
INSERT INTO `db_stats_btree` VALUES (868, 237, 'volume', 'Тенде', 100, 1422619077, 1423915077);
INSERT INTO `db_stats_btree` VALUES (867, 85, 'rj3111', 'Шхуна', 1000, 1422619063, 1423915063);
INSERT INTO `db_stats_btree` VALUES (866, 166, 'shpionka', 'Тенде', 100, 1422616138, 1423912138);
INSERT INTO `db_stats_btree` VALUES (865, 166, 'shpionka', 'Тенде', 100, 1422615088, 1423911088);
INSERT INTO `db_stats_btree` VALUES (864, 166, 'shpionka', 'Тенде', 100, 1422615087, 1423911087);
INSERT INTO `db_stats_btree` VALUES (863, 166, 'shpionka', 'Тенде', 100, 1422615085, 1423911085);
INSERT INTO `db_stats_btree` VALUES (862, 166, 'shpionka', 'Тенде', 100, 1422615084, 1423911084);
INSERT INTO `db_stats_btree` VALUES (861, 166, 'shpionka', 'Тенде', 100, 1422615082, 1423911082);
INSERT INTO `db_stats_btree` VALUES (860, 183, 'w2mwwm', 'Тенде', 100, 1422614629, 1423910629);
INSERT INTO `db_stats_btree` VALUES (859, 166, 'shpionka', 'Тенде', 100, 1422613240, 1423909240);
INSERT INTO `db_stats_btree` VALUES (858, 243, 'toys', 'Корве', 25000, 1422610620, 1423906620);
INSERT INTO `db_stats_btree` VALUES (857, 243, 'toys', 'Бриг', 5000, 1422610440, 1423906440);
INSERT INTO `db_stats_btree` VALUES (856, 243, 'toys', 'Бриг', 5000, 1422610435, 1423906435);
INSERT INTO `db_stats_btree` VALUES (855, 243, 'toys', 'Бриг', 5000, 1422610433, 1423906433);
INSERT INTO `db_stats_btree` VALUES (854, 243, 'toys', 'Бриг', 5000, 1422610426, 1423906426);
INSERT INTO `db_stats_btree` VALUES (853, 243, 'toys', 'Бриг', 5000, 1422610424, 1423906424);
INSERT INTO `db_stats_btree` VALUES (852, 243, 'toys', 'Бриг', 5000, 1422610419, 1423906419);
INSERT INTO `db_stats_btree` VALUES (851, 243, 'toys', 'Бриг', 5000, 1422610402, 1423906402);
INSERT INTO `db_stats_btree` VALUES (850, 243, 'toys', 'Шхуна', 1000, 1422610383, 1423906383);
INSERT INTO `db_stats_btree` VALUES (849, 243, 'toys', 'Шхуна', 1000, 1422610379, 1423906379);
INSERT INTO `db_stats_btree` VALUES (848, 243, 'toys', 'Шхуна', 1000, 1422610376, 1423906376);
INSERT INTO `db_stats_btree` VALUES (847, 243, 'toys', 'Шхуна', 1000, 1422610371, 1423906371);
INSERT INTO `db_stats_btree` VALUES (846, 166, 'shpionka', 'Тенде', 100, 1422610062, 1423906062);
INSERT INTO `db_stats_btree` VALUES (845, 237, 'volume', 'Тенде', 100, 1422609394, 1423905394);
INSERT INTO `db_stats_btree` VALUES (844, 166, 'shpionka', 'Тенде', 100, 1422607838, 1423903838);
INSERT INTO `db_stats_btree` VALUES (843, 166, 'shpionka', 'Тенде', 100, 1422606672, 1423902672);
INSERT INTO `db_stats_btree` VALUES (842, 166, 'shpionka', 'Тенде', 100, 1422606671, 1423902671);
INSERT INTO `db_stats_btree` VALUES (841, 166, 'shpionka', 'Тенде', 100, 1422606669, 1423902669);
INSERT INTO `db_stats_btree` VALUES (840, 166, 'shpionka', 'Тенде', 100, 1422606668, 1423902668);
INSERT INTO `db_stats_btree` VALUES (839, 166, 'shpionka', 'Тенде', 100, 1422606667, 1423902667);
INSERT INTO `db_stats_btree` VALUES (838, 166, 'shpionka', 'Тенде', 100, 1422606665, 1423902665);
INSERT INTO `db_stats_btree` VALUES (837, 166, 'shpionka', 'Тенде', 100, 1422606664, 1423902664);
INSERT INTO `db_stats_btree` VALUES (836, 166, 'shpionka', 'Тенде', 100, 1422606663, 1423902663);
INSERT INTO `db_stats_btree` VALUES (835, 166, 'shpionka', 'Тенде', 100, 1422606662, 1423902662);
INSERT INTO `db_stats_btree` VALUES (834, 166, 'shpionka', 'Шхуна', 1000, 1422606659, 1423902659);
INSERT INTO `db_stats_btree` VALUES (833, 166, 'shpionka', 'Шхуна', 1000, 1422606658, 1423902658);
INSERT INTO `db_stats_btree` VALUES (832, 166, 'shpionka', 'Шхуна', 1000, 1422606656, 1423902656);
INSERT INTO `db_stats_btree` VALUES (831, 166, 'shpionka', 'Тенде', 100, 1422606654, 1423902654);
INSERT INTO `db_stats_btree` VALUES (1221, 166, 'shpionka', 'Тенде', 100, 1423288908, 1424584908);
INSERT INTO `db_stats_btree` VALUES (1222, 166, 'shpionka', 'Тенде', 100, 1423288911, 1424584911);
INSERT INTO `db_stats_btree` VALUES (1223, 166, 'shpionka', 'Тенде', 100, 1423288913, 1424584913);
INSERT INTO `db_stats_btree` VALUES (1224, 166, 'shpionka', 'Тенде', 100, 1423288915, 1424584915);
INSERT INTO `db_stats_btree` VALUES (1225, 105, 'mimi877', 'Тенде', 100, 1423292388, 1424588388);
INSERT INTO `db_stats_btree` VALUES (1226, 183, 'w2mwwm', 'Тенде', 100, 1423294831, 1424590831);
INSERT INTO `db_stats_btree` VALUES (1227, 221, 'bhbirf906', 'Тенде', 100, 1423296292, 1424592292);
INSERT INTO `db_stats_btree` VALUES (1228, 85, 'rj3111', 'Тенде', 100, 1423296958, 1424592958);
INSERT INTO `db_stats_btree` VALUES (1229, 252, 'a100500q', 'Шхуна', 1000, 1423299783, 1424595783);
INSERT INTO `db_stats_btree` VALUES (1230, 252, 'a100500q', 'Тенде', 100, 1423299787, 1424595787);
INSERT INTO `db_stats_btree` VALUES (1231, 252, 'a100500q', 'Тенде', 100, 1423299789, 1424595789);
INSERT INTO `db_stats_btree` VALUES (1232, 252, 'a100500q', 'Тенде', 100, 1423299791, 1424595791);
INSERT INTO `db_stats_btree` VALUES (1233, 252, 'a100500q', 'Тенде', 100, 1423299793, 1424595793);
INSERT INTO `db_stats_btree` VALUES (1234, 221, 'bhbirf906', 'Тенде', 100, 1423315021, 1424611021);
INSERT INTO `db_stats_btree` VALUES (1235, 72, 'sarita', 'Тенде', 100, 1423319451, 1424615451);
INSERT INTO `db_stats_btree` VALUES (1236, 201, 'stupak62', 'Бриг', 5000, 1423326127, 1424622127);
INSERT INTO `db_stats_btree` VALUES (1237, 201, 'stupak62', 'Шхуна', 1000, 1423326133, 1424622133);
INSERT INTO `db_stats_btree` VALUES (1238, 201, 'stupak62', 'Шхуна', 1000, 1423326135, 1424622135);
INSERT INTO `db_stats_btree` VALUES (1239, 201, 'stupak62', 'Шхуна', 1000, 1423326137, 1424622137);
INSERT INTO `db_stats_btree` VALUES (1240, 201, 'stupak62', 'Тенде', 100, 1423326143, 1424622143);
INSERT INTO `db_stats_btree` VALUES (1241, 201, 'stupak62', 'Тенде', 100, 1423326144, 1424622144);
INSERT INTO `db_stats_btree` VALUES (1242, 201, 'stupak62', 'Тенде', 100, 1423326146, 1424622146);
INSERT INTO `db_stats_btree` VALUES (1243, 183, 'w2mwwm', 'Тенде', 100, 1423328809, 1424624809);
INSERT INTO `db_stats_btree` VALUES (1244, 270, 'cariden', 'Тенде', 100, 1423332434, 1424628434);
INSERT INTO `db_stats_btree` VALUES (1245, 270, 'cariden', 'Тенде', 100, 1423332436, 1424628436);
INSERT INTO `db_stats_btree` VALUES (1246, 221, 'bhbirf906', 'Тенде', 100, 1423335137, 1424631137);
INSERT INTO `db_stats_btree` VALUES (1247, 237, 'volume', 'Тенде', 100, 1423338852, 1424634852);
INSERT INTO `db_stats_btree` VALUES (1248, 237, 'volume', 'Тенде', 100, 1423338853, 1424634853);
INSERT INTO `db_stats_btree` VALUES (1249, 237, 'volume', 'Тенде', 100, 1423338853, 1424634853);
INSERT INTO `db_stats_btree` VALUES (1250, 237, 'volume', 'Тенде', 100, 1423338854, 1424634854);
INSERT INTO `db_stats_btree` VALUES (1251, 237, 'volume', 'Тенде', 100, 1423338854, 1424634854);
INSERT INTO `db_stats_btree` VALUES (1252, 237, 'volume', 'Тенде', 100, 1423338862, 1424634862);
INSERT INTO `db_stats_btree` VALUES (1253, 237, 'volume', 'Тенде', 100, 1423338863, 1424634863);
INSERT INTO `db_stats_btree` VALUES (1254, 237, 'volume', 'Тенде', 100, 1423338864, 1424634864);
INSERT INTO `db_stats_btree` VALUES (1255, 237, 'volume', 'Тенде', 100, 1423338864, 1424634864);
INSERT INTO `db_stats_btree` VALUES (1256, 260, 'tornadosta', 'Тенде', 100, 1423339028, 1424635028);
INSERT INTO `db_stats_btree` VALUES (1257, 221, 'bhbirf906', 'Тенде', 100, 1423341308, 1424637308);
INSERT INTO `db_stats_btree` VALUES (1258, 155, 'Kastaneda', 'Тенде', 100, 1423348209, 1424644209);
INSERT INTO `db_stats_btree` VALUES (1259, 243, 'toys', 'Тенде', 100, 1423376578, 1424672578);
INSERT INTO `db_stats_btree` VALUES (1260, 243, 'toys', 'Тенде', 100, 1423376581, 1424672581);
INSERT INTO `db_stats_btree` VALUES (1261, 243, 'toys', 'Тенде', 100, 1423376584, 1424672584);
INSERT INTO `db_stats_btree` VALUES (1262, 243, 'toys', 'Тенде', 100, 1423376586, 1424672586);
INSERT INTO `db_stats_btree` VALUES (1263, 243, 'toys', 'Тенде', 100, 1423376589, 1424672589);
INSERT INTO `db_stats_btree` VALUES (1264, 194, 'kukanik', 'Тенде', 100, 1423377181, 1424673181);
INSERT INTO `db_stats_btree` VALUES (1265, 135, 'denplast', 'Тенде', 100, 1423377803, 1424673803);
INSERT INTO `db_stats_btree` VALUES (1266, 183, 'w2mwwm', 'Тенде', 100, 1423378287, 1424674287);
INSERT INTO `db_stats_btree` VALUES (1267, 183, 'w2mwwm', 'Тенде', 100, 1423378289, 1424674289);
INSERT INTO `db_stats_btree` VALUES (1268, 244, 'amince', 'Тенде', 100, 1423382543, 1424678543);
INSERT INTO `db_stats_btree` VALUES (1269, 166, 'shpionka', 'Бриг', 5000, 1423384731, 1424680731);
INSERT INTO `db_stats_btree` VALUES (1270, 166, 'shpionka', 'Тенде', 100, 1423384735, 1424680735);
INSERT INTO `db_stats_btree` VALUES (1271, 166, 'shpionka', 'Тенде', 100, 1423384738, 1424680738);
INSERT INTO `db_stats_btree` VALUES (1272, 166, 'shpionka', 'Тенде', 100, 1423384740, 1424680740);
INSERT INTO `db_stats_btree` VALUES (1273, 166, 'shpionka', 'Тенде', 100, 1423384743, 1424680743);
INSERT INTO `db_stats_btree` VALUES (1274, 85, 'rj3111', 'Тенде', 100, 1423388301, 1424684301);
INSERT INTO `db_stats_btree` VALUES (1275, 270, 'cariden', 'Тенде', 100, 1423389790, 1424685790);
INSERT INTO `db_stats_btree` VALUES (1276, 284, 'izadora', 'Тенде', 100, 1423389928, 1424685928);
INSERT INTO `db_stats_btree` VALUES (1277, 219, 'ZET1', 'Тенде', 100, 1423392286, 1424688286);
INSERT INTO `db_stats_btree` VALUES (1278, 183, 'w2mwwm', 'Тенде', 100, 1423394695, 1424690695);
INSERT INTO `db_stats_btree` VALUES (1279, 231, 'palpalyh', 'Тенде', 100, 1423395413, 1424691413);
INSERT INTO `db_stats_btree` VALUES (1280, 216, 'GetLens', 'Тенде', 100, 1423409862, 1424705862);
INSERT INTO `db_stats_btree` VALUES (1281, 216, 'GetLens', 'Тенде', 100, 1423409864, 1424705864);
INSERT INTO `db_stats_btree` VALUES (1282, 221, 'bhbirf906', 'Тенде', 100, 1423426642, 1424722642);
INSERT INTO `db_stats_btree` VALUES (1283, 221, 'bhbirf906', 'Тенде', 100, 1423426646, 1424722646);
INSERT INTO `db_stats_btree` VALUES (1284, 221, 'bhbirf906', 'Тенде', 100, 1423426651, 1424722651);
INSERT INTO `db_stats_btree` VALUES (1285, 221, 'bhbirf906', 'Тенде', 100, 1423426654, 1424722654);
INSERT INTO `db_stats_btree` VALUES (1286, 283, 'ganne', 'Тенде', 100, 1423446579, 1424742579);
INSERT INTO `db_stats_btree` VALUES (1287, 95, 'bananan', 'Тенде', 100, 1423450239, 1424746239);
INSERT INTO `db_stats_btree` VALUES (1288, 228, 'Mixaluch', 'Тенде', 100, 1423454538, 1424750538);
INSERT INTO `db_stats_btree` VALUES (1289, 281, 'Bakeshi', 'Тенде', 100, 1423462580, 1424758580);
INSERT INTO `db_stats_btree` VALUES (1290, 183, 'w2mwwm', 'Тенде', 100, 1423464322, 1424760322);
INSERT INTO `db_stats_btree` VALUES (1291, 166, 'shpionka', 'Шхуна', 1000, 1423469963, 1424765963);
INSERT INTO `db_stats_btree` VALUES (1292, 166, 'shpionka', 'Шхуна', 1000, 1423469964, 1424765964);
INSERT INTO `db_stats_btree` VALUES (1293, 166, 'shpionka', 'Шхуна', 1000, 1423469966, 1424765966);
INSERT INTO `db_stats_btree` VALUES (1294, 166, 'shpionka', 'Тенде', 100, 1423469967, 1424765967);
INSERT INTO `db_stats_btree` VALUES (1295, 166, 'shpionka', 'Тенде', 100, 1423469968, 1424765968);
INSERT INTO `db_stats_btree` VALUES (1296, 194, 'kukanik', 'Тенде', 100, 1423471237, 1424767237);
INSERT INTO `db_stats_btree` VALUES (1297, 253, 'Vagan', 'Тенде', 100, 1423471302, 1424767302);
INSERT INTO `db_stats_btree` VALUES (1298, 166, 'shpionka', 'Шхуна', 1000, 1423473487, 1424769487);
INSERT INTO `db_stats_btree` VALUES (1299, 166, 'shpionka', 'Тенде', 100, 1423473489, 1424769489);
INSERT INTO `db_stats_btree` VALUES (1300, 166, 'shpionka', 'Тенде', 100, 1423473490, 1424769490);
INSERT INTO `db_stats_btree` VALUES (1301, 166, 'shpionka', 'Тенде', 100, 1423473491, 1424769491);
INSERT INTO `db_stats_btree` VALUES (1302, 166, 'shpionka', 'Тенде', 100, 1423473492, 1424769492);
INSERT INTO `db_stats_btree` VALUES (1303, 166, 'shpionka', 'Тенде', 100, 1423473494, 1424769494);
INSERT INTO `db_stats_btree` VALUES (1304, 166, 'shpionka', 'Тенде', 100, 1423473495, 1424769495);
INSERT INTO `db_stats_btree` VALUES (1305, 166, 'shpionka', 'Тенде', 100, 1423473497, 1424769497);
INSERT INTO `db_stats_btree` VALUES (1306, 260, 'tornadosta', 'Тенде', 100, 1423474253, 1424770253);
INSERT INTO `db_stats_btree` VALUES (1307, 221, 'bhbirf906', 'Тенде', 100, 1423474813, 1424770813);
INSERT INTO `db_stats_btree` VALUES (1308, 85, 'rj3111', 'Тенде', 100, 1423480911, 1424776911);
INSERT INTO `db_stats_btree` VALUES (1309, 243, 'toys', 'Шхуна', 1000, 1423487714, 1424783714);
INSERT INTO `db_stats_btree` VALUES (1310, 243, 'toys', 'Шхуна', 1000, 1423487716, 1424783716);
INSERT INTO `db_stats_btree` VALUES (1311, 243, 'toys', 'Тенде', 100, 1423487761, 1424783761);
INSERT INTO `db_stats_btree` VALUES (1312, 243, 'toys', 'Тенде', 100, 1423487764, 1424783764);
INSERT INTO `db_stats_btree` VALUES (1313, 243, 'toys', 'Тенде', 100, 1423487766, 1424783766);
INSERT INTO `db_stats_btree` VALUES (1314, 243, 'toys', 'Тенде', 100, 1423487769, 1424783769);
INSERT INTO `db_stats_btree` VALUES (1315, 166, 'shpionka', 'Тенде', 100, 1423491991, 1424787991);
INSERT INTO `db_stats_btree` VALUES (1316, 166, 'shpionka', 'Тенде', 100, 1423491992, 1424787992);
INSERT INTO `db_stats_btree` VALUES (1317, 166, 'shpionka', 'Тенде', 100, 1423491994, 1424787994);
INSERT INTO `db_stats_btree` VALUES (1318, 166, 'shpionka', 'Тенде', 100, 1423491995, 1424787995);
INSERT INTO `db_stats_btree` VALUES (1319, 166, 'shpionka', 'Тенде', 100, 1423491996, 1424787996);
INSERT INTO `db_stats_btree` VALUES (1320, 166, 'shpionka', 'Тенде', 100, 1423491997, 1424787997);
INSERT INTO `db_stats_btree` VALUES (1321, 166, 'shpionka', 'Тенде', 100, 1423491999, 1424787999);
INSERT INTO `db_stats_btree` VALUES (1322, 237, 'volume', 'Тенде', 100, 1423493286, 1424789286);
INSERT INTO `db_stats_btree` VALUES (1323, 237, 'volume', 'Тенде', 100, 1423493287, 1424789287);
INSERT INTO `db_stats_btree` VALUES (1324, 237, 'volume', 'Тенде', 100, 1423493287, 1424789287);
INSERT INTO `db_stats_btree` VALUES (1325, 237, 'volume', 'Тенде', 100, 1423493288, 1424789288);
INSERT INTO `db_stats_btree` VALUES (1326, 237, 'volume', 'Тенде', 100, 1423493288, 1424789288);
INSERT INTO `db_stats_btree` VALUES (1327, 237, 'volume', 'Тенде', 100, 1423493289, 1424789289);
INSERT INTO `db_stats_btree` VALUES (1328, 237, 'volume', 'Тенде', 100, 1423493298, 1424789298);
INSERT INTO `db_stats_btree` VALUES (1329, 237, 'volume', 'Тенде', 100, 1423493299, 1424789299);
INSERT INTO `db_stats_btree` VALUES (1330, 185, 'vitaminka', 'Тенде', 100, 1423498463, 1424794463);
INSERT INTO `db_stats_btree` VALUES (1331, 221, 'bhbirf906', 'Тенде', 100, 1423498541, 1424794541);
INSERT INTO `db_stats_btree` VALUES (1332, 155, 'Kastaneda', 'Тенде', 100, 1423500784, 1424796784);
INSERT INTO `db_stats_btree` VALUES (1333, 237, 'volume', 'Тенде', 100, 1423503746, 1424799746);
INSERT INTO `db_stats_btree` VALUES (1334, 281, 'Bakeshi', 'Тенде', 100, 1423504488, 1424800488);
INSERT INTO `db_stats_btree` VALUES (1335, 63, 'Best', 'Тенде', 100, 1423510391, 1424806391);
INSERT INTO `db_stats_btree` VALUES (1336, 221, 'bhbirf906', 'Тенде', 100, 1423514144, 1424810144);
INSERT INTO `db_stats_btree` VALUES (1337, 213, 'Nogar', 'Тенде', 100, 1423522485, 1424818485);
INSERT INTO `db_stats_btree` VALUES (1338, 219, 'ZET1', 'Тенде', 100, 1423544524, 1424840524);
INSERT INTO `db_stats_btree` VALUES (1339, 183, 'w2mwwm', 'Тенде', 100, 1423547768, 1424843768);
INSERT INTO `db_stats_btree` VALUES (1340, 183, 'w2mwwm', 'Тенде', 100, 1423547770, 1424843770);
INSERT INTO `db_stats_btree` VALUES (1341, 221, 'bhbirf906', 'Тенде', 100, 1423547916, 1424843916);
INSERT INTO `db_stats_btree` VALUES (1342, 166, 'shpionka', 'Шхуна', 1000, 1423549263, 1424845263);
INSERT INTO `db_stats_btree` VALUES (1343, 166, 'shpionka', 'Шхуна', 1000, 1423549264, 1424845264);
INSERT INTO `db_stats_btree` VALUES (1344, 166, 'shpionka', 'Тенде', 100, 1423549266, 1424845266);
INSERT INTO `db_stats_btree` VALUES (1345, 166, 'shpionka', 'Тенде', 100, 1423549268, 1424845268);
INSERT INTO `db_stats_btree` VALUES (1346, 231, 'palpalyh', 'Тенде', 100, 1423560611, 1424856611);
INSERT INTO `db_stats_btree` VALUES (1347, 225, 'imkatla', 'Шхуна', 1000, 1423563372, 1424859372);
INSERT INTO `db_stats_btree` VALUES (1348, 105, 'mimi877', 'Тенде', 100, 1423565327, 1424861327);
INSERT INTO `db_stats_btree` VALUES (1349, 244, 'amince', 'Тенде', 100, 1423566259, 1424862259);
INSERT INTO `db_stats_btree` VALUES (1350, 183, 'w2mwwm', 'Тенде', 100, 1423568270, 1424864270);
INSERT INTO `db_stats_btree` VALUES (1351, 281, 'Bakeshi', 'Тенде', 100, 1423568827, 1424864827);
INSERT INTO `db_stats_btree` VALUES (1352, 221, 'bhbirf906', 'Тенде', 100, 1423568979, 1424864979);
INSERT INTO `db_stats_btree` VALUES (1353, 216, 'GetLens', 'Тенде', 100, 1423571067, 1424867067);
INSERT INTO `db_stats_btree` VALUES (1354, 279, 'Evgeniy888', 'Тенде', 100, 1423572084, 1424868084);
INSERT INTO `db_stats_btree` VALUES (1355, 198, 'sarapul', 'Тенде', 100, 1423575885, 1424871885);
INSERT INTO `db_stats_btree` VALUES (1356, 85, 'rj3111', 'Тенде', 100, 1423576402, 1424872402);
INSERT INTO `db_stats_btree` VALUES (1357, 221, 'bhbirf906', 'Тенде', 100, 1423594550, 1424890550);
INSERT INTO `db_stats_btree` VALUES (1358, 237, 'volume', 'Тенде', 100, 1423595891, 1424891891);
INSERT INTO `db_stats_btree` VALUES (1359, 237, 'volume', 'Тенде', 100, 1423595892, 1424891892);
INSERT INTO `db_stats_btree` VALUES (1360, 237, 'volume', 'Тенде', 100, 1423595893, 1424891893);
INSERT INTO `db_stats_btree` VALUES (1361, 237, 'volume', 'Тенде', 100, 1423595909, 1424891909);
INSERT INTO `db_stats_btree` VALUES (1362, 237, 'volume', 'Тенде', 100, 1423595909, 1424891909);
INSERT INTO `db_stats_btree` VALUES (1363, 237, 'volume', 'Тенде', 100, 1423595910, 1424891910);
INSERT INTO `db_stats_btree` VALUES (1364, 237, 'volume', 'Тенде', 100, 1423595911, 1424891911);
INSERT INTO `db_stats_btree` VALUES (1365, 183, 'w2mwwm', 'Тенде', 100, 1423597078, 1424893078);
INSERT INTO `db_stats_btree` VALUES (1366, 277, 'SUMRAC', 'Тенде', 100, 1423597702, 1424893702);
INSERT INTO `db_stats_btree` VALUES (1367, 260, 'tornadosta', 'Тенде', 100, 1423600344, 1424896344);
INSERT INTO `db_stats_btree` VALUES (1368, 155, 'Kastaneda', 'Тенде', 100, 1423606642, 1424902642);
INSERT INTO `db_stats_btree` VALUES (1369, 243, 'toys', 'Шхуна', 1000, 1423627513, 1424923513);
INSERT INTO `db_stats_btree` VALUES (1370, 243, 'toys', 'Тенде', 100, 1423627516, 1424923516);
INSERT INTO `db_stats_btree` VALUES (1371, 243, 'toys', 'Тенде', 100, 1423627519, 1424923519);
INSERT INTO `db_stats_btree` VALUES (1372, 243, 'toys', 'Тенде', 100, 1423627522, 1424923522);
INSERT INTO `db_stats_btree` VALUES (1373, 243, 'toys', 'Тенде', 100, 1423627524, 1424923524);
INSERT INTO `db_stats_btree` VALUES (1374, 243, 'toys', 'Тенде', 100, 1423627527, 1424923527);
INSERT INTO `db_stats_btree` VALUES (1375, 166, 'shpionka', 'Шхуна', 1000, 1423635542, 1424931542);
INSERT INTO `db_stats_btree` VALUES (1376, 166, 'shpionka', 'Шхуна', 1000, 1423635543, 1424931543);
INSERT INTO `db_stats_btree` VALUES (1377, 166, 'shpionka', 'Шхуна', 1000, 1423635544, 1424931544);
INSERT INTO `db_stats_btree` VALUES (1378, 166, 'shpionka', 'Тенде', 100, 1423635546, 1424931546);
INSERT INTO `db_stats_btree` VALUES (1379, 166, 'shpionka', 'Тенде', 100, 1423635547, 1424931547);
INSERT INTO `db_stats_btree` VALUES (1380, 166, 'shpionka', 'Тенде', 100, 1423635548, 1424931548);
INSERT INTO `db_stats_btree` VALUES (1381, 166, 'shpionka', 'Тенде', 100, 1423635550, 1424931550);
INSERT INTO `db_stats_btree` VALUES (1382, 166, 'shpionka', 'Тенде', 100, 1423635551, 1424931551);
INSERT INTO `db_stats_btree` VALUES (1383, 166, 'shpionka', 'Тенде', 100, 1423635552, 1424931552);
INSERT INTO `db_stats_btree` VALUES (1384, 221, 'bhbirf906', 'Тенде', 100, 1423640720, 1424936720);
INSERT INTO `db_stats_btree` VALUES (1385, 194, 'kukanik', 'Тенде', 100, 1423642382, 1424938382);
INSERT INTO `db_stats_btree` VALUES (1386, 135, 'denplast', 'Тенде', 100, 1423642572, 1424938572);
INSERT INTO `db_stats_btree` VALUES (1387, 209, 'fktrc906', 'Тенде', 100, 1423644754, 1424940754);
INSERT INTO `db_stats_btree` VALUES (1388, 281, 'Bakeshi', 'Тенде', 100, 1423645493, 1424941493);
INSERT INTO `db_stats_btree` VALUES (1389, 237, 'volume', 'Тенде', 100, 1423648053, 1424944053);
INSERT INTO `db_stats_btree` VALUES (1390, 237, 'volume', 'Тенде', 100, 1423648054, 1424944054);
INSERT INTO `db_stats_btree` VALUES (1391, 183, 'w2mwwm', 'Тенде', 100, 1423650461, 1424946461);
INSERT INTO `db_stats_btree` VALUES (1392, 253, 'Vagan', 'Тенде', 100, 1423654791, 1424950791);
INSERT INTO `db_stats_btree` VALUES (1393, 85, 'rj3111', 'Тенде', 100, 1423665394, 1424961394);
INSERT INTO `db_stats_btree` VALUES (1394, 228, 'Mixaluch', 'Тенде', 100, 1423672515, 1424968515);
INSERT INTO `db_stats_btree` VALUES (1395, 183, 'w2mwwm', 'Тенде', 100, 1423672961, 1424968961);
INSERT INTO `db_stats_btree` VALUES (1396, 221, 'bhbirf906', 'Тенде', 100, 1423676626, 1424972626);
INSERT INTO `db_stats_btree` VALUES (1397, 277, 'SUMRAC', 'Тенде', 100, 1423685248, 1424981248);
INSERT INTO `db_stats_btree` VALUES (1398, 237, 'volume', 'Тенде', 100, 1423685603, 1424981603);
INSERT INTO `db_stats_btree` VALUES (1399, 237, 'volume', 'Тенде', 100, 1423685604, 1424981604);
INSERT INTO `db_stats_btree` VALUES (1400, 237, 'volume', 'Тенде', 100, 1423685617, 1424981617);
INSERT INTO `db_stats_btree` VALUES (1401, 237, 'volume', 'Тенде', 100, 1423685617, 1424981617);
INSERT INTO `db_stats_btree` VALUES (1402, 221, 'bhbirf906', 'Тенде', 100, 1423687253, 1424983253);
INSERT INTO `db_stats_btree` VALUES (1403, 213, 'Nogar', 'Тенде', 100, 1423699440, 1424995440);
INSERT INTO `db_stats_btree` VALUES (1404, 166, 'shpionka', 'Шхуна', 1000, 1423720648, 1425016648);
INSERT INTO `db_stats_btree` VALUES (1405, 166, 'shpionka', 'Шхуна', 1000, 1423720649, 1425016649);
INSERT INTO `db_stats_btree` VALUES (1406, 166, 'shpionka', 'Шхуна', 1000, 1423720651, 1425016651);
INSERT INTO `db_stats_btree` VALUES (1407, 166, 'shpionka', 'Тенде', 100, 1423720652, 1425016652);
INSERT INTO `db_stats_btree` VALUES (1408, 166, 'shpionka', 'Тенде', 100, 1423720654, 1425016654);
INSERT INTO `db_stats_btree` VALUES (1409, 166, 'shpionka', 'Тенде', 100, 1423728158, 1425024158);
INSERT INTO `db_stats_btree` VALUES (1410, 166, 'shpionka', 'Тенде', 100, 1423728159, 1425024159);
INSERT INTO `db_stats_btree` VALUES (1411, 166, 'shpionka', 'Тенде', 100, 1423728161, 1425024161);
INSERT INTO `db_stats_btree` VALUES (1412, 166, 'shpionka', 'Тенде', 100, 1423728181, 1425024181);
INSERT INTO `db_stats_btree` VALUES (1413, 166, 'shpionka', 'Тенде', 100, 1423728182, 1425024182);
INSERT INTO `db_stats_btree` VALUES (1414, 221, 'bhbirf906', 'Тенде', 100, 1423729432, 1425025432);
INSERT INTO `db_stats_btree` VALUES (1415, 231, 'palpalyh', 'Тенде', 100, 1423736052, 1425032052);
INSERT INTO `db_stats_btree` VALUES (1416, 260, 'tornadosta', 'Тенде', 100, 1423737472, 1425033472);
INSERT INTO `db_stats_btree` VALUES (1417, 275, 'stupak2691', 'Тенде', 100, 1423737855, 1425033855);
INSERT INTO `db_stats_btree` VALUES (1418, 280, 'tverdun927', 'Тенде', 100, 1423739771, 1425035771);
INSERT INTO `db_stats_btree` VALUES (1419, 280, 'tverdun927', 'Тенде', 100, 1423739774, 1425035774);
INSERT INTO `db_stats_btree` VALUES (1420, 280, 'tverdun927', 'Тенде', 100, 1423739779, 1425035779);
INSERT INTO `db_stats_btree` VALUES (1421, 183, 'w2mwwm', 'Тенде', 100, 1423742126, 1425038126);
INSERT INTO `db_stats_btree` VALUES (1422, 192, 'valter', 'Тенде', 100, 1423745709, 1425041709);
INSERT INTO `db_stats_btree` VALUES (1423, 237, 'volume', 'Тенде', 100, 1423749191, 1425045191);
INSERT INTO `db_stats_btree` VALUES (1424, 237, 'volume', 'Тенде', 100, 1423749192, 1425045192);
INSERT INTO `db_stats_btree` VALUES (1425, 237, 'volume', 'Тенде', 100, 1423749193, 1425045193);
INSERT INTO `db_stats_btree` VALUES (1426, 166, 'shpionka', 'Тенде', 100, 1423751122, 1425047122);
INSERT INTO `db_stats_btree` VALUES (1427, 166, 'shpionka', 'Тенде', 100, 1423751123, 1425047123);
INSERT INTO `db_stats_btree` VALUES (1428, 166, 'shpionka', 'Тенде', 100, 1423751125, 1425047125);
INSERT INTO `db_stats_btree` VALUES (1429, 166, 'shpionka', 'Тенде', 100, 1423751126, 1425047126);
INSERT INTO `db_stats_btree` VALUES (1430, 166, 'shpionka', 'Тенде', 100, 1423751127, 1425047127);
INSERT INTO `db_stats_btree` VALUES (1431, 166, 'shpionka', 'Тенде', 100, 1423751129, 1425047129);
INSERT INTO `db_stats_btree` VALUES (1432, 166, 'shpionka', 'Тенде', 100, 1423751130, 1425047130);
INSERT INTO `db_stats_btree` VALUES (1433, 166, 'shpionka', 'Тенде', 100, 1423751131, 1425047131);
INSERT INTO `db_stats_btree` VALUES (1434, 166, 'shpionka', 'Тенде', 100, 1423751132, 1425047132);
INSERT INTO `db_stats_btree` VALUES (1435, 221, 'bhbirf906', 'Тенде', 100, 1423754195, 1425050195);
INSERT INTO `db_stats_btree` VALUES (1436, 194, 'kukanik', 'Тенде', 100, 1423757387, 1425053387);
INSERT INTO `db_stats_btree` VALUES (1437, 250, 'andron1144', 'Тенде', 100, 1423759688, 1425055688);
INSERT INTO `db_stats_btree` VALUES (1438, 216, 'GetLens', 'Тенде', 100, 1423761343, 1425057343);
INSERT INTO `db_stats_btree` VALUES (1439, 277, 'SUMRAC', 'Тенде', 100, 1423771876, 1425067876);
INSERT INTO `db_stats_btree` VALUES (1440, 85, 'rj3111', 'Тенде', 100, 1423773740, 1425069740);
INSERT INTO `db_stats_btree` VALUES (1441, 155, 'Kastaneda', 'Тенде', 100, 1423780524, 1425076524);
INSERT INTO `db_stats_btree` VALUES (1442, 96, 'tanda13', 'Тенде', 100, 1423784432, 1425080432);
INSERT INTO `db_stats_btree` VALUES (1443, 243, 'toys', 'Шхуна', 1000, 1423798550, 1425094550);
INSERT INTO `db_stats_btree` VALUES (1444, 201, 'stupak62', 'Шхуна', 1000, 1423799103, 1425095103);
INSERT INTO `db_stats_btree` VALUES (1445, 201, 'stupak62', 'Шхуна', 1000, 1423799110, 1425095110);
INSERT INTO `db_stats_btree` VALUES (1446, 201, 'stupak62', 'Тенде', 100, 1423799121, 1425095121);
INSERT INTO `db_stats_btree` VALUES (1447, 201, 'stupak62', 'Тенде', 100, 1423799123, 1425095123);
INSERT INTO `db_stats_btree` VALUES (1448, 201, 'stupak62', 'Тенде', 100, 1423799124, 1425095124);
INSERT INTO `db_stats_btree` VALUES (1449, 201, 'stupak62', 'Тенде', 100, 1423799126, 1425095126);
INSERT INTO `db_stats_btree` VALUES (1450, 201, 'stupak62', 'Тенде', 100, 1423799127, 1425095127);
INSERT INTO `db_stats_btree` VALUES (1451, 201, 'stupak62', 'Тенде', 100, 1423799129, 1425095129);
INSERT INTO `db_stats_btree` VALUES (1452, 221, 'bhbirf906', 'Тенде', 100, 1423803932, 1425099932);
INSERT INTO `db_stats_btree` VALUES (1453, 183, 'w2mwwm', 'Тенде', 100, 1423804397, 1425100397);
INSERT INTO `db_stats_btree` VALUES (1454, 166, 'shpionka', 'Шхуна', 1000, 1423808640, 1425104640);
INSERT INTO `db_stats_btree` VALUES (1455, 166, 'shpionka', 'Шхуна', 1000, 1423808642, 1425104642);
INSERT INTO `db_stats_btree` VALUES (1456, 166, 'shpionka', 'Тенде', 100, 1423808643, 1425104643);
INSERT INTO `db_stats_btree` VALUES (1457, 166, 'shpionka', 'Тенде', 100, 1423808644, 1425104644);
INSERT INTO `db_stats_btree` VALUES (1458, 281, 'Bakeshi', 'Тенде', 100, 1423813878, 1425109878);
INSERT INTO `db_stats_btree` VALUES (1459, 135, 'denplast', 'Тенде', 100, 1423814774, 1425110774);
INSERT INTO `db_stats_btree` VALUES (1460, 244, 'amince', 'Тенде', 100, 1423816660, 1425112660);
INSERT INTO `db_stats_btree` VALUES (1461, 221, 'bhbirf906', 'Тенде', 100, 1423822770, 1425118770);
INSERT INTO `db_stats_btree` VALUES (1462, 183, 'w2mwwm', 'Тенде', 100, 1423823208, 1425119208);
INSERT INTO `db_stats_btree` VALUES (1463, 166, 'shpionka', 'Шхуна', 1000, 1423824577, 1425120577);
INSERT INTO `db_stats_btree` VALUES (1464, 166, 'shpionka', 'Тенде', 100, 1423824578, 1425120578);
INSERT INTO `db_stats_btree` VALUES (1465, 166, 'shpionka', 'Тенде', 100, 1423824579, 1425120579);
INSERT INTO `db_stats_btree` VALUES (1466, 166, 'shpionka', 'Тенде', 100, 1423824580, 1425120580);
INSERT INTO `db_stats_btree` VALUES (1467, 166, 'shpionka', 'Тенде', 100, 1423824582, 1425120582);
INSERT INTO `db_stats_btree` VALUES (1468, 166, 'shpionka', 'Тенде', 100, 1423824583, 1425120583);
INSERT INTO `db_stats_btree` VALUES (1469, 166, 'shpionka', 'Тенде', 100, 1423824584, 1425120584);
INSERT INTO `db_stats_btree` VALUES (1470, 237, 'volume', 'Тенде', 100, 1423827898, 1425123898);
INSERT INTO `db_stats_btree` VALUES (1471, 237, 'volume', 'Тенде', 100, 1423827898, 1425123898);
INSERT INTO `db_stats_btree` VALUES (1472, 237, 'volume', 'Тенде', 100, 1423827899, 1425123899);
INSERT INTO `db_stats_btree` VALUES (1473, 237, 'volume', 'Тенде', 100, 1423827899, 1425123899);
INSERT INTO `db_stats_btree` VALUES (1474, 237, 'volume', 'Тенде', 100, 1423827900, 1425123900);
INSERT INTO `db_stats_btree` VALUES (1475, 253, 'Vagan', 'Тенде', 100, 1423839239, 1425135239);
INSERT INTO `db_stats_btree` VALUES (1476, 228, 'Mixaluch', 'Тенде', 100, 1423844612, 1425140612);
INSERT INTO `db_stats_btree` VALUES (1477, 1, 'Admin', 'Тенде', 100, 1464025668, 1465321668);
INSERT INTO `db_stats_btree` VALUES (1478, 1, 'Admin', 'Тенде', 100, 1464025700, 1465321700);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_swap_ser`
-- 

CREATE TABLE `db_swap_ser` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `user` varchar(10) NOT NULL default '',
  `amount_b` double NOT NULL default '0',
  `amount_p` double NOT NULL default '0',
  `date_add` int(11) NOT NULL default '0',
  `date_del` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=7 ;

-- 
-- ���� ������ ������� `db_swap_ser`
-- 

INSERT INTO `db_swap_ser` VALUES (6, 243, 'toys', 1050, 1000, 1423487706, 1424783706);
INSERT INTO `db_swap_ser` VALUES (5, 243, 'toys', 1050, 1000, 1423206386, 1424502386);
INSERT INTO `db_swap_ser` VALUES (4, 243, 'toys', 1050, 1000, 1422950601, 1424246601);

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_users_a`
-- 

CREATE TABLE `db_users_a` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(10) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `pass` varchar(20) NOT NULL default '',
  `referer` varchar(10) NOT NULL default '',
  `referer_id` int(11) NOT NULL default '0',
  `referals` int(11) NOT NULL default '0',
  `date_reg` int(11) NOT NULL default '0',
  `date_login` int(11) NOT NULL default '0',
  `ip` int(10) unsigned NOT NULL default '0',
  `banned` int(1) NOT NULL default '0',
  `hide` varchar(55) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=302 DEFAULT CHARSET=cp1251 AUTO_INCREMENT=302 ;

-- 
-- ���� ������ ������� `db_users_a`
-- 

INSERT INTO `db_users_a` VALUES (1, 'Admin', 'yura.boss@yandex.ua', 'admin4ika', 'Admin', 1, 158, 1367313062, 1464064218, 2956673857, 0, '0');
INSERT INTO `db_users_a` VALUES (23, 'Ludo95', '195musa195@mail.ru', '8879048', 'test', 1, 0, 1420885071, 1421574512, 624291364, 1, '1');
INSERT INTO `db_users_a` VALUES (24, 'kolkoo', 'qwe@mail.ru', 'qweasd', 'test', 1, 0, 1420885593, 1421831831, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (25, 'VladimirVi', 'gbfss@yandex.ru', 'yafljlrmby', 'test', 1, 0, 1420885680, 1422551232, 531938102, 0, '0');
INSERT INTO `db_users_a` VALUES (26, 'frog', 'frog1337@yandex.ru', 'Rfrnec50', 'test', 1, 0, 1420885879, 1420890057, 1600873964, 0, '0');
INSERT INTO `db_users_a` VALUES (27, 'Zippo', 'tolya1999.5@mail.ru', '111111', 'test', 1, 1, 1420886093, 1422548265, 634675494, 0, '0');
INSERT INTO `db_users_a` VALUES (36, 'kostq', 'peovski@mail.ru', '454545', 'pirat', 33, 0, 1420890701, 1420890708, 1597308112, 0, '0');
INSERT INTO `db_users_a` VALUES (35, 'looop', 'votkinck79@mail.ru', '123456789', 'test', 1, 0, 1420890432, 1420905291, 1314211999, 0, '0');
INSERT INTO `db_users_a` VALUES (34, 'VorobeY', 'puiutzul@gmail.com', '946c8lp9ci89', 'Zippo', 27, 12, 1420889513, 1423254086, 1598108626, 0, '0');
INSERT INTO `db_users_a` VALUES (33, 'pirat', 'andreyslesarenko2@gmail.com', 'azamat', 'test', 1, 3, 1420889277, 1422672259, 3104369197, 0, '0');
INSERT INTO `db_users_a` VALUES (32, 'appledox', 'vadim.voitehovich@mail.ru', 'vadim25072000', 'test', 1, 0, 1420888544, 1421000822, 634813561, 0, '0');
INSERT INTO `db_users_a` VALUES (22, 'Sano460', 'sadsfsdgfdgfdgfd@yandex.ru', '000000', 'test', 1, 0, 1420884960, 1422207681, 3648413526, 0, '0');
INSERT INTO `db_users_a` VALUES (31, 'Deniska199', 'd.podkalns@yandex.by', 'Deniska99', 'test', 1, 0, 1420888161, 1420888176, 2956767499, 0, '0');
INSERT INTO `db_users_a` VALUES (30, 'ischeg', 'ischeg@yandex.ru', '201979', 'test', 1, 0, 1420887527, 1421831822, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (29, 'herues2009', 'herues2009@yandex.ru', 'zaqxsw', 'test', 1, 0, 1420886801, 1421831822, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (28, 'DenTODDesT', 'adelard8888@gmail.com', 'dentoddest11', 'test', 1, 0, 1420886231, 1421845807, 1519874340, 0, '0');
INSERT INTO `db_users_a` VALUES (21, 'kolkov', 'stas_gsdkolkov@mail.tu', '15236348457236', 'test', 1, 0, 1420884774, 1422799684, 631102986, 0, '0');
INSERT INTO `db_users_a` VALUES (37, 'admi1998', 'sasha.garifullin.98@mail.ru', 'alopes02', 'test', 1, 0, 1420891415, 1420891425, 1542107661, 0, '0');
INSERT INTO `db_users_a` VALUES (38, 'mixayamaha', 'mr.mixa2014@bk.ru', '22102011', 'test', 1, 0, 1420892438, 1421831827, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (39, 'skroliks', 'skroliks@ukr.net', 'vjycnh1984', 'test', 1, 0, 1420892890, 1421831834, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (40, 'sashatlt8', 'sashatlt8@gmail.com', '02a03a01j2000s', 'test', 1, 0, 1420892966, 1421122868, 1402278876, 0, '0');
INSERT INTO `db_users_a` VALUES (41, 'Siskashvil', 'sasukekun_96@mail.ru', 'zxcvb96', 'test', 1, 0, 1420893074, 1420893084, 787623844, 0, '0');
INSERT INTO `db_users_a` VALUES (42, 'qwerty', 'qwerty@ya.ru', 'qwerty', 'test', 1, 0, 1420893131, 1421831831, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (43, 'matveik22', 'matveik22@gmail.com', 'ww9196384531', 'VorobeY', 34, 0, 1420896512, 1421831826, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (44, 'RockTheStr', 'rockthestreet@yandex.ru', 'dfybkf555', 'VorobeY', 34, 0, 1420897694, 1420897701, 2992548901, 0, '0');
INSERT INTO `db_users_a` VALUES (45, 'Valera01', 'gd_bird01@mail.ru', 'cola123', 'test', 1, 1, 1420898338, 1421770440, 1551009067, 0, '0');
INSERT INTO `db_users_a` VALUES (46, 'Ruty', 'senor-2000t@yandex.ru', 'andrew1608', 'test', 1, 0, 1420900910, 1420900916, 1294838933, 0, '0');
INSERT INTO `db_users_a` VALUES (47, 'heeer', '1@mail.ru', '666666', 'test', 1, 0, 1420901238, 1421250252, 625927860, 0, '0');
INSERT INTO `db_users_a` VALUES (48, 'and23154', 'andrey.andreich.14@mail.ru', '89105384358andrei', 'VorobeY', 34, 0, 1420901492, 1421831816, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (49, 'wingchun', 'lil_prince@box.az', '212303983', 'test', 1, 2, 1420902199, 1422688258, 628267016, 0, '0');
INSERT INTO `db_users_a` VALUES (50, 'Aleksandr1', 'aleksander.smolin2015@yandex.ru', '35d62dg5h4il45ssd2', 'test', 1, 0, 1420903186, 1422794255, 89112264, 0, '0');
INSERT INTO `db_users_a` VALUES (51, 'YRIIK', 'kalugin-y@bk.ru', '123454321', 'Valera01', 45, 0, 1420903572, 1421831823, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (52, 'Sheamus', 'k-burdo@mail.ru', 'sheamus', 'test', 1, 0, 1420903784, 1420903801, 2992460089, 0, '0');
INSERT INTO `db_users_a` VALUES (53, 'Dronuks', 'dronuks999@mail.ru', 'dronuks999', 'VorobeY', 34, 0, 1420904083, 1421831820, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (54, 'ACTORS', 'invest-games@yandex.ru', 'efbrgn13', 'test', 1, 0, 1420904754, 1420904813, 3169540461, 0, '0');
INSERT INTO `db_users_a` VALUES (55, 'Kanadec', 'sobol.exellent6@yandex.by', 'fxfxfxfx', 'test', 1, 5, 1420904861, 1421099461, 2994682973, 0, '0');
INSERT INTO `db_users_a` VALUES (56, 'SarkCG', 'dlinnov@ukr.net', '666666', 'Kanadec', 55, 0, 1420905873, 1421337907, 1587103779, 0, '0');
INSERT INTO `db_users_a` VALUES (57, 'almazik', 'almazov.yur@yandex.ru', 'k300k500k700', 'Kanadec', 55, 0, 1420906113, 1422145589, 3103990101, 0, '0');
INSERT INTO `db_users_a` VALUES (58, 'sttori', 'sttori8@gmail.com', '140575alex', 'VorobeY', 34, 0, 1420906597, 1423165995, 1595815286, 0, '0');
INSERT INTO `db_users_a` VALUES (59, 'rasseikin2', 'rasseikin2015@yandex.ru', '04041981', 'test', 1, 0, 1420908600, 1421831832, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (60, 'SuperGonzo', 'supergonzo555@gmail.com', 'hbrbnbrbnfdb', 'test', 1, 0, 1420909999, 1420910010, 1047955415, 0, '0');
INSERT INTO `db_users_a` VALUES (61, 'Alfred', 'alfred.yanitski.1970@mail.ru', 'tanuha1970', 'pirat', 33, 0, 1420910897, 1422796933, 3579281611, 0, '0');
INSERT INTO `db_users_a` VALUES (62, '321321', 'olgadunai5@gmail.com', '123caribbean', 'test', 1, 14, 1420911233, 1422897152, 775272397, 0, '0');
INSERT INTO `db_users_a` VALUES (63, 'Best', 'soba4kin.p@yandex.ru', 'ghbhjlf', 'test', 1, 5, 1420911546, 1423542595, 2449408382, 0, '0');
INSERT INTO `db_users_a` VALUES (64, 'monitFerm', 'monitoring-ferm@yandex.ru', '49tgb41', 'test', 1, 4, 1420912731, 1421658496, 785611266, 0, '0');
INSERT INTO `db_users_a` VALUES (65, 'frfr', 'norbirt1@yandex.ru', '123slym123', 'VorobeY', 34, 0, 1420916262, 1421831829, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (66, 'Semen71', 'gs.gena71@yandex.ru', 'gena1971', 'test', 1, 0, 1420918268, 1422177190, 3578749674, 0, '0');
INSERT INTO `db_users_a` VALUES (67, 'kykabara', 'kot_e@mail.ua', 'kykabara777', 'VorobeY', 34, 0, 1420918778, 1421831824, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (68, 'Helen', 'elena211058@mail.ru', '2357rfeifys', 'Kanadec', 55, 1, 1420921453, 1421164207, 1606276970, 0, '0');
INSERT INTO `db_users_a` VALUES (69, 'strin', 'jekazx@mail.ru', '123654789', 'test', 1, 0, 1420923869, 1420923878, 3648410608, 0, '0');
INSERT INTO `db_users_a` VALUES (70, 'Dimbos2', 'dimbos2@yandex.ru', '13061975', 'test', 1, 0, 1420928978, 1421831820, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (71, 'som1987', 'kalber@bk.ru', 'qwert54321', 'Best', 63, 0, 1420937173, 1421831823, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (72, 'sarita', 'sarita85@yandex.ru', '5adkt4ads', 'Kanadec', 55, 49, 1420965395, 1423753225, 2953815359, 0, '0');
INSERT INTO `db_users_a` VALUES (73, 'treder', 'fattakhov.ilnur@inbox.ru', 'qwerty123456', 'test', 1, 0, 1420965591, 1423573880, 2994836114, 0, '0');
INSERT INTO `db_users_a` VALUES (74, 'SKORPION', 'skorpion5011@yandex.ru', '306496', 'Helen', 68, 0, 1420967741, 1422800839, 1522304417, 0, '0');
INSERT INTO `db_users_a` VALUES (75, 'makar2013', 'olga.melkina.82@mail.ru', '230313makar', 'Best', 63, 0, 1420968438, 1421831829, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (76, 'vitya1998', 'v.sushin2015@ya.ru', 'vityasushin', 'test', 1, 0, 1420973410, 1423321780, 1406987684, 0, '0');
INSERT INTO `db_users_a` VALUES (77, 'pantera121', 'durdq_irina@mail.ru', '0120210', 'test', 1, 0, 1420974040, 1422935665, 634846395, 0, '0');
INSERT INTO `db_users_a` VALUES (78, 'vertebra', 'agabec1958@gmail.com', 'bagdasar58', 'test', 1, 0, 1420974890, 1422682831, 631099919, 0, '0');
INSERT INTO `db_users_a` VALUES (79, 'grabitel', 'ervik65@gmail.com', 'ecgtiyfz', 'test', 1, 0, 1420976836, 1422623299, 624245082, 0, '0');
INSERT INTO `db_users_a` VALUES (80, 'IgorSap', 'igorsapeykolll@mail.ru', 'ig0010024639ig', 'Best', 63, 0, 1420980418, 1422802952, 635799128, 0, '0');
INSERT INTO `db_users_a` VALUES (81, 'brost', 'sasha-lis-2015@bk.ru', '123qwea', 'test', 1, 1, 1420982791, 1423087779, 3648409367, 0, '0');
INSERT INTO `db_users_a` VALUES (82, 'leto14', 'seg241166@gmail.com', 'selena234', 'test', 1, 0, 1420982916, 1421831833, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (83, 'Allinas', 'allinas@yandex.ru', 'de030e', 'test', 1, 0, 1420984875, 1421058050, 3585335634, 0, '0');
INSERT INTO `db_users_a` VALUES (84, 'FLINT333', 'calimbet2010@yandex.ru', 'rfgecnf787', 'test', 1, 0, 1420992137, 1423172030, 1540581712, 0, '0');
INSERT INTO `db_users_a` VALUES (85, 'rj3111', 'rj3112@mail.ru', 'qazwsx1234', 'test', 1, 0, 1420993525, 1423828113, 2996703910, 0, '0');
INSERT INTO `db_users_a` VALUES (86, 'N049', 'nikson_pr@mail.ru', '1986430', 'VorobeY', 34, 0, 1420993630, 1421831828, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (87, 'MishelSCH', 'scheglovma@yandex.ru', 'Leon919pirates', 'test', 1, 0, 1420994067, 1422794428, 93351574, 0, '0');
INSERT INTO `db_users_a` VALUES (88, 'Kizil', 'chigina.t@yandex.ru', '450442a0', 'test', 1, 0, 1420994832, 1422966500, 2449454304, 0, '0');
INSERT INTO `db_users_a` VALUES (89, 'lizok', 'chocolatepumka@gmail.com', 'lizok123', 'test', 1, 0, 1420995415, 1420995421, 92303174, 0, '0');
INSERT INTO `db_users_a` VALUES (90, 'lyuda', 'lyudmila.demenchonok@yandex.ru', 'demyan', 'VorobeY', 34, 0, 1420996894, 1421831826, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (91, 'yvital1982', 'yvital1982@mail.ru', '555y555vit', 'test', 1, 0, 1420997185, 1420997194, 1347593641, 0, '0');
INSERT INTO `db_users_a` VALUES (92, 'vasiadfhz', 'vasia.goncharenko2014@yndex.ru', 'vasiavasiavasia', 'test', 1, 0, 1420998719, 1422649638, 93176143, 0, '0');
INSERT INTO `db_users_a` VALUES (93, 'LEXXA', 'lexxa_1977@mail.ru', 'karina2003', 'test', 1, 0, 1421006180, 1421831825, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (94, 'Belfart', 'ilyarslim@mail.ru', '99ilyarvin', 'test', 1, 0, 1421007806, 1421007815, 1508406982, 0, '0');
INSERT INTO `db_users_a` VALUES (95, 'bananan', 'john.kim2015@yandex.ru', 'metro1978', 'test', 1, 0, 1421012248, 1423450184, 1565607787, 0, '0');
INSERT INTO `db_users_a` VALUES (96, 'tanda13', 'silver-key2012@mail.ru', 'a1l2i3c4e5', 'wingchun', 49, 0, 1421012367, 1423784286, 1602459373, 0, '0');
INSERT INTO `db_users_a` VALUES (97, 'asys123', 'perig.73@mail.ru', 'azsxdcfv', 'VorobeY', 34, 0, 1421022437, 1421831830, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (98, 'varava3575', 'aton3575@bk.ru', 'varava3575', 'test', 1, 0, 1421022471, 1421831817, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (99, 'Lancer', 'barac19820809@yandex.ru', 'kulinariy', 'test', 1, 0, 1421023063, 0, 2956685018, 0, '0');
INSERT INTO `db_users_a` VALUES (100, 'kentavr190', 'kentavr190@yandex.ru', '8dktBv1gtyhD', 'test', 1, 0, 1421023151, 1422376007, 86118567, 0, '0');
INSERT INTO `db_users_a` VALUES (101, 'puklich', 'o.puklich@yandex.ru', 'puklich', 'test', 1, 0, 1421028210, 1421831829, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (102, 'udacha2802', 'chitalka210@mail.ru', '2616413', 'test', 1, 0, 1421032486, 1423053313, 1502769767, 0, '0');
INSERT INTO `db_users_a` VALUES (103, 'detka', 'detka-mariya@yandex.ru', 'al1960la', 'Kanadec', 55, 0, 1421044086, 1422274258, 1476337465, 0, '0');
INSERT INTO `db_users_a` VALUES (104, 'andrey121', 'andrey121100@yandex.ru', '4321rewq', 'test', 1, 0, 1421045872, 1421831817, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (105, 'mimi877', 'mimoza_87_7@abv.bg', '27072008', 'sarita', 72, 0, 1421048410, 1423724833, 533956153, 0, '0');
INSERT INTO `db_users_a` VALUES (106, 'Lada60', 'colncenadya308@gmail.com', '66moi113', 'test', 1, 0, 1421048883, 1422772952, 3103990734, 0, '0');
INSERT INTO `db_users_a` VALUES (107, 'AngryBir', 'fotograf.russkiy@yandex.ru', 'ij3Y6tMz', 'Best', 63, 0, 1421059036, 1421831821, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (108, 'Arsin', 'yagudinlanskaya@mail.ru', 'yagudin80', 'test', 1, 0, 1421065400, 1422182578, 3645637618, 0, '0');
INSERT INTO `db_users_a` VALUES (109, 'ramill', 'tukhvatullin.ramil@bk.ru', 'mamafir', 'test', 1, 0, 1421065942, 1421831836, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (110, 'den4ik', 'den4ik@yandex.ua', '123456789', 'pirat', 33, 0, 1421068276, 1421068289, 624291364, 1, '0');
INSERT INTO `db_users_a` VALUES (111, 'gannaganna', 'ganna_ganna@inbox.ru', '12345ggg', 'wolframavt', 1, 0, 1421068332, 1421831821, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (112, 'duore', 'duore001@gmail.com', 'hln533800', 'wolframavt', 1, 0, 1421069493, 1421069506, 3743100429, 0, '0');
INSERT INTO `db_users_a` VALUES (113, '77777', 'violettadocha@yandex.ru', 'zxcvbnm', 'wolframavt', 1, 0, 1421069725, 1423596945, 1402276143, 0, '0');
INSERT INTO `db_users_a` VALUES (114, 'elen', 'elanky@yandex.ru', 'elen71218791', 'wolframavt', 1, 0, 1421073133, 1422325400, 3648410524, 0, '0');
INSERT INTO `db_users_a` VALUES (115, 'valer67', 'pietrik67@mail.ru', 'dfkthf', 'wolframavt', 1, 2, 1421076631, 1422903352, 779565800, 0, '0');
INSERT INTO `db_users_a` VALUES (116, 'danil03100', 'danil.kolpakov.00@inbox.ru', 'danilka', 'sarita', 72, 0, 1421078858, 1421831819, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (117, 'zazazaza86', 'zaza.lobzhanidze@bk.ru', 'zaza1986', 'valer67', 115, 0, 1421079361, 1421132212, 1602868140, 0, '0');
INSERT INTO `db_users_a` VALUES (118, 'kuyta', 'kuytatvk@gmail.com', 'mr63EZIa', 'valer67', 115, 0, 1421079520, 1422410068, 773192953, 0, '0');
INSERT INTO `db_users_a` VALUES (119, 'alxnd', 'alggal@mail.ru', 'YOxSuS5Ikp', 'test', 1, 0, 1421081654, 1421081661, 3648410604, 0, '0');
INSERT INTO `db_users_a` VALUES (120, 'Mope', 'seleninov@gmail.com', 'minecraft123', 'sarita', 72, 0, 1421082173, 1422875873, 2152449958, 0, '0');
INSERT INTO `db_users_a` VALUES (121, 'tapocyc', 'tapock.tapochek@yandex.ru', '9866511', 'test', 1, 0, 1421082978, 1422216145, 98893437, 0, '0');
INSERT INTO `db_users_a` VALUES (122, 'pijik68', 'pijik68@mail.ru', 'alegator', 'test', 1, 0, 1421083132, 1422881421, 628206698, 0, '0');
INSERT INTO `db_users_a` VALUES (123, 'tashiz', 'tashiz@mail.ru', 'gersham', '321321', 62, 0, 1421087366, 1422524440, 85081790, 0, '0');
INSERT INTO `db_users_a` VALUES (124, 'Snap1k', 'anishin.1998@yandex.ru', '123321', 'test', 1, 0, 1421089106, 1423326327, 783042370, 0, '0');
INSERT INTO `db_users_a` VALUES (125, 'mitin1989', 'gosha-pupkin@mail.ru', '9391653', 'monitFerm', 64, 0, 1421091828, 1421688181, 775281554, 0, '0');
INSERT INTO `db_users_a` VALUES (126, 'smirn59', 'smirn59@gmail.com', 'a2472404', 'sarita', 72, 0, 1421095392, 1423664757, 781346132, 0, '0');
INSERT INTO `db_users_a` VALUES (127, 'hose', 'hose@alivance.com', 'alivance', 'test', 1, 0, 1421100606, 1421922644, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (128, 'egorka1998', 'evtukhov1998@mail.ru', '102030', 'VorobeY', 34, 0, 1421111325, 0, 1295292468, 0, '0');
INSERT INTO `db_users_a` VALUES (129, '23232323', 'koyeka@yandex.ru', '23091981', 'Admin', 1, 0, 1421113998, 1422991779, 1841250009, 0, '0');
INSERT INTO `db_users_a` VALUES (130, 'Denis69', 'den.lodkin@yandex.ru', 'xexf69', 'Admin', 1, 0, 1421119179, 1422866405, 522905412, 0, '0');
INSERT INTO `db_users_a` VALUES (131, 'tolt', 'www.tolik.net@bk.ru', 'tolik2003', 'Kanadec', 55, 0, 1421122878, 1421122990, 2147507027, 0, '0');
INSERT INTO `db_users_a` VALUES (132, 'Legolas397', 'levlavrovenot@mail.ru', 'zercalo2', 'Admin', 1, 0, 1421123090, 1421123099, 3579284230, 0, '0');
INSERT INTO `db_users_a` VALUES (133, 'Andrey1994', 'k.andrei-94@mail.ru', '1234567890', 'Admin', 1, 0, 1421141232, 1421141242, 1427827245, 0, '0');
INSERT INTO `db_users_a` VALUES (134, 'gencjik', 'pauk1@mail.ru', '951753', 'Admin', 1, 0, 1421143377, 1421143601, 3579312190, 0, '0');
INSERT INTO `db_users_a` VALUES (135, 'denplast', 'denplast1974@gmail.com', 'chilibombers', 'sarita', 72, 0, 1421145379, 1423814726, 1299777195, 0, '0');
INSERT INTO `db_users_a` VALUES (136, 'kalash', 'rost_bot-100@mail.ru', '259love777kalash', 'Admin', 1, 0, 1421150042, 1422332352, 786677591, 0, '0');
INSERT INTO `db_users_a` VALUES (137, 'Father', 'games@work-in-net.in.ua', '46467rtt78t78', 'Admin', 1, 0, 1421154155, 1422793693, 3251148561, 0, '0');
INSERT INTO `db_users_a` VALUES (138, '73alex', 'alexandr7304@gmail.com', 'qazwsxd', 'Admin', 1, 0, 1421154938, 1421154947, 1595905274, 0, '0');
INSERT INTO `db_users_a` VALUES (139, 'vlad64', 'vlad6175@yandex.ru', 'vl919721pc', 'sarita', 72, 0, 1421159062, 1422876153, 1403415067, 0, '0');
INSERT INTO `db_users_a` VALUES (140, 'Swent', 'purtov.83@mail.ru', '9046641110', 'monitFerm', 64, 0, 1421165741, 1422707132, 3169460181, 0, '0');
INSERT INTO `db_users_a` VALUES (141, 'sergej2455', 'asadchy.sergej@yandex.by', '30111978', 'Admin', 1, 0, 1421167804, 1422118409, 1446640845, 0, '0');
INSERT INTO `db_users_a` VALUES (142, 'kyll', 'iura.ryabinov@yandex.ru', '565656', 'sarita', 72, 0, 1421170634, 1421170642, 3103990234, 0, '0');
INSERT INTO `db_users_a` VALUES (143, 'UYTTAAA', 'belodore@mail.ru', '8alfklfl5lfl23', 'sarita', 72, 0, 1421201697, 1421582682, 3645020161, 0, '0');
INSERT INTO `db_users_a` VALUES (144, 'gigabait', 'zelenko-sania@mail.ru', '123123', 'sarita', 72, 0, 1421224987, 1421831839, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (145, 'sasha118a', 'sasha118.a@gmail.com', 'sasha118', 'monitFerm', 64, 0, 1421247016, 1421247022, 1592161411, 0, '0');
INSERT INTO `db_users_a` VALUES (146, 'Slv1983', 'kolesovvv83@gmail.com', '258789', 'Admin', 1, 0, 1421253830, 1421253836, 86814011, 0, '0');
INSERT INTO `db_users_a` VALUES (147, 'erik1999', 'support@arm-farm.ru', '123456', 'Admin', 1, 0, 1421305307, 1421831835, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (148, 'mixail', 'rmaikl2006@yandex.ru', 'mixail', 'Admin', 1, 0, 1421306115, 1423820655, 1317314062, 0, '0');
INSERT INTO `db_users_a` VALUES (149, 'okosko18', 'okosko18@inbox.lv', 'qazwsxedc122', 'Admin', 1, 0, 1421309820, 1421309827, 1539193597, 0, '0');
INSERT INTO `db_users_a` VALUES (150, 'cedoiii83', 'cedoiii83@gmail.com', '2357andrei', 'Admin', 1, 0, 1421313935, 1422640142, 94780318, 0, '0');
INSERT INTO `db_users_a` VALUES (151, 'DKFL', 'arkhipov.vlad.2000@mail.ru', '159753', 'Admin', 1, 0, 1421314157, 0, 3648409364, 0, '0');
INSERT INTO `db_users_a` VALUES (152, 'MexBod', 'vladislaw.shepelenko@yandex.ru', 'dkflghjcnjcegth', 'Admin', 1, 0, 1421331432, 1421831838, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (153, 'rodar', 'super-natali.belova@yandex.ru', 'qazwsxqaz', 'Admin', 1, 0, 1421336586, 1421831835, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (154, 'dosmuxan', 'dosmuxanoo@mail.ru', 'dosmuxan', 'Admin', 1, 0, 1421339437, 1421430966, 2449449948, 0, '0');
INSERT INTO `db_users_a` VALUES (155, 'Kastaneda', 'bel.konst@mail.ru', '01091983', 'Admin', 1, 0, 1421343652, 1423780496, 2152431330, 0, '0');
INSERT INTO `db_users_a` VALUES (156, 'RUSSkir', 'mr.kirnicki@gmail.com', '2873148', 'Admin', 1, 0, 1421344769, 1423025299, 634839018, 0, '0');
INSERT INTO `db_users_a` VALUES (157, 'Mex777', 'sanek8311@mail.ru', 'lola1990', 'sarita', 72, 0, 1421350361, 1421403465, 1486067816, 0, '0');
INSERT INTO `db_users_a` VALUES (158, 'ligun', 'ligun7@mail.ru', 'ligun1996', 'Admin', 1, 0, 1421356329, 1423343303, 1315945366, 0, '0');
INSERT INTO `db_users_a` VALUES (159, 'azer', 'agalarovazer092@gmail.com', '11101984', 'sarita', 72, 0, 1421358017, 1422794875, 630623059, 0, '0');
INSERT INTO `db_users_a` VALUES (160, 'vigenpt', 'vigenpt@yandex.com', 'Ab123456bA', 'Admin', 1, 0, 1421364281, 1422878773, 631101568, 0, '0');
INSERT INTO `db_users_a` VALUES (161, 'KOLJUNJA', 'nikola20.09@mail.ru', 'koljunja2009', 'sarita', 72, 0, 1421369063, 1423430325, 3648413527, 0, '0');
INSERT INTO `db_users_a` VALUES (162, 'hkiper', 'ortyakov61@mail.ru', 'qqqwert47', 'sarita', 72, 0, 1421383769, 1421383785, 3106729971, 0, '0');
INSERT INTO `db_users_a` VALUES (163, 'bigrange', 'poshakinskiy1992@mail.ru', '25121992a', 'Admin', 1, 0, 1421405726, 1421405730, 1601167509, 0, '0');
INSERT INTO `db_users_a` VALUES (164, 'automat', 'auto8088@mail.ru', 'automat', 'Admin', 1, 0, 1421406751, 1421831818, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (165, 'zorin', 'gvv2223@ukr.net', 'felbn2223', '321321', 62, 0, 1421410991, 1422975708, 1542849804, 0, '0');
INSERT INTO `db_users_a` VALUES (166, 'shpionka', 'shpionka-007@mail.ru', '4597216836', 'Admin', 1, 0, 1421414950, 1423824549, 1446934715, 0, '0');
INSERT INTO `db_users_a` VALUES (167, 'LEMBERG', 'angelofhells@spaces.ru', 'angel123', 'Admin', 1, 0, 1421419818, 1422794251, 785627434, 0, '0');
INSERT INTO `db_users_a` VALUES (168, 'diman82', 'dmitriy-vasiliev-2012@mail.ru', '37711982', 'VorobeY', 34, 0, 1421422401, 1421422408, 2994316676, 0, '0');
INSERT INTO `db_users_a` VALUES (169, 'ivan605', 'bagachev.ivan@yandex.ru', 'pensioner', 'Admin', 1, 0, 1421425139, 1422473833, 1588742018, 0, '0');
INSERT INTO `db_users_a` VALUES (170, 'piratka', 'zakazport@mail.ru', 'paroll', 'Admin', 1, 0, 1421426299, 1423760028, 1597505343, 0, '0');
INSERT INTO `db_users_a` VALUES (171, 'f0restUA', 'zvadimz01@mail.ru', 'kykla228', 'Admin', 1, 0, 1421427725, 1421502420, 3256624893, 1, '0');
INSERT INTO `db_users_a` VALUES (172, 'aleksana', 'skoromnova1974@mail.ru', 'fedorina18101954', 'Admin', 1, 0, 1421429384, 1423233756, 2999834109, 0, '0');
INSERT INTO `db_users_a` VALUES (173, 'stryk', 'super.super-alex-brat-1974@yandex.ru', '221274qwerty', 'Admin', 1, 0, 1421430698, 0, 3161519930, 0, '0');
INSERT INTO `db_users_a` VALUES (174, 'kruger', 'kruger2@mail.ru', 'kruger2015', '321321', 62, 0, 1421430809, 1421430828, 2959461600, 0, '0');
INSERT INTO `db_users_a` VALUES (175, 'andre28424', 'andre28424@yandex.ru', '111111', 'Admin', 1, 0, 1421437008, 1421831816, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (176, 'silrgb', 'rgbcast1@mail.ru', 'rgbcastqww5', '321321', 62, 0, 1421448762, 1421831832, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (177, 'midavg', 'midavg69@gmail.com', 'koFeynya47', '321321', 62, 0, 1421466908, 1421831827, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (178, 'Vint2108', 'mr.vint2108@yandex.ru', '123698745', 'Admin', 1, 0, 1421469972, 1421831828, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (179, 'oleg111578', 'larisa.mamaeva.77@mail.ru', '111578', 'Admin', 1, 0, 1421473166, 1421473178, 1427826510, 0, '0');
INSERT INTO `db_users_a` VALUES (180, 'levft', 'levft@yandex.ru', '533423pc', 'Admin', 1, 5, 1421477649, 1423560146, 1475614186, 0, '0');
INSERT INTO `db_users_a` VALUES (181, 'tsttst', 'aleksnez@yandex.ru', '25198206', 'Admin', 1, 0, 1421480776, 1423418227, 1834954701, 0, '0');
INSERT INTO `db_users_a` VALUES (182, 'Aminalin', 'khinalina@mail.ru', 'Miller888', 'Admin', 1, 0, 1421483478, 1421831824, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (183, 'w2mwwm', 'w2mwwm-vadim@yandex.ru', '318398', '321321', 62, 0, 1421494968, 1423803090, 2953833247, 0, '0');
INSERT INTO `db_users_a` VALUES (184, 'zhuravell', 'zhuravell@mail.ru', 'nizamipolsha', '321321', 62, 0, 1421527366, 1422142504, 3648409203, 0, '0');
INSERT INTO `db_users_a` VALUES (185, 'vitaminka', 'toria0207@mail.ru', '147258369', '321321', 62, 4, 1421535725, 1423836829, 1843613086, 0, '0');
INSERT INTO `db_users_a` VALUES (186, 'kovy83', 'kovy83@yandex.ru', '230987', 'sarita', 72, 0, 1421575505, 1421831824, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (187, 'annaolga', 'morisok123@gmail.com', '123987', 'levft', 180, 4, 1421583714, 1423521524, 1427815007, 0, '0');
INSERT INTO `db_users_a` VALUES (188, 'aivaras881', 'aivarasadomaitis881@gmail.com', 'spartanas', 'sarita', 72, 0, 1421593583, 1422613748, 1490985828, 0, '0');
INSERT INTO `db_users_a` VALUES (189, 'oksolin', 'miss.porutchikova@mail.ru', 'celeronvistainside', 'sarita', 72, 0, 1421596309, 1423066304, 2999953554, 0, '0');
INSERT INTO `db_users_a` VALUES (190, 'Ryba30', 'rybchik80@mail.ru', 'RS321580', 'levft', 180, 0, 1421612602, 1421831833, 1531941902, 1, '0');
INSERT INTO `db_users_a` VALUES (191, 'kvach', 'kvach-888@mail.ru', '123456789', 'annaolga', 187, 0, 1421619400, 1421619411, 2992536985, 0, '0');
INSERT INTO `db_users_a` VALUES (192, 'valter', 'barbosov.2000@mail.ru', '1212123qw', 'brost', 81, 0, 1421655102, 1423745582, 1402286202, 0, '0');
INSERT INTO `db_users_a` VALUES (193, 'sint', 'gladishev.oleg@yandex.ru', '01301977sunt', 'monitFerm', 64, 0, 1421657795, 1422793017, 1348213023, 0, '0');
INSERT INTO `db_users_a` VALUES (194, 'kukanik', 'ayvazyanvachagan@gmail.com', 'kukanik1970', 'sarita', 72, 0, 1421658743, 1423831100, 632964360, 0, '0');
INSERT INTO `db_users_a` VALUES (195, 'Viy007', 'viyoo7@yandex.ru', 'mokrov', 'sarita', 72, 0, 1421672312, 1422015468, 1541685559, 0, '0');
INSERT INTO `db_users_a` VALUES (196, 'kelmonda', 'adamdaurov1997@gmail.com', 'adam1997', 'sarita', 72, 0, 1421700539, 1423556210, 3000604915, 0, '0');
INSERT INTO `db_users_a` VALUES (197, 'vvladk', 'vvladk@ukr.net', '147258', '321321', 62, 0, 1421756677, 1422126349, 624403468, 0, '0');
INSERT INTO `db_users_a` VALUES (198, 'sarapul', 'sarapulplus.ru@yandex.ru', '2135409ZX', 'Admin', 1, 0, 1421762207, 1423575800, 3648410512, 0, '0');
INSERT INTO `db_users_a` VALUES (199, 'tane4ka987', 'kitana90@i.ua', '03062014', 'sarita', 72, 0, 1421775647, 1422365501, 3164819828, 0, '0');
INSERT INTO `db_users_a` VALUES (200, 'milliorder', 'gumenyuk.olesya@inbox.ru', '20091209', 'sarita', 72, 0, 1421777408, 1421777415, 2965512946, 0, '0');
INSERT INTO `db_users_a` VALUES (201, 'stupak62', 'stupak1962@yandex.ru', '1962269119622691', 'sarita', 72, 1, 1421781501, 1423798962, 1505585436, 0, '0');
INSERT INTO `db_users_a` VALUES (202, 'den5800', 'den_kalugar@rambler.ru', 'qazwsxEDC7654321', 'Admin', 1, 0, 1421795440, 1421795447, 3000548237, 0, '0');
INSERT INTO `db_users_a` VALUES (203, 'jayzy', 'xaker2@mail.ru', '123456', 'Best', 63, 0, 1421849442, 1423423457, 2960670648, 0, '0');
INSERT INTO `db_users_a` VALUES (204, 'iris1502', 'angelanddragon@yandex.com', '998911336505', 'sarita', 72, 0, 1421905786, 1423241786, 3588639512, 0, '0');
INSERT INTO `db_users_a` VALUES (205, 'temass', 'artem_alex@mail.ua', '26081985', 'Kanadec', 55, 0, 1421912927, 1422800299, 1540963569, 0, '0');
INSERT INTO `db_users_a` VALUES (206, 'babkyy', 'moric23865@gmail.com', 'valera2000', 'annaolga', 187, 0, 1421922291, 1423066607, 2449453148, 0, '0');
INSERT INTO `db_users_a` VALUES (207, 'Deit15', 'kostya19991@ukr.net', '147963', 'sarita', 72, 0, 1421946599, 1423164013, 3588700348, 0, '0');
INSERT INTO `db_users_a` VALUES (208, 'csserv55', 'csserv55@mail.ru', '88888888', 'levft', 180, 0, 1422014129, 1422014139, 787072817, 0, '0');
INSERT INTO `db_users_a` VALUES (209, 'fktrc906', '89377124804@yandex.ru', 'gorynyj', 'sarita', 72, 2, 1422017799, 1423644307, 1603915008, 0, '0');
INSERT INTO `db_users_a` VALUES (210, 'selzhan', 'fatkullas@mail.ru', 'seilzhan2001', 'annaolga', 187, 0, 1422017806, 1422017813, 3563081404, 0, '0');
INSERT INTO `db_users_a` VALUES (211, 'blesk1', 'blesk1@atlas.sk', 'kapurka', 'sarita', 72, 0, 1422027441, 1422027448, 1490299588, 0, '0');
INSERT INTO `db_users_a` VALUES (212, 'slava3201', 'vyacheslav.karpov.12@mail.ru', '16slava32', 'sarita', 72, 0, 1422047270, 1423336711, 633362277, 0, '0');
INSERT INTO `db_users_a` VALUES (213, 'Nogar', 'nogar31@gmail.com', 'nogar311', 'vitaminka', 185, 0, 1422068954, 1423784305, 3107386921, 0, '0');
INSERT INTO `db_users_a` VALUES (214, 'Alegator59', 'investusd@yandex.ru', '25262740', 'sarita', 72, 0, 1422093760, 1422974015, 3166604231, 0, '0');
INSERT INTO `db_users_a` VALUES (215, 'Yfnfkbz', 'stipahamidiya@yandex.ru', 'yfnfkb', 'wingchun', 49, 0, 1422093791, 1422603224, 1467298561, 0, '0');
INSERT INTO `db_users_a` VALUES (216, 'GetLens', 'suturin2@yandex.ru', '1p7o5p7u4l7i', 'sarita', 72, 0, 1422105705, 1423761315, 1541962464, 0, '0');
INSERT INTO `db_users_a` VALUES (217, 'dens', 'dens_-_18@mail.ru', 'dens1991', 'annaolga', 187, 0, 1422107610, 1423385934, 1406987590, 0, '0');
INSERT INTO `db_users_a` VALUES (218, 'dankow98', 'danko_98_kz@bk.ru', 'dan98ko', 'vitaminka', 185, 0, 1422116992, 1422117005, 2500066928, 0, '0');
INSERT INTO `db_users_a` VALUES (219, 'ZET1', 'ms.yuliya79@bk.ru', '333444', 'sarita', 72, 0, 1422140387, 1423725892, 3164753929, 0, '0');
INSERT INTO `db_users_a` VALUES (220, 'zums', 'nfswin1@mail.ru', '2554809', '321321', 62, 0, 1422185683, 1422597590, 1310292644, 0, '0');
INSERT INTO `db_users_a` VALUES (221, 'bhbirf906', 'bhbirf906@yandex.ru', 'bhbirf8906', 'fktrc906', 209, 0, 1422190551, 1423805825, 1603910396, 0, '0');
INSERT INTO `db_users_a` VALUES (222, 'Ryslan777', 'ryslahaka.2012@mail.ru', 'ryslahaka2010', '321321', 62, 0, 1422194265, 1423088094, 1540034474, 0, '0');
INSERT INTO `db_users_a` VALUES (223, 'GERAKL', 'gerakl.karabelnikov@yandex.ru', 'laifsex333', 'levft', 180, 0, 1422195813, 1423056729, 1592309765, 0, '0');
INSERT INTO `db_users_a` VALUES (224, 'tiger55555', 'vilejaninov2012@yandex.ru', 'asdfghjkl', 'vitaminka', 185, 0, 1422216379, 1422823587, 1597282990, 0, '0');
INSERT INTO `db_users_a` VALUES (225, 'imkatla', 'allakisa1369@mail.ru', 'devilinthepower1369', 'Admin', 1, 2, 1422305202, 1423825202, 2996732941, 0, '0');
INSERT INTO `db_users_a` VALUES (226, 'Askadeus', 'askadeus@bk.ru', '2248511qQ', 'imkatla', 225, 0, 1422305920, 1422565439, 1369673655, 0, '0');
INSERT INTO `db_users_a` VALUES (227, 'abnormalen', 'abnormalenka@mail.ru', '12345678', 'imkatla', 225, 0, 1422307094, 1422988226, 1566169297, 0, '0');
INSERT INTO `db_users_a` VALUES (228, 'Mixaluch', 'aleksandr.vdovin.97@mail.ru', '19MS04199702V3', 'monitFerm', 64, 0, 1422332276, 1423844581, 1596273318, 0, '0');
INSERT INTO `db_users_a` VALUES (229, 'mamaaa', '2012mamaaa@gmail.com', '25301911', '321321', 62, 0, 1422354668, 1422373253, 1598422210, 0, '0');
INSERT INTO `db_users_a` VALUES (230, 'Sss502', 'typoki@mail.ru', '332285030718', 'sarita', 72, 0, 1422356080, 1423765410, 1295292758, 0, '0');
INSERT INTO `db_users_a` VALUES (231, 'palpalyh', 'palpalyh@gmail.com', 'd907g824p', 'vitaminka', 185, 0, 1422370277, 1423826390, 2997443987, 0, '0');
INSERT INTO `db_users_a` VALUES (232, 'olegator74', 'mov08051968@mail.ru', 'Wkt97SN3', 'Admin', 1, 0, 1422428279, 1423146638, 521099925, 0, '0');
INSERT INTO `db_users_a` VALUES (233, 'noorg', 'noorg1@yandex.ru', 'donalcogolito', 'sarita', 72, 0, 1422465863, 1422498486, 2989336360, 0, '0');
INSERT INTO `db_users_a` VALUES (234, 'snezhana', 'snezhana.tokareva@mail.ru', 'kbpf2008', 'Admin', 1, 0, 1422471672, 1422737376, 1464663583, 0, '0');
INSERT INTO `db_users_a` VALUES (235, 'romka', 'romka_rad@mail.ru', '720830as', 'Admin', 1, 0, 1422517617, 1422865750, 2992392354, 0, '0');
INSERT INTO `db_users_a` VALUES (236, 'CrazyLegen', 'nikulina.kseniya@mail.ru', 'dfcbkbq76', '321321', 62, 0, 1422528932, 1422705974, 1531829077, 0, '0');
INSERT INTO `db_users_a` VALUES (237, 'volume', 'mamanya1954@rambler.ru', 'mib222', 'Admin', 1, 0, 1422545002, 1423834787, 2966729493, 0, '0');
INSERT INTO `db_users_a` VALUES (238, 'mar4', 'alina_muhamedyan@mail.ru', '951753', 'Admin', 1, 0, 1422552832, 1422552840, 1475986708, 0, '0');
INSERT INTO `db_users_a` VALUES (239, 'karolina55', 'kbegar@bk.ru', 'mezins99', 'sarita', 72, 0, 1422556295, 1423373780, 785618708, 0, '0');
INSERT INTO `db_users_a` VALUES (240, 'abdula', 'abdula@mail.ru', '123123a', 'sarita', 72, 0, 1422564164, 1422564178, 3579284839, 0, '0');
INSERT INTO `db_users_a` VALUES (241, 'islam1991', 'islam_avdaev@mail.ru', 'gelani17', 'Admin', 1, 0, 1422573759, 1422573778, 1433663537, 0, '0');
INSERT INTO `db_users_a` VALUES (242, 'lema', 'lema_248@mail.ru', '123jkz123jkz', 'Admin', 1, 0, 1422602515, 1422953638, 2959874601, 0, '0');
INSERT INTO `db_users_a` VALUES (243, 'toys', 'qwerasdf87@yandex.ru', '17032007z', 'Admin', 1, 0, 1422609025, 1423843750, 2965679023, 0, '0');
INSERT INTO `db_users_a` VALUES (244, 'amince', 'agagkl88@gmail.com', 'Piraatinjicariibi8', 'Admin', 1, 0, 1422616847, 1423816529, 1589262391, 0, '0');
INSERT INTO `db_users_a` VALUES (245, 'Erejep', '95_erejep@mail.ru', '87751189699b', 'Admin', 1, 0, 1422628717, 1422719940, 2992328252, 0, '0');
INSERT INTO `db_users_a` VALUES (246, 'FBi59', 'evdocimov2014@mail.ru', 'fp2489', 'Admin', 1, 0, 1422629125, 1422629140, 1580397229, 0, '0');
INSERT INTO `db_users_a` VALUES (247, 'Vktor1987', 'vityusha.luchko@mail.ru', 'suso55pozobo53evuver', 'sarita', 72, 0, 1422629517, 1422629538, 1601152719, 0, '0');
INSERT INTO `db_users_a` VALUES (248, 'usame', 'vaybe_sen_ben@hotmail.com', '01021993', 'Admin', 1, 0, 1422649449, 1422649455, 1433008254, 0, '0');
INSERT INTO `db_users_a` VALUES (249, 'swerg', 'swerg@mail.ru', '22111975', 'Admin', 1, 0, 1422691344, 1423066976, 1509877704, 0, '0');
INSERT INTO `db_users_a` VALUES (250, 'andron1144', 'marat333-74@mail.ru', 'gfcgjhn0706', 'sarita', 72, 0, 1422695424, 1423759549, 92968487, 0, '0');
INSERT INTO `db_users_a` VALUES (251, 'scorpion66', 'smierti89@bk.ru', 'demon666', 'sarita', 72, 0, 1422696756, 1422696767, 1389395177, 0, '0');
INSERT INTO `db_users_a` VALUES (252, 'a100500q', 'flirchi-2012@ya.ru', '147741147', 'Admin', 1, 0, 1422698298, 1423299738, 1595528905, 0, '0');
INSERT INTO `db_users_a` VALUES (253, 'Vagan', 'vasiliy.vaganin@yandex.ru', 'GhjcnjDfctr06988', 'sarita', 72, 0, 1422711063, 1423838945, 1540901043, 0, '0');
INSERT INTO `db_users_a` VALUES (254, 'robetoman', 'fedorow.s2013@yandex.ru', '1234561', 'Admin', 1, 0, 1422715824, 1422715829, 3166670968, 0, '0');
INSERT INTO `db_users_a` VALUES (255, 'xxx555', 'denis-balaev@mail.ru', '555333535', 'Admin', 1, 0, 1422717423, 1422717435, 1359302787, 0, '0');
INSERT INTO `db_users_a` VALUES (256, 'Doshs', 'des101des@mail.ru', '123456', 'Admin', 1, 0, 1422718862, 1423504863, 3156935564, 0, '0');
INSERT INTO `db_users_a` VALUES (257, 'Gennadiy77', 'mikolaichuk77@mail.ru', 'gena1977d1903', '321321', 62, 0, 1422726490, 1422761986, 621917781, 0, '0');
INSERT INTO `db_users_a` VALUES (258, 'galstya', 'support@funny-fishing.ru', '123456', 'Admin', 1, 0, 1422798533, 1422799041, 631102986, 0, '0');
INSERT INTO `db_users_a` VALUES (259, 'erik1999ff', 'erikkazaryan99@mail.ru', '123456', 'Admin', 1, 0, 1422799371, 1422799384, 631102986, 0, '0');
INSERT INTO `db_users_a` VALUES (260, 'tornadosta', 'tornadostar@ukr.net', '28s38s48d', 'sarita', 72, 0, 1422804656, 1423823823, 1834375806, 0, '0');
INSERT INTO `db_users_a` VALUES (261, 'cactyc', 'cactyc@yandex.ru', 'BAT1919YRIira', 'sarita', 72, 0, 1422806151, 1422806174, 100193302, 0, '0');
INSERT INTO `db_users_a` VALUES (262, 'viktors', '5440353@mail.ru', '1949dbnmrf', 'Admin', 1, 0, 1422810861, 1422810876, 1598651114, 0, '0');
INSERT INTO `db_users_a` VALUES (268, 'udovitskiy', 'sanek_199106@mail.ru', 'udovitskiy', 'Admin', 1, 0, 1422967217, 1423430437, 625603500, 0, '0');
INSERT INTO `db_users_a` VALUES (263, 'FeeLing', 'xlobystov1998@mail.ru', 'master1998', 'Admin', 1, 0, 1422823667, 1422823675, 2959466436, 0, '0');
INSERT INTO `db_users_a` VALUES (264, 'Zero35', 'lavrencova.lisa@mail.ru', '234234234', 'sarita', 72, 0, 1422832973, 1422833197, 634855726, 0, '0');
INSERT INTO `db_users_a` VALUES (265, 'morr', 'enicei@inbox.ru', 'nbvjattdbx', 'Admin', 1, 0, 1422846936, 1422846963, 788459737, 0, '0');
INSERT INTO `db_users_a` VALUES (266, 'Ririeajj', 'upzzemmz@rocketmail.com', 'sachie1990', 'Admin', 1, 0, 1422862873, 1422862932, 1920565543, 0, '0');
INSERT INTO `db_users_a` VALUES (267, 'rty6ty', '4196237@gmail.com', '4567ujhgfde456yu', 'sarita', 72, 0, 1422900472, 1422900484, 1407042265, 0, '0');
INSERT INTO `db_users_a` VALUES (269, 'bodev', 'bodevbodev@gmail.com', 'qazwsx', 'Admin', 1, 0, 1422971876, 1423495960, 1297951410, 0, '0');
INSERT INTO `db_users_a` VALUES (270, 'cariden', 'android2121agca@gmail.com', 'android', 'sarita', 72, 1, 1422984603, 1423819615, 2682264122, 0, '0');
INSERT INTO `db_users_a` VALUES (271, 'mishanja30', 'mishanja.ru@mail.ru', '180183kim', 'sarita', 72, 0, 1422999924, 1423684015, 624314887, 0, '0');
INSERT INTO `db_users_a` VALUES (272, '2069321', 'a@a.ru', 'wwwwwww', 'Admin', 1, 0, 1423037390, 1423508526, 2990614236, 0, '0');
INSERT INTO `db_users_a` VALUES (273, 'chelton085', 'chelton085@mail.ru', 'karapuz85', 'Admin', 1, 0, 1423037592, 1423037606, 3106008736, 0, '0');
INSERT INTO `db_users_a` VALUES (274, 'dima12321', 'agent401@mail.ru', '1q2w3e4r5t', 'sarita', 72, 0, 1423067008, 1423067017, 621872403, 0, '0');
INSERT INTO `db_users_a` VALUES (275, 'stupak2691', 'stupak2691@yandex.ru', 'cnegfrcthutq', 'stupak62', 201, 0, 1423067023, 1423737799, 1047872724, 0, '0');
INSERT INTO `db_users_a` VALUES (276, 'rerishari', 'rerishari@ya.ru', 'b3S3v63Q', 'levft', 180, 0, 1423086003, 1423086009, 1504305081, 0, '0');
INSERT INTO `db_users_a` VALUES (277, 'SUMRAC', 'boss.shpomer@gmail.com', 'QWERTY', 'fktrc906', 209, 0, 1423139294, 1423771801, 3648409370, 0, '0');
INSERT INTO `db_users_a` VALUES (278, 'Asasins123', 'abadyal@mail.ru', 'AVG2004', 'Admin', 1, 0, 1423154565, 1423154700, 1602528583, 0, '0');
INSERT INTO `db_users_a` VALUES (279, 'Evgeniy888', 'qwert468@tut.by', 'ZxCvBn8023517382831', 'Admin', 1, 0, 1423163082, 1423777339, 2994292402, 0, '0');
INSERT INTO `db_users_a` VALUES (280, 'tverdun927', 'tverdun927@gmail.com', 'Lada2107', 'cariden', 270, 0, 1423173119, 1423759457, 2992567568, 0, '0');
INSERT INTO `db_users_a` VALUES (281, 'Bakeshi', 'bulat_x@mail.ru', '123654789', 'Admin', 1, 0, 1423192140, 1423828399, 3566902570, 0, '0');
INSERT INTO `db_users_a` VALUES (282, 'missklv', 'miss-klv@yandex.ru', 'qweqwe', 'Admin', 1, 0, 1423217543, 1423217551, 1595535375, 0, '0');
INSERT INTO `db_users_a` VALUES (283, 'ganne', 'beauty.venera@gmail.com', 'yhn963852741', 'Admin', 1, 0, 1423267825, 1423777201, 1504880234, 0, '0');
INSERT INTO `db_users_a` VALUES (284, 'izadora', 'ol.schapina@yandex.ru', 'ambasador1100', 'sarita', 72, 0, 1423325456, 1423389683, 1310309418, 0, '0');
INSERT INTO `db_users_a` VALUES (285, 'blizz88', 'kino-mania@yandex.ru', '123456', 'Admin', 1, 0, 1423400667, 1423400692, 3104670785, 0, '0');
INSERT INTO `db_users_a` VALUES (286, 'kvozimir', 'kvozimir@yandex.ru', '123456', 'Admin', 1, 0, 1423413311, 1423413319, 3579279593, 0, '0');
INSERT INTO `db_users_a` VALUES (287, 'admin1', 'kirpich229@mail.ru', 'admin1', 'Admin', 1, 0, 1423487670, 1423487704, 3169334328, 0, '0');
INSERT INTO `db_users_a` VALUES (288, 'Diknoa', 'diknoa@bk.ru', '123455', 'Admin', 1, 0, 1423497385, 1423497392, 3648409865, 0, '0');
INSERT INTO `db_users_a` VALUES (289, 'dima008', 'dima008@mail.ru', '12369874', 'Admin', 1, 0, 1423497884, 1423497888, 625890063, 0, '0');
INSERT INTO `db_users_a` VALUES (290, 'demo', 'demo@mail.com', '123456', 'Admin', 1, 0, 1423506942, 1423506950, 1427827498, 0, '0');
INSERT INTO `db_users_a` VALUES (291, 'soso', 'soso@mail.ru', 'sosososo', 'Admin', 1, 0, 1423511333, 1423511337, 98819682, 0, '0');
INSERT INTO `db_users_a` VALUES (292, 'maks2108', 'tixonov.maksim.1987@yandex.ua', 'MAKA21081992', 'Admin', 1, 0, 1423562631, 1423562643, 3283665385, 0, '0');
INSERT INTO `db_users_a` VALUES (293, 'practik', 'sshhot.com@yandex.ru', 'ananim947', 'sarita', 72, 0, 1423574230, 1423574238, 3648405561, 0, '0');
INSERT INTO `db_users_a` VALUES (294, 'Romka92', 'ya.akhmerov2014@yandex.ru', 'Rafkat100992', 'sarita', 72, 0, 1423620699, 1423620709, 2151961578, 0, '0');
INSERT INTO `db_users_a` VALUES (295, 'mitya777', 'mitya.rom2016@yandex.ru', 'qwert123', 'sarita', 72, 0, 1423681900, 1423767424, 1427809626, 0, '0');
INSERT INTO `db_users_a` VALUES (296, 'schcolnik', 'admin@schcolnik.ru', '112233', 'Admin', 1, 0, 1423767144, 1423767147, 2988634160, 0, '0');
INSERT INTO `db_users_a` VALUES (297, 'alexsoft59', 'alexsoft59@gmail.com', '123456', 'Admin', 1, 0, 1423819916, 1423819922, 93107917, 0, '0');
INSERT INTO `db_users_a` VALUES (298, 'kondor', 'crysis.ryzhih@yandex.ru', '199019901990', 'Admin', 1, 0, 1462616717, 1462616726, 3648405557, 0, '0');
INSERT INTO `db_users_a` VALUES (299, 'MegaScript', 'f0rest009@mail.ru', '0000000', 'Admin', 1, 0, 1462619003, 1462619020, 625916720, 0, '0');
INSERT INTO `db_users_a` VALUES (300, 'romdik', 'cherem120@gmail.com', 'zzzzzxx', 'test', 1, 0, 1473000132, 1473244687, 92830826, 0, '0');
INSERT INTO `db_users_a` VALUES (301, 'games', 'wormix456@mail.ua', '123456', 'test', 1, 0, 1473225922, 1473225940, 1540214356, 0, '0');

-- --------------------------------------------------------

-- 
-- ��������� ������� `db_users_b`
-- 

CREATE TABLE `db_users_b` (
  `id` int(11) NOT NULL default '0',
  `user` varchar(10) NOT NULL default '',
  `money_b` double NOT NULL default '0',
  `money_p` double NOT NULL default '0',
  `a_t` int(11) NOT NULL default '0',
  `b_t` int(11) NOT NULL default '0',
  `c_t` int(11) NOT NULL default '0',
  `d_t` int(11) NOT NULL default '0',
  `e_t` int(11) NOT NULL default '0',
  `a_b` int(11) NOT NULL default '0',
  `b_b` int(11) NOT NULL default '0',
  `c_b` int(11) NOT NULL default '0',
  `d_b` int(11) NOT NULL default '0',
  `e_b` int(11) NOT NULL default '0',
  `all_time_a` int(11) NOT NULL default '0',
  `all_time_b` int(11) NOT NULL default '0',
  `all_time_c` int(11) NOT NULL default '0',
  `all_time_d` int(11) NOT NULL default '0',
  `all_time_e` int(11) NOT NULL default '0',
  `last_sbor` int(11) NOT NULL default '0',
  `from_referals` double NOT NULL default '0',
  `to_referer` double NOT NULL default '0',
  `payment_sum` double NOT NULL default '0',
  `insert_sum` double NOT NULL default '0',
  `billet` int(1) NOT NULL default '0',
  `days` varchar(55) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- 
-- ���� ������ ������� `db_users_b`
-- 

INSERT INTO `db_users_b` VALUES (1, 'Admin', 245.633, 211.687, 2, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90723, 1464025656, 34950, 1845, 9.56, 502, 0, '0');
INSERT INTO `db_users_b` VALUES (34, 'VorobeY', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420889513, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (33, 'pirat', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422251932, 20, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (32, 'appledox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420888544, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (31, 'Deniska199', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420888161, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (30, 'ischeg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420887527, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (29, 'herues2009', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420892211, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (28, 'DenTODDesT', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421845831, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (27, 'Zippo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420886093, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (26, 'frog', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420885879, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (25, 'VladimirVi', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422551507, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (35, 'looop', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420905489, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (24, 'kolkoo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420886090, 0, 30, 0, 1650, 0, '0');
INSERT INTO `db_users_b` VALUES (22, 'Sano460', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420968145, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (23, 'Ludo95', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420885071, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (21, 'kolkovpira', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420884774, 0, 0, 0, 250, 0, '0');
INSERT INTO `db_users_b` VALUES (36, 'kostq', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420890701, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (37, 'admi1998', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420891415, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (38, 'mixayamaha', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420892438, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (39, 'skroliks', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420892890, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (40, 'sashatlt8', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420892966, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (41, 'Siskashvil', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420893074, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (42, 'qwerty', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421169975, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (43, 'matveik22', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421562740, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (44, 'RockTheStr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420897694, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (45, 'Valera01', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420901682, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (46, 'Ruty', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420900910, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (47, 'heeer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420901238, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (48, 'and23154', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420901492, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (49, 'wingchun', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422026360, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (50, 'Aleksandr1', -11, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422794306, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (51, 'YRIIK', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420903572, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (52, 'Sheamus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420903784, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (53, 'Dronuks', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420952042, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (54, 'ACTORS', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420904754, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (55, 'Kanadec', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420915069, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (56, 'SarkCG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421337936, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (57, 'almazik', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422145611, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (58, 'sttori', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422197894, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (59, 'rasseikin2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420908600, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (60, 'SuperGonzo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420909999, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (61, 'Alfred', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421205206, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (62, '321321', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422555176, 0, 2000, 0, 0, 2, '0');
INSERT INTO `db_users_b` VALUES (63, 'Best', 63.1175, 3.8325, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1643, 0, 0, 0, 0, 1423542618, 0, 2000, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (64, 'monitFerm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421659250, 2100, 5000, 0, 0, 3, '0');
INSERT INTO `db_users_b` VALUES (65, 'frfr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420916262, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (66, 'Semen71', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422177247, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (67, 'kykabara', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420918778, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (68, 'Helen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421164219, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (69, 'strin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420923869, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (70, 'Dimbos2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421540292, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (71, 'som1987', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421163486, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (72, 'sarita', 70.5134999999999, 126.2765, 4, 5, 0, 0, 0, 0, 0, 0, 0, 0, 4394, 49724, 0, 0, 0, 1423319443, 5020, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (73, 'treder', 615.9065, 275.1035, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423573940, 0, 4000, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (243, 'toys', 1007.218, 1506.502, 42, 17, 8, 1, 0, 0, 0, 0, 0, 0, 55900, 264715, 977009, 633734, 0, 1423798510, 0, 4075, 9, 205, 0, '0');
INSERT INTO `db_users_b` VALUES (74, 'SKORPION', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421842675, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (75, 'makar2013', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421809817, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (76, 'vitya1998', 47, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422184684, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (77, 'pantera121', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420974040, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (78, 'vertebra', 53, 0, 0, 0, 0, 0, 0, 1003, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421989597, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (79, 'grabitel', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422300335, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (80, 'IgorSap', 2.4505, 1.3195, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421271351, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (81, 'brost', 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422304548, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (82, 'leto14', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420982916, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (196, 'kelmonda', 74.754, 0.406, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421789853, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (83, 'Allinas', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420984875, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (84, 'FLINT333', 142, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422558161, 0, 2000, 0, 0, 2, '0');
INSERT INTO `db_users_b` VALUES (85, 'rj3111', 62.314, 78.246, 11, 1, 0, 0, 0, 0, 0, 0, 0, 0, 11082, 22451, 0, 0, 0, 1423773728, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (86, 'N049', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420993630, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (87, 'MishelSCH', 33, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420994067, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (88, 'Kizil', -13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422966539, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (89, 'lizok', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420995415, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (90, 'lyuda', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420996894, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (91, 'yvital1982', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1420997185, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (92, 'vasiadfhz', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422461430, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (93, 'LEXXA', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421679491, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (94, 'Belfart', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421007806, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (95, 'bananan', -16, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423450233, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (96, 'tanda13', 38, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423784409, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (97, 'asys123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421022437, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (98, 'varava3575', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421022471, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (99, 'Lancer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421023063, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (100, 'kentavr190', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422376024, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (101, 'puklich', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421324641, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (102, 'udacha2802', 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422529288, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (103, 'detka', 0, 0, 0, 0, 0, 0, 0, 1528, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422274269, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (104, 'andrey121', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421045872, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (105, 'mimi877', 97.6875, 17.0625, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7312, 0, 0, 0, 0, 1423724839, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (106, 'Lada60', 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422558519, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (107, 'AngryBir', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421059036, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (108, 'Arsin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421764015, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (109, 'ramill', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421236960, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (110, 'den4ik', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421068368, 0, 20, 0, 666, 0, '0');
INSERT INTO `db_users_b` VALUES (111, 'gannaganna', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421659425, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (112, 'duore', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421069493, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (113, '77777', 51, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423597000, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (114, 'elen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422325469, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (115, 'valer67', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421076631, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (116, 'danil03100', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421078858, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (117, 'zazazaza86', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421132231, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (118, 'kuyta', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422410138, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (119, 'alxnd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421081654, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (120, 'Mope', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422433159, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (121, 'tapocyc', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422216275, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (122, 'pijik68', 78, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422604178, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (123, 'tashiz', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422524448, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (124, 'Snap1k', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421522528, 0, 0, 0, 300, 0, '0');
INSERT INTO `db_users_b` VALUES (125, 'mitin1989', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421688252, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (126, 'smirn59', 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423664787, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (127, 'hose', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421922695, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (128, 'egorka1998', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421111325, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (129, '23232323', -26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422308488, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (130, 'Denis69', 91, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422683107, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (131, 'tolt', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421122878, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (132, 'Legolas397', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421123090, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (133, 'Andrey1994', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421141232, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (134, 'gencjik', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421143377, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (135, 'denplast', 64.0535, 18.3365, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7858, 0, 0, 0, 0, 1423814760, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (136, 'kalash', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422332488, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (137, 'Father', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422793756, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (138, '73alex', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421154938, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (139, 'vlad64', 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422465021, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (140, 'Swent', 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422707154, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (141, 'sergej2455', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422118438, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (142, 'kyll', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421170634, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (180, 'levft', 149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422434043, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (143, 'UYTTAAA', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421582690, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (144, 'gigabait', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421224987, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (145, 'sasha118a', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421247016, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (146, 'Slv1983', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421253830, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (147, 'erik1999', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421305307, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (148, 'mixail', 624.163, 3.857, 1, 0, 0, 0, 0, 288, 0, 0, 0, 0, 1940, 0, 0, 0, 0, 1423820684, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (149, 'okosko18', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421309820, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (150, 'cedoiii83', 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422453872, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (151, 'DKFL', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421314157, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (152, 'MexBod', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421331432, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (153, 'rodar', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421336586, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (154, 'dosmuxan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421431015, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (155, 'Kastaneda', 6.7105, 15.4595, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6625, 0, 0, 0, 0, 1423780506, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (156, 'RUSSkir', 125, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422489551, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (157, 'Mex777', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421350361, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (158, 'ligun', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422491666, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (159, 'azer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421599828, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (160, 'vigenpt', 33, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422878883, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (161, 'KOLJUNJA', 85.171, 1.169, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 501, 0, 0, 0, 0, 1423430348, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (162, 'hkiper', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421383769, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (163, 'bigrange', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421405726, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (164, 'automat', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421406751, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (165, 'zorin', 36, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421410991, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (166, 'shpionka', 75.8260000000028, 13691.214, 218, 38, 12, 2, 2, 0, 0, 0, 0, 0, 343332, 474442, 1422343, 1299306, 6530381, 1423824571, 0, 12000, 98.05, 500, 0, '0');
INSERT INTO `db_users_b` VALUES (167, 'LEMBERG', -80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421419818, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (168, 'diman82', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421422401, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (169, 'ivan605', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421425139, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (170, 'piratka', -17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423760082, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (171, 'f0restUA', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421571638, 0, 0, 0, 0, 2, '0');
INSERT INTO `db_users_b` VALUES (172, 'aleksana', 14, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423233810, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (173, 'stryk', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421430698, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (174, 'kruger', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421430809, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (186, 'kovy83', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421575505, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (176, 'silrgb', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421448762, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (175, 'andre28424', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421437008, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (177, 'midavg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421466908, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (178, 'Vint2108', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421469972, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (179, 'oleg111578', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421473166, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (181, 'tsttst', 54, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421480776, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (182, 'Aminalin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421483478, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (183, 'w2mwwm', 94.84, 81.76, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35039, 0, 0, 0, 0, 1423823199, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (188, 'aivaras881', 33, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422527340, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (184, 'zhuravell', 0, 0, 0, 0, 0, 0, 0, 1913, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422142550, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (185, 'vitaminka', 23.9995, 3.2305, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1384, 0, 0, 0, 0, 1423498447, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (187, 'annaolga', -11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422302698, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (189, 'oksolin', 190, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421657236, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (190, 'Ryba30', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421612602, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (191, 'kvach', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421619400, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (192, 'valter', 29, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423745682, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (193, 'sint', 43, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422543845, 0, 2100, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (194, 'kukanik', 45.729, 21.931, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9398, 0, 0, 0, 0, 1423831126, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (195, 'Viy007', 0, 0, 0, 0, 0, 0, 0, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422020503, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (197, 'vvladk', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422126366, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (202, 'den5800', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421795440, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (198, 'sarapul', 89.656, 3.584, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1535, 0, 0, 0, 0, 1423575867, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (199, 'tane4ka987', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422220347, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (200, 'milliorder', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421777408, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (201, 'stupak62', 29.8735000000001, 2526.3165, 18, 11, 10, 0, 0, 0, 0, 0, 0, 0, 22754, 162249, 1116276, 0, 0, 1423799015, 0, 5020, 5.1, 251, 0, '0');
INSERT INTO `db_users_b` VALUES (206, 'babkyy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421922291, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (203, 'jayzy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1421849442, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (204, 'iris1502', 364, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422353436, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (205, 'temass', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422800393, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (207, 'Deit15', 71, 0, 1, 0, 0, 0, 0, 175, 0, 0, 0, 0, 175, 0, 0, 0, 0, 1423164025, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (208, 'csserv55', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422014129, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (209, 'fktrc906', 54.0805, 4.8895, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2096, 0, 0, 0, 0, 1423644710, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (210, 'selzhan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422017806, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (211, 'blesk1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422027441, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (212, 'slava3201', 44.7915, 3.1185, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422454508, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (213, 'Nogar', 9.244, 5.516, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2363, 0, 0, 0, 0, 1423699390, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (214, 'Alegator59', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422093760, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (215, 'Yfnfkbz', 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422541592, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (216, 'GetLens', 45.15, 17.85, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6963, 0, 0, 0, 0, 1423761337, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (217, 'dens', 41, 0, 2, 0, 0, 0, 0, 695, 0, 0, 0, 0, 427, 0, 0, 0, 0, 1423253912, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (218, 'dankow98', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422116992, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (219, 'ZET1', 98.0455, 14.0245, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5717, 0, 0, 0, 0, 1423725919, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (250, 'andron1144', 27.57, 13.23, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5670, 0, 0, 0, 0, 1423759674, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (249, 'swerg', 66.0615, 1.6485, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 706, 0, 0, 0, 0, 1423054275, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (220, 'zums', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422185683, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (248, 'usame', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422649449, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (222, 'Ryslan777', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422519630, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (221, 'bhbirf906', 80.9004999999999, 117.8695, 43, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50519, 0, 0, 0, 0, 1423831845, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (223, 'GERAKL', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422195813, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (224, 'tiger55555', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422216379, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (225, 'imkatla', 456, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423563367, 100, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (226, 'Askadeus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422435229, 0, 100, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (227, 'abnormalen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422471143, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (228, 'Mixaluch', 43.4215, 27.6885, 10, 0, 0, 0, 0, 1799, 0, 0, 0, 0, 13290, 0, 0, 0, 0, 1423844606, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (251, 'scorpion66', -35.688, 0.168, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 71, 0, 0, 0, 0, 1422733036, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (247, 'Vktor1987', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422629517, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (229, 'mamaaa', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422354668, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (230, 'Sss502', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422356080, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (246, 'FBi59', 87, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422629125, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (231, 'palpalyh', 57.4085, 13.6815, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5863, 0, 0, 0, 0, 1423826398, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (235, 'romka', -54, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422517617, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (232, 'olegator74', 77.5435, 2.4465, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1048, 0, 0, 0, 0, 1423146701, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (240, 'abdula', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422564164, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (241, 'islam1991', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422573759, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (242, 'lema', 78, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422602515, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (233, 'noorg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422465863, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (234, 'snezhana', 67, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422471672, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (236, 'CrazyLegen', 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422528932, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (237, 'volume', 134.016, 169.624, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72698, 0, 0, 0, 0, 1423827893, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (238, 'mar4', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422552832, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (239, 'karolina55', 250, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422907001, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (245, 'Erejep', 9.7735, 0.4165, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 178, 0, 0, 0, 0, 1422720025, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (244, 'amince', 61.7165, 11.6935, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5011, 0, 0, 0, 0, 1423816629, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (252, 'a100500q', 79.9115000000002, 858.7985, 29, 21, 2, 0, 0, 0, 0, 0, 0, 0, 27283, 233219, 107557, 0, 0, 1423299746, 0, 2000, 0, 100, 0, '0');
INSERT INTO `db_users_b` VALUES (253, 'Vagan', 53.3895, 10.4405, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4474, 0, 0, 0, 0, 1423839233, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (254, 'robetoman', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422715824, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (255, 'xxx555', 66, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422717423, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (256, 'Doshs', 21, 0, 1, 0, 0, 0, 0, 1529, 0, 0, 0, 0, 1529, 0, 0, 0, 0, 1423504952, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (257, 'Gennadiy77', 84, 0, 1, 0, 0, 0, 0, 70, 0, 0, 0, 0, 70, 0, 0, 0, 0, 1422762736, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (258, 'galstya', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422798533, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (259, 'erik1999ff', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422799371, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (260, 'tornadosta', 97.445, 22.855, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9792, 0, 0, 0, 0, 1423823841, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (261, 'cactyc', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422806151, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (262, 'viktors', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422810861, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (263, 'FeeLing', 48, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422823667, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (264, 'Zero35', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422832973, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (265, 'morr', 42, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422846936, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (266, 'Ririeajj', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422862873, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (268, 'udovitskiy', 225.9575, 1.5925, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 682, 0, 0, 0, 0, 1423318022, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (267, 'rty6ty', 35, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422900472, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (269, 'bodev', 7, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1422971876, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (270, 'cariden', 363.007, 3.773, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1618, 0, 0, 0, 0, 1423389773, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (271, 'mishanja30', 144.7655, 3.1045, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1330, 0, 0, 0, 0, 1423684089, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (272, '2069321', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423037390, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (273, 'chelton085', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423037592, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (274, 'dima12321', 33, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423067008, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (275, 'stupak2691', 28.6485, 3.0415, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1304, 0, 0, 0, 0, 1423737835, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (276, 'rerishari', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423086003, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (277, 'SUMRAC', 30.9405, 6.4295, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2755, 0, 0, 0, 0, 1423771810, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (278, 'Asasins123', 4.0065, 0.0035, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1423155825, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (279, 'Evgeniy888', 94.2255, 6.0445, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2591, 0, 0, 0, 0, 1423777366, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (280, 'tverdun927', 98.4535, 2.9365, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1257, 0, 0, 0, 0, 1423759530, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (281, 'Bakeshi', 90.313, 7.707, 6, 0, 0, 0, 0, 170, 0, 0, 0, 0, 3470, 0, 0, 0, 0, 1423828405, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (282, 'missklv', 66, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423217543, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (283, 'ganne', 97.0785, 3.8115, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1634, 0, 0, 0, 0, 1423777262, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (284, 'izadora', 18.5395, 0.2905, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 125, 0, 0, 0, 0, 1423389878, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (285, 'blizz88', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423400667, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (286, 'kvozimir', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423413311, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (287, 'admin1', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423487670, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (288, 'Diknoa', -65, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423497385, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (289, 'dima008', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423497884, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (290, 'demo', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423506942, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (291, 'soso', -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423511333, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (292, 'maks2108', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423562631, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (293, 'practik', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423574230, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (294, 'Romka92', -51, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423620699, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (295, 'mitya777', 86.7215, 0.3885, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 166, 0, 0, 0, 0, 1423767469, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (296, 'schcolnik', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423767144, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (297, 'alexsoft59', 3, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1423819916, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (298, 'kondor', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1462616717, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (299, 'MegaScript', 66, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1462619003, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (300, 'romdik', 49.2335, 3.3565, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1438, 0, 0, 0, 0, 1473246918, 0, 0, 0, 0, 0, '0');
INSERT INTO `db_users_b` VALUES (301, 'games', 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1473225922, 0, 0, 0, 0, 0, '0');

-- --------------------------------------------------------

-- 
-- ��������� ������� `stats_fortuna`
-- 

CREATE TABLE `stats_fortuna` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(55) NOT NULL default '',
  `sum` varchar(55) NOT NULL default '',
  `date` int(13) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 AUTO_INCREMENT=62 ;

-- 
-- ���� ������ ������� `stats_fortuna`
-- 

INSERT INTO `stats_fortuna` VALUES (50, 'shpionka', '1', 1422606587);
INSERT INTO `stats_fortuna` VALUES (51, 'shpionka', '16', 1422606607);
INSERT INTO `stats_fortuna` VALUES (52, 'shpionka', '7', 1422606622);
INSERT INTO `stats_fortuna` VALUES (53, 'shpionka', '8', 1422606637);
INSERT INTO `stats_fortuna` VALUES (54, 'toys', '3', 1422610517);
INSERT INTO `stats_fortuna` VALUES (55, 'toys', '13', 1422610539);
INSERT INTO `stats_fortuna` VALUES (56, 'toys', '2', 1422610572);
INSERT INTO `stats_fortuna` VALUES (57, 'a100500q', '13', 1422776624);
INSERT INTO `stats_fortuna` VALUES (58, 'a100500q', '16', 1422776642);
INSERT INTO `stats_fortuna` VALUES (59, 'stupak62', '7', 1423165839);
INSERT INTO `stats_fortuna` VALUES (60, 'stupak62', '7', 1423165860);
INSERT INTO `stats_fortuna` VALUES (61, 'stupak62', '10', 1423165903);

-- --------------------------------------------------------

-- 
-- ��������� ������� `wmrush_pm`
-- 

CREATE TABLE `wmrush_pm` (
  `id` int(11) NOT NULL auto_increment,
  `id_pm` int(11) NOT NULL default '0',
  `user_id_in` int(11) NOT NULL default '0',
  `login_in` varchar(55) NOT NULL default '',
  `user_id_out` int(11) NOT NULL default '0',
  `login_out` varchar(55) NOT NULL default '',
  `theme` varchar(150) NOT NULL default '',
  `text` text NOT NULL,
  `status` int(11) NOT NULL default '0',
  `date` int(11) NOT NULL default '0',
  `inbox` int(11) NOT NULL default '0',
  `outbox` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- 
-- ���� ������ ������� `wmrush_pm`
-- 

