<?PHP
$tfstats = time() - 60*60*24;
$db->Query("SELECT 
(SELECT COUNT(*) FROM db_users_a) all_users,
(SELECT SUM(insert_sum) FROM db_users_b) all_insert, 
(SELECT SUM(payment_sum) FROM db_users_b) all_payment, 
(SELECT COUNT(*) FROM db_users_a WHERE date_reg > '$tfstats') new_users");
$stats_data = $db->FetchArray();
?>

<div class="user-line-bg">
<div class="user-line">

</div>
</div>

<div class="line">
</div>
<div class="all-content">
<div class="intro-content">

<center><h1>�������</h1></center>

<?PHP
$db->Query("SELECT * FROM db_news ORDER BY id DESC");
if($db->NumRows() > 0){
while($news = $db->FetchArray()){
?>

<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
  <tbody><tr>
    <td>
	<div style="background:#fff; border:1px solid #0f3b4c; padding:10px 10px 10px 10px;">����: <?=date("d.m.Y",$news["date_add"]); ?></div><br>
	<h2><?=$news["title"]; ?></h2><br>
	</td>
    
  </tr>

  <tr>
    <td><?=$news["news"]; ?></td>
  </tr>

<?PHP
}
}else echo "<center>�������� ���</center>";
?>


</tbody></table>

</div></div>