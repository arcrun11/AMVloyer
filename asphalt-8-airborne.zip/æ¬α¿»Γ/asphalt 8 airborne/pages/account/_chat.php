<?PHP
$tfstats = time() - 60*60*24;
$db->Query("SELECT 
(SELECT COUNT(*) FROM db_users_a) all_users,
(SELECT SUM(insert_sum) FROM db_users_b) all_insert, 
(SELECT SUM(payment_sum) FROM db_users_b) all_payment, 
(SELECT COUNT(*) FROM db_users_a WHERE date_reg > '$tfstats') new_users");
$stats_data = $db->FetchArray();
?>
<div class="user-content-fon">
<div class="clr"></div>
<br><br>
<center><h3>�������</h3></center>

<div style="background:#629b18; margin-bottom:10px; padding:10px 10px 10px 10px; text-align:center; color:#fff;">��� � ����������</div>

</div>
<div class="fon-bottom"></div>				
</div>
<br><br>
</div>